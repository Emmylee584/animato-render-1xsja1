// WARDROBE CORE: the body measurements of every character style, the drawing helpers (colours, fabric patterns, outlines, shading)
// and the function that turns a list of worn things into drawings that fit the person.
//
//   bodyModel('stickman', {gender})   -> where the head, neck, shoulders, waist, hips, knees and feet are for that style (scene units, feet at y=880)
//   renderPlan(plan, ctx)             -> { back, mid, head, front }  the clothes as SVG strings, in the person's own coordinates
//
// Layers (so a garment sits where a real one does and arms/hands are never hidden by a shirt):
//   back   behind the whole person (cape, backpack, wings, tail, long coat back)
//   mid    on the torso and legs, UNDER the arms and the head (shirt, dress, skirt, apron, belt)
//   head   on the head, moves with the head (hat, glasses, mask, ears, hair things)
//   front  on top of everything on the body (scarf, tie, necklace, bag strap, jewellery)
// The styles' own renderers take `mid` and `head` through the hooks `_w.m` and `_w.h` of the look; `back` and `front` wrap the finished picture.
// Because everything is drawn INSIDE the character's picture, the app's scene lighting, shading and floor shadow treat clothes as part of the person.
// Pure functions, no DOM (a browser is only used, when there is one, to measure the head of an uploaded character).

const cl = (v, a, b) => Math.min(b, Math.max(a, v));
const f1 = (n) => (Math.round(n * 10) / 10).toString();
const lerp = (a, b, t) => a + (b - a) * t;

// ---------------------------------------------------------------- colours
export const COLORS = Object.freeze({
  white: '#f5f5f2', ivory: '#f3ecd8', cream: '#efe4c8', beige: '#d8c4a0', tan: '#c19a6b', khaki: '#b5a46a', brown: '#7a4a2a', chocolate: '#4a2c1a', coffee: '#6b4423', camel: '#c19a5b',
  black: '#1c1c20', charcoal: '#363a42', grey: '#8a8f98', gray: '#8a8f98', silver: '#c4c8cf', slate: '#5a6577', graphite: '#4a4f5a',
  red: '#d32f2f', crimson: '#b71c3c', scarlet: '#e8402a', maroon: '#7a1a2a', burgundy: '#6d1f35', wine: '#722f37', rose: '#e8788f', pink: '#f08fb0', blush: '#f3b8c4', magenta: '#c2307e', fuchsia: '#d63aa0', coral: '#ff7f6e', salmon: '#f49a85',
  orange: '#f28a1d', tangerine: '#f57c20', rust: '#b5502a', terracotta: '#c8643d', peach: '#ffbc96', apricot: '#fbb77a', amber: '#f2a516', mustard: '#d9a21b', gold: '#d9a82b', yellow: '#f5d327', lemon: '#f7e65a', sunflower: '#f7c52b',
  lime: '#9ccc3c', olive: '#7a8a2a', green: '#2f9e4f', emerald: '#1c8a5a', forest: '#1f5f3a', mint: '#8fe0b8', sage: '#9bb59a', moss: '#6b7f3a', teal: '#1b8a8a', turquoise: '#2fc4c0', aqua: '#4fd6d6', cyan: '#27b8e0',
  sky: '#7cc4ee', blue: '#2f6fd6', cobalt: '#1f4fb0', royal: '#2a45c4', navy: '#1b2a5a', denim: '#3f5f8f', indigo: '#3b3a9a', periwinkle: '#8a94e8', lavender: '#b9a4e6', lilac: '#c8a6dc', purple: '#7b3fa8', violet: '#8a4fd6', plum: '#6a2a5a', mauve: '#b08aa8',
  neon: '#39ff88', neongreen: '#39ff88', neonpink: '#ff3fa8', neonyellow: '#f5ff3a', neonblue: '#3fd2ff', bronze: '#a8703a', copper: '#b8643a', rosegold: '#d9a48f',
});
const COLOR_NAMES = Object.keys(COLORS);
const MODS = { dark: 0.62, deep: 0.7, light: 1.25, pale: 1.4, pastel: 1.45, bright: 1.08, dusty: 0.9 };
const HEXRE = /^#(?:[0-9a-f]{3}|[0-9a-f]{6})$/i;

export const normHex = (h, d = '') => { const s = String(h == null ? '' : h).trim(); if (/^#[0-9a-f]{6}$/i.test(s)) return s.toLowerCase(); if (/^#[0-9a-f]{3}$/i.test(s)) return ('#' + s[1] + s[1] + s[2] + s[2] + s[3] + s[3]).toLowerCase(); return d; };
export function shade(hex, k) {
  const h = normHex(hex, '#888888'); const n = parseInt(h.slice(1), 16);
  let r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
  if (k <= 1) { r *= k; g *= k; b *= k; } else { const t = k - 1; r = r + (255 - r) * t; g = g + (255 - g) * t; b = b + (255 - b) * t; }
  const c = (v) => Math.round(cl(v, 0, 255)).toString(16).padStart(2, '0');
  return '#' + c(r) + c(g) + c(b);
}
export function mix(a, b, t) {
  const x = parseInt(normHex(a, '#888888').slice(1), 16), y = parseInt(normHex(b, '#888888').slice(1), 16);
  const ch = (s) => Math.round(lerp((x >> s) & 255, (y >> s) & 255, t));
  return '#' + [16, 8, 0].map((s) => ch(s).toString(16).padStart(2, '0')).join('');
}
const lum = (hex) => { const n = parseInt(normHex(hex, '#888888').slice(1), 16); return (0.299 * ((n >> 16) & 255) + 0.587 * ((n >> 8) & 255) + 0.114 * (n & 255)) / 255; };
export { lum };

/** "dark red", "navy", "#ff8800", "pastel pink" -> '#rrggbb' ('' when the words are no colour). */
export function colorOf(text) {
  const t = String(text == null ? '' : text).trim().toLowerCase();
  if (!t) return '';
  const hx = normHex(t); if (hx) return hx;
  const words = t.replace(/[^a-z# ]/g, ' ').split(/\s+/).filter(Boolean);
  let k = 1, base = '';
  for (const w of words) {
    if (MODS[w]) k = MODS[w];
    else if (COLORS[w]) base = COLORS[w];
    else if (w.length > 3 && w.endsWith('ish') && COLORS[w.slice(0, -3)]) base = COLORS[w.slice(0, -3)];
  }
  return base ? (k === 1 ? base : shade(base, k)) : '';
}
export const isColorWord = (w) => !!(COLORS[w] || MODS[w] || (w.length > 3 && w.endsWith('ish') && COLORS[w.slice(0, -3)]));
export const COLOR_LIST = COLOR_NAMES;

// ---------------------------------------------------------------- fabric patterns (drawn as SVG <pattern>, so they bend with nothing and cost nothing)
export const PATTERNS = Object.freeze(['solid', 'stripes', 'pinstripe', 'checks', 'gingham', 'plaid', 'dots', 'polka', 'floral', 'tropical', 'camo', 'houndstooth', 'argyle', 'stars', 'hearts', 'zigzag', 'waves', 'leopard', 'zebra', 'tiedye', 'denim', 'knit', 'quilted', 'sequin', 'lace', 'colorblock', 'gradient', 'ankara', 'kente', 'tartan', 'herringbone', 'chevron', 'paisley', 'snakeskin', 'galaxy', 'brick']);
const PAT_ALIAS = { striped: 'stripes', stripe: 'stripes', striped2: 'stripes', check: 'checks', checked: 'checks', checkered: 'checks', checker: 'checks', chequered: 'checks', dotted: 'dots', spotted: 'dots', spots: 'dots', flowers: 'floral', flower: 'floral', hawaiian: 'tropical', camouflage: 'camo', military: 'camo', heart: 'hearts', star: 'stars', animal: 'leopard', cheetah: 'leopard', tigerstripe: 'zebra', tie: 'tiedye', 'tie dye': 'tiedye', tiedye: 'tiedye', jeans: 'denim', knitted: 'knit', cable: 'knit', quilt: 'quilted', puffer: 'quilted', sparkly: 'sequin', glitter: 'sequin', sequins: 'sequin', african: 'ankara', wax: 'ankara', plain: 'solid', zig: 'zigzag', wave: 'waves', space: 'galaxy', cosmic: 'galaxy', snake: 'snakeskin', bricks: 'brick', block: 'colorblock', colourblock: 'colorblock', ombre: 'gradient', fade: 'gradient', scottish: 'tartan', diamond: 'argyle', diamonds: 'argyle', polkadot: 'polka', polkadots: 'polka' };
export const patternOf = (w) => { const s = String(w || '').toLowerCase().replace(/[^a-z ]/g, '').trim(); return PATTERNS.includes(s) ? s : (PAT_ALIAS[s] || ''); };
export const PATTERN_ALIASES = PAT_ALIAS;

/** The <pattern> element for a fabric. `id` must be unique in the picture. */
export function patternDef(id, pat, c1, c2) {
  const a = normHex(c1, '#888888'), b = normHex(c2, '') || (lum(a) > 0.55 ? shade(a, 0.45) : shade(a, 1.65)), d = shade(a, 0.78), e = shade(a, 1.22);
  const P = (w, h, body, rot = 0) => `<pattern id="${id}" width="${w}" height="${h}" patternUnits="userSpaceOnUse"${rot ? ` patternTransform="rotate(${rot})"` : ''}><rect width="${w}" height="${h}" fill="${a}"/>${body}</pattern>`;
  switch (pat) {
    case 'stripes': return P(16, 16, `<rect width="16" height="7" fill="${b}"/>`);
    case 'pinstripe': return P(11, 10, `<rect width="1.8" height="10" fill="${b}" opacity=".85"/>`);
    case 'checks': return P(24, 24, `<rect width="12" height="12" fill="${b}"/><rect x="12" y="12" width="12" height="12" fill="${b}"/>`);
    case 'gingham': return P(20, 20, `<rect width="10" height="20" fill="${b}" opacity=".55"/><rect width="20" height="10" fill="${b}" opacity=".55"/>`);
    case 'plaid': case 'tartan': return P(34, 34, `<rect x="4" width="9" height="34" fill="${b}" opacity=".55"/><rect y="4" width="34" height="9" fill="${b}" opacity=".55"/><rect x="21" width="2.4" height="34" fill="${d}"/><rect y="21" width="34" height="2.4" fill="${d}"/><rect x="27" width="1.4" height="34" fill="#fff" opacity=".45"/>`);
    case 'dots': return P(18, 18, `<circle cx="9" cy="9" r="3.6" fill="${b}"/>`);
    case 'polka': return P(30, 30, `<circle cx="8" cy="8" r="7" fill="${b}"/><circle cx="23" cy="23" r="7" fill="${b}"/>`);
    case 'floral': return P(36, 36, `<g fill="${b}"><circle cx="9" cy="9" r="3.2"/><circle cx="9" cy="3.6" r="2.8"/><circle cx="9" cy="14.4" r="2.8"/><circle cx="3.6" cy="9" r="2.8"/><circle cx="14.4" cy="9" r="2.8"/></g><circle cx="9" cy="9" r="2.2" fill="#ffd54a"/><g fill="${e}"><circle cx="27" cy="27" r="3"/><circle cx="27" cy="22" r="2.6"/><circle cx="27" cy="32" r="2.6"/><circle cx="22" cy="27" r="2.6"/><circle cx="32" cy="27" r="2.6"/></g><circle cx="27" cy="27" r="2" fill="#fff6c0"/><path d="M18 26q4-4 8-1" stroke="#3a8a4a" stroke-width="1.6" fill="none"/>`);
    case 'tropical': return P(44, 44, `<path d="M6 30q10-26 30-24-10 6-14 22q-8 4-16 2z" fill="#2f9e4f" opacity=".9"/><path d="M30 44q2-14 14-16-2 10-8 16z" fill="#1f7a3a" opacity=".9"/><circle cx="34" cy="14" r="5" fill="${b}"/><circle cx="34" cy="14" r="2" fill="#ffd54a"/>`);
    case 'camo': return P(60, 60, `<path d="M4 14q14-14 30-4 8 14-8 20-20 4-22-16z" fill="#5a6b3a"/><path d="M36 38q16-8 22 6-4 14-20 12-8-8-2-18z" fill="#3a4a28"/><path d="M8 44q8-6 16 2-2 12-14 10z" fill="#8a7a4a"/>`);
    case 'houndstooth': return P(24, 24, `<path d="M0 0h12v12zM12 12h12v12zM12 0h12L12 12zM0 12h12L0 24z" fill="${b}"/>`);
    case 'argyle': return P(40, 40, `<path d="M20 0L40 20 20 40 0 20z" fill="${b}"/><path d="M20 0L40 20 20 40 0 20z" fill="none" stroke="${d}" stroke-width="1.2"/><path d="M0 0l40 40M40 0L0 40" stroke="#fff" stroke-width=".8" opacity=".5"/>`);
    case 'stars': return P(30, 30, `<path d="M8 2l2 5 5 .4-4 3.4 1.3 5.2-4.3-3-4.3 3L5 10.8 1 7.4 6 7z" fill="${b}"/><path d="M23 18l1.3 3.2 3.4.3-2.6 2.2.8 3.3-2.9-1.9-2.9 1.9.8-3.3-2.6-2.2 3.4-.3z" fill="${b}" opacity=".8"/>`);
    case 'hearts': return P(30, 30, `<path d="M9 14C2 9 4 3 8 4q1 .4 1 2 0-1.6 1-2c4-1 6 5-1 10z" fill="${b}"/><path d="M24 28c-5-4-3-9 0-8q.7.3.7 1.3 0-1 .7-1.3c3-1 5 4-1.4 8z" fill="${b}" opacity=".8"/>`);
    case 'zigzag': return P(24, 14, `<path d="M0 10l6-7 6 7 6-7 6 7" fill="none" stroke="${b}" stroke-width="3.4" stroke-linejoin="round"/>`);
    case 'chevron': return P(24, 18, `<path d="M0 12l12-10 12 10" fill="none" stroke="${b}" stroke-width="4"/>`);
    case 'herringbone': return P(20, 20, `<path d="M0 10l10-10 10 10M0 20l10-10 10 10" fill="none" stroke="${b}" stroke-width="3.4" opacity=".8"/>`);
    case 'waves': return P(30, 18, `<path d="M0 9q7.5-8 15 0t15 0" fill="none" stroke="${b}" stroke-width="3.2"/>`);
    case 'leopard': return P(40, 40, `<g fill="#2a1a10"><path d="M6 8q6-6 11 0-4 6-11 0z"/><path d="M26 22q6-6 11 0-4 6-11 0z"/><path d="M8 30q5-5 9 0-3 5-9 0z"/><path d="M28 4q4-4 8 0-3 4-8 0z"/></g><g fill="${shade(a, 1.3)}"><circle cx="12" cy="9" r="2.2"/><circle cx="32" cy="23" r="2.2"/></g>`);
    case 'zebra': return P(30, 24, `<path d="M0 4q10 4 8 10t6 10M16 0q8 6 6 12t8 12" fill="none" stroke="${shade(a, 0.2)}" stroke-width="5" opacity=".92"/>`);
    case 'snakeskin': return P(22, 22, `<path d="M11 0l11 11-11 11L0 11z" fill="${b}" opacity=".5"/><path d="M11 5l6 6-6 6-6-6z" fill="${d}" opacity=".7"/>`);
    case 'tiedye': return `<radialGradient id="${id}" cx=".5" cy=".5" r=".75"><stop offset="0" stop-color="${b}"/><stop offset=".3" stop-color="${a}"/><stop offset=".55" stop-color="${mix(a, '#ffd54a', 0.5)}"/><stop offset=".8" stop-color="${mix(a, '#ff4fa0', 0.5)}"/><stop offset="1" stop-color="${a}"/></radialGradient>`;
    case 'gradient': return `<linearGradient id="${id}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${b}"/><stop offset="1" stop-color="${a}"/></linearGradient>`;
    case 'galaxy': return `<linearGradient id="${id}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#10163a"/><stop offset=".5" stop-color="#5a2a8a"/><stop offset="1" stop-color="#14305a"/></linearGradient>`;
    case 'denim': return P(8, 8, `<path d="M0 8L8 0" stroke="${e}" stroke-width="1" opacity=".5"/><path d="M0 4L4 0" stroke="${d}" stroke-width="1" opacity=".5"/>`);
    case 'knit': return P(12, 12, `<path d="M3 0v12M9 0v12" stroke="${d}" stroke-width="2.4" opacity=".55"/><path d="M0 3q3 3 6 0t6 0" stroke="${e}" stroke-width="1" fill="none" opacity=".6"/>`);
    case 'quilted': return P(34, 34, `<path d="M0 17Q17 0 34 17 17 34 0 17z" fill="none" stroke="${d}" stroke-width="2.2" opacity=".7"/>`);
    case 'sequin': return P(14, 14, `<circle cx="4" cy="4" r="3.6" fill="${e}"/><circle cx="11" cy="11" r="3.6" fill="${e}"/><circle cx="4" cy="4" r="1.4" fill="#fff" opacity=".7"/><circle cx="11" cy="11" r="1.4" fill="#fff" opacity=".7"/>`);
    case 'lace': return P(18, 18, `<circle cx="9" cy="9" r="5.4" fill="none" stroke="${b}" stroke-width="1.6"/><circle cx="0" cy="0" r="3" fill="none" stroke="${b}" stroke-width="1.4"/><circle cx="18" cy="18" r="3" fill="none" stroke="${b}" stroke-width="1.4"/>`);
    case 'ankara': return P(46, 46, `<circle cx="23" cy="23" r="17" fill="${b}"/><circle cx="23" cy="23" r="11" fill="${a}"/><circle cx="23" cy="23" r="5" fill="#ffc83a"/><path d="M0 0l9 9M46 0l-9 9M0 46l9-9M46 46l-9-9" stroke="#1f9e8a" stroke-width="4"/>`);
    case 'kente': return P(40, 40, `<rect width="40" height="8" fill="#e8b320"/><rect y="12" width="40" height="8" fill="#c8302a"/><rect y="24" width="40" height="8" fill="#1f8a4a"/><rect x="0" y="34" width="40" height="3" fill="#111"/><rect x="8" width="6" height="40" fill="#111" opacity=".55"/><rect x="26" width="6" height="40" fill="#fff" opacity=".35"/>`);
    case 'paisley': return P(32, 32, `<path d="M8 22c-6-8 0-18 8-16 5 1 5 8 0 9-3 .6-3-3-1-3" fill="none" stroke="${b}" stroke-width="2.6"/><path d="M22 28c-3-4 0-9 4-8 3 .8 2 4 0 4.4" fill="none" stroke="${b}" stroke-width="2" opacity=".8"/>`);
    case 'brick': return P(32, 16, `<path d="M0 0h32M0 8h32M0 16h32M16 0v8M0 8v8M32 8v8" stroke="${d}" stroke-width="1.6" opacity=".7" fill="none"/>`);
    default: return '';
  }
}

// ---------------------------------------------------------------- how each style is drawn (line weight, shading)
export const FLAVORS = Object.freeze({
  original: { ink: '#1b1b1f', sw: 4.6, shade: false, join: 'round' },
  stickman: { ink: '#12151f', sw: 4, shade: false, join: 'round' },
  human: { ink: '#20222c', sw: 1.3, shade: true, join: 'round', inkA: 0.62 },
  doodle: { ink: '#5b4a3d', sw: 3.2, shade: false, join: 'round', sketch: true },
  custom: { ink: '#25252c', sw: 3.4, shade: true, join: 'round', inkA: 0.9 },
});

// ---------------------------------------------------------------- the body of each style (front view, feet on y=880, centred on x=0)
//   Y = heights of the landmarks, X = half widths of the torso there, head = the head ellipse, eye / mouth = where the face is,
//   k = detail scale (a button on a tiny doodle body is smaller than on a big cartoon one), legs = where the legs hang.
const MODELS = {
  original: { head: { x: 0, y: 400, rx: 168, ry: 148 }, neck: { y0: 538, y1: 582, w: 27 }, Y: { sh: 584, chest: 640, waist: 730, hip: 796, crotch: 806, knee: 842, ankle: 868 }, X: { sh: 92, chest: 96, waist: 96, hip: 96 }, legs: { x: 38, w: 20 }, foot: { w: 50, h: 18 }, eye: { y: 436, dx: 68 }, mouth: { y: 500 }, k: 1, ear: 176, shoulder: 100 },
  stickman: { head: { x: 0, y: 322, rx: 74, ry: 72 }, neck: { y0: 394, y1: 444, w: 9 }, Y: { sh: 444, chest: 492, waist: 575, hip: 612, crotch: 640, knee: 752, ankle: 862 }, X: { sh: 52, chest: 50, waist: 46, hip: 50 }, legs: { x: 27, w: 21 }, foot: { w: 38, h: 20 }, eye: { y: 322, dx: 28 }, mouth: { y: 352 }, k: 0.8, ear: 76, shoulder: 56 },
  human: { head: { x: 0, y: 330, rx: 38, ry: 48 }, neck: { y0: 376, y1: 416, w: 13 }, Y: { sh: 416, chest: 470, waist: 562, hip: 628, crotch: 690, knee: 785, ankle: 862 }, X: { sh: 58, chest: 52, waist: 44, hip: 60 }, legs: { x: 22, w: 24 }, foot: { w: 30, h: 14 }, eye: { y: 338, dx: 18 }, mouth: { y: 362 }, k: 0.56, ear: 39, shoulder: 60 },
  doodle: { head: { x: 0, y: 530, rx: 152, ry: 190 }, neck: { y0: 715, y1: 725, w: 18 }, Y: { sh: 699, chest: 725, waist: 760, hip: 782, crotch: 790, knee: 826, ankle: 862 }, X: { sh: 90, chest: 92, waist: 92, hip: 88 }, legs: { x: 34, w: 10 }, foot: { w: 36, h: 14 }, eye: { y: 520, dx: 60 }, mouth: { y: 592 }, k: 0.62, ear: 152, shoulder: 96 },
};

/** The measurements of one person, as the clothes need them. opt: { gender, build, rig (an uploaded character's bone lengths), head ({x,y,rx,ry} when measured) } */
export function bodyModel(style, opt = {}) {
  const st = MODELS[style] ? style : (style === 'custom' && opt.rig ? 'custom' : 'original');
  let B;
  if (st === 'custom') B = customModel(opt.rig, opt.head);
  else B = JSON.parse(JSON.stringify(MODELS[st]));
  B.style = st;
  const male = String(opt.gender || '').toLowerCase().startsWith('m');
  if (st === 'human') {
    if (male) { B.X.sh = 68; B.X.chest = 62; B.X.waist = 54; B.X.hip = 56; B.head.ry = 50; B.head.rx = 40; B.neck.w = 15; B.legs.x = 21; }
  }
  const bw = cl(+opt.build || 1, 0.8, 1.3);
  if (bw !== 1) { for (const k of Object.keys(B.X)) B.X[k] *= bw; }
  B.top = B.head.y - B.head.ry; B.chin = B.head.y + B.head.ry;
  B.floor = 880; B.legLen = 880 - B.Y.hip;
  return B;
}

function customModel(rig, head) {
  const R = rig || {};
  const UL = +R.upperLeg || 150, LL = +R.lowerLeg || 150, T = +R.torso || 190, SX = +R.shoulderX || 58, SD = +R.shoulderDown || 25, HX = +R.hipX || 32;
  const hipY = 880 - (UL + LL), neckY = hipY - T, shY = neckY + SD;
  const hr = Math.max(40, T * 0.42);
  const H = head && head.rx ? head : { x: 0, y: neckY - hr * 0.8, rx: hr * 0.9, ry: hr };
  const wid = SX + 10;
  return {
    head: H, neck: { y0: H.y + H.ry - 4, y1: shY, w: Math.max(8, SX * 0.2) },
    Y: { sh: shY, chest: lerp(shY, hipY, 0.3), waist: lerp(shY, hipY, 0.72), hip: hipY, crotch: hipY + 14, knee: hipY + UL, ankle: 880 - 14 },
    X: { sh: wid, chest: wid - 2, waist: wid - 8, hip: HX + 24 }, legs: { x: HX, w: Math.max(18, HX * 0.8) }, foot: { w: HX * 1.5, h: 16 },
    eye: { y: H.y - H.ry * 0.05, dx: H.rx * 0.45 }, mouth: { y: H.y + H.ry * 0.45 }, k: cl(T / 230, 0.5, 1.2), ear: H.rx, shoulder: SX, rig: R, custom: true,
  };
}

/** Half width of the torso (cloth) at a height, between the landmarks. grow = extra width of the garment on each side. */
export function halfW(B, y, grow = 0) {
  const L = [[B.Y.sh, B.X.sh], [B.Y.chest, B.X.chest], [B.Y.waist, B.X.waist], [B.Y.hip, B.X.hip]];
  let w;
  if (y <= L[0][0]) w = L[0][1] * (0.82 + 0.18 * cl((y - (L[0][0] - 24)) / 24, 0, 1));
  else if (y >= L[3][0]) w = L[3][1] + (y - L[3][0]) * 0.06;
  else { w = L[3][1]; for (let i = 1; i < L.length; i++) if (y <= L[i][0]) { w = lerp(L[i - 1][1], L[i][1], (y - L[i - 1][0]) / (L[i][0] - L[i - 1][0])); break; } }
  return w + grow;
}
/** Height of a hem: 'crop' | 'waist' | 'hip' | 'thigh' | 'knee' | 'midi' | 'ankle' | 'floor' or a number (0 = shoulder, 1 = hip). */
export function hemY(B, name) {
  const Y = B.Y;
  const m = { crop: lerp(Y.sh, Y.waist, 0.78), waist: Y.waist, belly: lerp(Y.waist, Y.hip, 0.5), hip: Y.hip + 4, bottom: Y.hip + 12, thigh: lerp(Y.hip, Y.knee, 0.45), mini: lerp(Y.hip, Y.knee, 0.35), knee: Y.knee, midi: lerp(Y.knee, Y.ankle, 0.5), shin: lerp(Y.knee, Y.ankle, 0.75), ankle: Y.ankle - 6, floor: 878 };
  return m[name] != null ? m[name] : (Number.isFinite(+name) ? lerp(Y.sh, Y.hip, +name) : Y.hip);
}

// ---------------------------------------------------------------- drawing helpers handed to every garment
export function makeDrawKit(B, F, uid) {
  const k = B.k;
  let n = 0;
  const defs = [];
  const K = {
    B, F, k, uid,
    /** outline + fill attributes. w = outline weight multiplier */
    st: (fill, w = 1) => `fill="${fill}" stroke="${F.ink}" stroke-width="${f1(F.sw * w * (B.style === 'human' ? 1 : 1))}" stroke-linejoin="round" stroke-linecap="round"${F.inkA ? ` stroke-opacity="${F.inkA}"` : ''}`,
    ln: (w = 1, col) => `fill="none" stroke="${col || F.ink}" stroke-width="${f1(F.sw * w)}" stroke-linecap="round" stroke-linejoin="round"${F.inkA && !col ? ` stroke-opacity="${F.inkA}"` : ''}`,
    /** a cloth fill: plain colour or a pattern (adds its <pattern> to the defs once). */
    cloth: (col, pat, col2) => {
      if (!pat || pat === 'solid') return col;
      const id = `${uid}p${n++}`;
      const d = patternDef(id, pat, col, col2);
      if (!d) return col;
      defs.push(d);
      return `url(#${id})`;
    },
    /** soft shading drawn over a cloth shape (only where the style is shaded: lifelike people and uploaded characters) */
    shadeOver: (d, hh) => {
      if (!F.shade) return '';
      const id = `${uid}s${n++}`;
      defs.push(`<linearGradient id="${id}" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#05081a" stop-opacity=".28"/><stop offset=".22" stop-color="#05081a" stop-opacity="0"/><stop offset=".7" stop-color="#fff" stop-opacity=".06"/><stop offset="1" stop-color="#05081a" stop-opacity=".3"/></linearGradient>`);
      return `<path d="${d}" fill="url(#${id})" stroke="none"/>`;
    },
    defs: () => defs.join(''),
    /** a smooth closed shape through points [x,y,...] with curved corners */
    poly: (pts, round = 0) => polyPath(pts, round),
    dk: (c) => shade(c, 0.72), lt: (c) => shade(c, 1.28), W: (v) => v * k,
  };
  return K;
}

/** Path through the points with rounded corners (radius `round`). */
export function polyPath(pts, round = 0) {
  const n = pts.length / 2;
  if (!round || n < 3) { let d = ''; for (let i = 0; i < n; i++) d += (i ? 'L' : 'M') + f1(pts[2 * i]) + ',' + f1(pts[2 * i + 1]); return d + 'Z'; }
  let d = '';
  for (let i = 0; i < n; i++) {
    const p0 = [pts[2 * ((i + n - 1) % n)], pts[2 * ((i + n - 1) % n) + 1]], p1 = [pts[2 * i], pts[2 * i + 1]], p2 = [pts[2 * ((i + 1) % n)], pts[2 * ((i + 1) % n) + 1]];
    const l1 = Math.hypot(p1[0] - p0[0], p1[1] - p0[1]) || 1, l2 = Math.hypot(p2[0] - p1[0], p2[1] - p1[1]) || 1;
    const r = Math.min(round, l1 / 2, l2 / 2);
    const a = [p1[0] + (p0[0] - p1[0]) * r / l1, p1[1] + (p0[1] - p1[1]) * r / l1], b = [p1[0] + (p2[0] - p1[0]) * r / l2, p1[1] + (p2[1] - p1[1]) * r / l2];
    d += (i ? 'L' : 'M') + f1(a[0]) + ',' + f1(a[1]) + 'Q' + f1(p1[0]) + ',' + f1(p1[1]) + ' ' + f1(b[0]) + ',' + f1(b[1]);
  }
  return d + 'Z';
}

/**
 * Draws the plan. plan = { items: [{ id, slot, col, col2, pat, spec }] }  (see wardrobe-catalog.js)
 * ctx = { style, view ('front'|'back'), gender, build, rig, head, uid, pose }
 * Returns { back, mid, head, front, defs }.
 */
export function renderPlan(plan, ctx, GARMENTS) {
  const style = ctx.style || 'original';
  const B = bodyModel(style, ctx);
  const F = FLAVORS[style] || FLAVORS.original;
  const uid = String(ctx.uid || 'w');
  const kit = makeDrawKit(B, F, uid);
  const view = ctx.view === 'back' ? 'back' : 'front';
  const out = { back: '', mid: '', head: '', front: '' };
  const items = (plan && plan.items) || [];
  // draw order inside a layer: base garments first, then outer layers
  const ORDER = { feet: 0, bottom: 1, top: 2, dress: 2, suit: 2, outer: 3, waist: 4, neck: 5, hands: 5, bag: 6, back: 0, head: 1, eyes: 2, face: 3, ears: 4, hair: 0, jewel: 6, tail: 0, prop: 7 };
  const sorted = items.slice().sort((a, b) => (ORDER[a.slot] || 0) - (ORDER[b.slot] || 0));
  for (const it of sorted) {
    const g = GARMENTS.get(it.id);
    if (!g || !g.draw) continue;
    let r;
    try { r = g.draw(kit, { col: it.col, col2: it.col2, pat: it.pat, view, gender: ctx.gender, pose: ctx.pose, item: it, ctx }); } catch (e) { r = null; }
    if (!r) continue;
    for (const l of ['back', 'mid', 'head', 'front']) if (r[l]) out[l] += r[l];
  }
  out.defs = kit.defs();
  return out;
}
