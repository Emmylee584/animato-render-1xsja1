/* A picture drawn from SVG text is read by the browser as strict XML, which refuses a tag that names the same attribute twice
   (for example stroke-linecap two times). The live preview does not mind, but the video export and the GitHub renderer stop with
   "frame render failed". fixDuplicateAttributes keeps the FIRST copy of each attribute on every tag, so one sloppy shape can never stop a whole video. */
const TAG = /<[a-zA-Z][\w:.-]*\s(?:"[^"]*"|'[^']*'|[^<>"'])*>/g;
const ATTR = /(\s)([\w:.-]+)(\s*=\s*(?:"[^"]*"|'[^']*'))/g;

export function fixDuplicateAttributes(svg) {
  if (typeof svg !== 'string') return svg;
  return svg.replace(TAG, (tag) => {
    const seen = new Set();
    let dup = false;
    const out = tag.replace(ATTR, (m, sp, name, rest) => {
      if (seen.has(name)) { dup = true; return ''; }
      seen.add(name);
      return m;
    });
    return dup ? out : tag;
  });
}

/* Adds the round line ends to a shape only where it has not set them itself (never writes an attribute twice). */
export function roundLineEnds(markup, tagRe) {
  return markup.replace(tagRe, (m, name, rest) => {
    const has = (a) => new RegExp('\\s' + a + '\\s*=').test(rest);
    if (has('stroke-linejoin')) return m;
    return '<' + name + ' stroke-linejoin="round"' + (has('stroke-linecap') ? '' : ' stroke-linecap="round"') + rest;
  });
}

/* ---------- Faster pictures: drop the definitions a frame never uses ----------
   Every frame is read by the browser as a brand new SVG document, and about half of its text is character parts (hair, gradients, filters) that
   belong to people or places that are not in that frame. Reading that text again for every frame is most of the time an export takes.
   pruneUnusedDefs removes a <defs> child only when its id is not named anywhere else in the picture (url(#id), href="#id"). It is conservative:
   anything it is not sure about stays, and a picture with <style> or script text is returned unchanged. The picture looks exactly the same. */
const REF = /(?:url\(\s*['"]?#|href\s*=\s*["']#)([^)"'\s]+)/g;
function countRefs(s, map, sign) {
  REF.lastIndex = 0;
  let m;
  while ((m = REF.exec(s))) map.set(m[1], (map.get(m[1]) || 0) + sign);
}
/* the end of an opening tag, skipping '>' that sits inside quotes */
function tagEnd(s, from) {
  let q = '';
  for (let i = from; i < s.length; i++) {
    const c = s.charCodeAt(i);
    if (q) { if (c === q) q = ''; } else if (c === 34 || c === 39) q = c; else if (c === 62) return i;
  }
  return -1;
}
/* the children of the defs text between a and b: [{from, to, id}] or null when the text is not what we expect */
function defsChildren(s, a, b) {
  const out = [];
  let p = a;
  while (p < b) {
    const lt = s.indexOf('<', p);
    if (lt < 0 || lt >= b) break;
    if (s.startsWith('<!--', lt)) { const e = s.indexOf('-->', lt); if (e < 0 || e >= b) return null; p = e + 3; continue; }
    const nm = /^<([A-Za-z][\w:.-]*)/.exec(s.slice(lt, lt + 60));
    if (!nm) return null;
    const te = tagEnd(s, lt);
    if (te < 0 || te >= b) return null;
    let to;
    if (s.charCodeAt(te - 1) === 47) to = te + 1;
    else {
      const open = '<' + nm[1], close = '</' + nm[1] + '>';
      let depth = 1, q = te + 1;
      while (depth > 0) {
        const o = s.indexOf(open, q), c = s.indexOf(close, q);
        if (c < 0 || c >= b) return null;
        if (o >= 0 && o < c && /[\s/>]/.test(s[o + open.length] || '')) { const oe = tagEnd(s, o); if (oe < 0) return null; if (s.charCodeAt(oe - 1) !== 47) depth++; q = oe + 1; }
        else { depth--; q = c + close.length; }
      }
      to = q;
    }
    const idm = /\sid\s*=\s*"([^"]+)"|\sid\s*=\s*'([^']+)'/.exec(s.slice(lt, te + 1));
    out.push({ from: lt, to, id: idm ? idm[1] || idm[2] : '' });
    p = to;
  }
  return out;
}
/* where the </name> that closes an element opened just before `from` starts, counting nested elements of the same name; -1 when there is none */
function matchClose(s, from, name) {
  const open = '<' + name, close = '</' + name + '>';
  let depth = 1, q = from;
  while (depth > 0) {
    const o = s.indexOf(open, q), c = s.indexOf(close, q);
    if (c < 0) return -1;
    if (o >= 0 && o < c && /[\s/>]/.test(s[o + open.length] || '')) { const oe = tagEnd(s, o); if (oe < 0) return -1; if (s.charCodeAt(oe - 1) !== 47) depth++; q = oe + 1; }
    else { depth--; if (depth === 0) return c; q = c + close.length; }
  }
  return -1;
}
export function pruneUnusedDefs(svg) {
  if (typeof svg !== 'string' || svg.length < 4000 || svg.indexOf('<defs') < 0) return svg;
  if (svg.indexOf('<style') >= 0 || svg.indexOf('<script') >= 0) return svg;
  let cur = svg;
  for (let pass = 0; pass < 4; pass++) {
    const total = new Map();
    countRefs(cur, total, 1);
    const cuts = [];
    let pos = 0;
    for (;;) {
      const d0 = cur.indexOf('<defs', pos);
      if (d0 < 0) break;
      const ch = cur.charCodeAt(d0 + 5);
      if (!(ch === 62 || ch === 32 || ch === 10 || ch === 9 || ch === 13)) { pos = d0 + 5; continue; }
      const te = tagEnd(cur, d0);
      if (te < 0) return svg;
      const d1 = cur.charCodeAt(te - 1) === 47 ? te : matchClose(cur, te + 1, 'defs');   // a defs inside a defs is kept whole (it is just one child)
      if (d1 < 0) return svg;
      if (cur.charCodeAt(te - 1) !== 47) {
        const kids = defsChildren(cur, te + 1, d1);
        if (!kids) return svg;
        for (const k of kids) {
          if (!k.id) continue;
          const own = new Map();
          countRefs(cur.slice(k.from, k.to), own, 1);
          if ((total.get(k.id) || 0) - (own.get(k.id) || 0) <= 0) cuts.push(k);
        }
      }
      pos = d1 + 7;
    }
    if (!cuts.length) break;
    let out = '', last = 0;
    for (const k of cuts) { out += cur.slice(last, k.from); last = k.to; }
    cur = out + cur.slice(last);
  }
  return cur;
}
