// SOUND EFFECTS THAT BRING THE SCENE TO LIFE (all drawn with the Web Audio API: no sound files, nothing to download).
//
// The narrator says it, the picture shows it, and now it is heard: footsteps while someone walks, a door slam, a creaking door, crying,
// an explosion (with a flash, a fireball and a camera shake), glass, a punch, fire crackling, rain, thunder, wind, a phone ringing, a car engine,
// a honk, a heartbeat, applause... plus a very quiet bed for the place (birds in a forest, crickets at night, traffic in a city, waves at the sea).
//
//  sfxCues(S)         the list of {at, kind, dur, v, cls} for a film. S = {SC, st, total, syncedCaptions?, sync?}. Times come from the captions
//                     (the real word times after voiceover sync), so a sound lands on the word that causes it.
//  renderTrack(S,rate) all of them as two mono tracks {soft, hit} for the export (OfflineAudioContext).
//  mixDucked(narr,tr,rate,level) adds them under the narration: the soft sounds sink while the voice speaks, impacts only dip a little.
//  playCue(ctx,cue)   one sound on a live AudioContext (the preview).
//  prepare(SC)/setTimes(S) the visual half: flash + fireball + shake on an explosion, shake on a slam, crash or punch.
// Quiet on purpose: they sit under the voice and never fight it. No look-behind regex (older iPhones).

const num = (v, d = 0) => (Number.isFinite(+v) ? +v : d);
const cl = (v, a, b) => Math.max(a, Math.min(b, v));

export const LEVELS = { off: 0, soft: 0.6, normal: 1 };
export const DEFAULT_LEVEL = 'normal';
export const levelOf = (v) => (Object.prototype.hasOwnProperty.call(LEVELS, v) ? v : DEFAULT_LEVEL);

const DOORW = '(?:the\\s+|a\\s+|her\\s+|his\\s+|their\\s+|that\\s+)?';
/** [kind, regex, seconds it lasts, loudness 0..1, class] (hit = an impact, soft = everything else, amb = a quiet bed) */
export const RULES = [
  ['boom', /\b(explod\w*|explosions?|blew up|blow up|blows up|blast(?:ed)?|detonat\w*|bombs?)\b/, 2.4, 1, 'hit'],
  ['doorSlam', new RegExp('\\b(slam(?:med|s|ming)?\\s+' + DOORW + 'door|door\\s+(?:slam\\w*|shut|banged)|(?:shut|closed|banged|slammed)\\s+' + DOORW + 'door|door\\s+closed)\\b'), 1.4, 0.95, 'hit'],
  ['doorCreak', new RegExp('\\b(open(?:ed|s|ing)?\\s+' + DOORW + 'door|door\\s+(?:open\\w*|creak\\w*)|creak\\w*|squeak\\w*)\\b'), 1.2, 0.6, 'soft'],
  ['knock', /\b(knock\w*)\b/, 1, 0.7, 'soft'],
  ['run', /\b(ran|runs|running|sprint\w*|rushed|raced|dash\w*|chas\w+|hurried|fled)\b/, 1.8, 0.55, 'soft'],
  ['steps', /\b(walk(?:ed|s|ing)?|stroll\w*|march\w*|tiptoe\w*|crept|creep\w*|footsteps?|wander\w*|paced|stepp?\w*|stomp\w*)\b/, 2.2, 0.5, 'soft'],
  ['cry', /\b(cried|cry|cries|crying|sobb\w*|wept|weep\w*|tears|bawl\w*)\b/, 3, 0.7, 'soft'],
  ['gasp', /\b(gasp\w*)\b/, 0.7, 0.55, 'soft'],
  ['glass', /\b(shatter\w*|smash\w*)\b/, 1.2, 0.8, 'hit'],
  ['crash', /\b(crash\w*|collid\w*|collision|wreck\w*)\b/, 1.4, 0.9, 'hit'],
  ['slap', /\b(slap\w*)\b/, 0.4, 0.7, 'hit'],
  ['punch', /\b(punch\w*|kick\w*|struck|thump\w*|slammed into|smacked|hit him|hit her|hit the)\b/, 0.4, 0.75, 'hit'],
  ['bang', /\b(gunshots?|gun went off|bang\w*|shot at|gunfire)\b/, 1.2, 0.85, 'hit'],
  ['thunder', /\b(thunder\w*|lightning)\b/, 3, 0.7, 'hit'],
  ['fire', /\b(fire|flames?|burn(?:ed|ing|t|s)?|blaze|inferno)\b/, 3.6, 0.5, 'soft'],
  ['rain', /\b(rain\w*|storm\w*|drizzle|downpour)\b/, 4, 0.5, 'soft'],
  ['wind', /\b(wind\w*|breeze|gusts?)\b/, 3.2, 0.45, 'soft'],
  ['ring', /\b(phone rang|phone ring\w*|ringing|rang|doorbell)\b/, 2.4, 0.6, 'soft'],
  ['honk', /\b(honk\w*|horn)\b/, 0.7, 0.6, 'soft'],
  ['screech', /\b(screech\w*|skid\w*)\b/, 0.9, 0.6, 'soft'],
  ['engine', /\b(engine|drove|driving|sped|revved|accelerat\w*)\b/, 2.6, 0.45, 'soft'],
  ['splash', /\b(splash\w*|dived|swam|plunged)\b/, 0.9, 0.65, 'soft'],
  ['crunch', /\b(ate|eating|chew\w*|crunch\w*|munch\w*|nibbl\w*)\b/, 0.9, 0.5, 'soft'],
  ['heartbeat', /\b(heart (?:pound\w*|rac\w*|beat\w*|thump\w*)|heartbeat)\b/, 3.2, 0.55, 'soft'],
  ['clap', /\b(clap\w*|applau\w*|cheer\w*)\b/, 1.8, 0.5, 'soft'],
  ['bell', /\b(bells?|ding)\b/, 1.6, 0.5, 'soft'],
];
/** the place itself: [kind, regex over the scene name, mood and words]. At most one quiet bed per scene. */
export const BEDS = [
  ['rain', /\b(rain\w*|storm\w*|drizzle|downpour)\b/],
  ['waves', /\b(ocean|sea|beach|shore|waves|harbou?r|island)\b/],
  ['birds', /\b(forest|jungle|woods|park|garden|farm|village|meadow|field|morning|birds?)\b/],
  ['crickets', /\b(night|midnight|camp|dusk|moonlit|stars)\b/],
  ['traffic', /\b(city|street|traffic|highway|road|downtown|market|station|airport)\b/],
];
const BED_VOL = 0.55;

const words = (text) => String(text || '').split(/\s+/).filter(Boolean);
/** the second each word of a caption is spoken (real timings when the voiceover was matched, else spread by word length) */
function wordTimes(c) {
  const ws = words(c.text);
  if (Array.isArray(c.wordTimings) && c.wordTimings.length === ws.length) return c.wordTimings.map((w) => num(w.start));
  const a = c.speechFrom != null ? num(c.speechFrom) : num(c.from), b = c.speechTo != null ? num(c.speechTo) : num(c.to);
  const wt = ws.map((w) => w.replace(/[^a-z0-9]/gi, '').length + 2), sum = wt.reduce((x, y) => x + y, 0) || 1;
  let acc = 0; return wt.map((w) => { const t = a + (b - a) * acc / sum; acc += w; return t; });
}
function startsOf(S) {
  if (Array.isArray(S.st) && S.st.length) return S.st;
  let T = 0; return (S.SC || []).map((sc) => { const t = T; T += Math.max(.5, num(sc && sc.duration, 5)); return t; });
}

/** every sound of the film, in order */
export function sfxCues(S) {
  const out = [], SC = (S && S.SC) || [], st = startsOf(S), total = num(S && S.total, st.length ? st[st.length - 1] + 5 : 60);
  const beds = [];
  SC.forEach((sc, i) => {
    if (!sc || typeof sc !== 'object') return;
    const t0 = num(st[i]), end = st[i + 1] != null ? num(st[i + 1]) : total;
    const synced = !!(S.sync && S.syncedCaptions && S.syncedCaptions[i]);
    const caps = (synced ? S.syncedCaptions[i] : sc.captions || []).filter((c) => c && c.text);
    const shift = synced ? 0 : t0;
    for (const c of caps) {
      const raw = String(c.text), low = raw.toLowerCase(), wts = wordTimes(c).map((t) => t + shift);
      // character offset of each word, to turn a match position into a word number
      const offs = []; let p = 0; for (const w of words(low)) { const k = low.indexOf(w, p); offs.push(k); p = k + w.length; }
      for (const [kind, re, dur, v, cls] of RULES) {
        const g = new RegExp(re.source, 'g'); let m;
        while ((m = g.exec(low))) {
          let wi = 0; for (let k = 0; k < offs.length; k++) if (offs[k] <= m.index) wi = k;
          const at = cl(num(wts[wi], c.from + shift), t0, end - 0.05);
          out.push({ at, kind, dur: Math.min(dur, Math.max(.4, end - at)), v, cls, scene: i });
          if (m[0].length === 0) g.lastIndex++;
        }
      }
    }
    // the place: one very quiet bed under the whole scene
    const ctx = (String(sc.name || '') + ' ' + String(sc.mood || '') + ' ' + caps.map((c) => c.text).join(' ')).toLowerCase();
    const hit = BEDS.find(([, re]) => re.test(ctx));
    if (hit && end - t0 > 3) {
      const last = beds[beds.length - 1];
      if (last && last.kind === hit[0] && Math.abs(last.end - t0) < .3) last.end = end; else beds.push({ kind: hit[0], start: t0, end });
    }
  });
  // the same sound twice within a moment is one sound
  out.sort((a, b) => a.at - b.at);
  const kept = [], lastOf = {};
  for (const c of out) {
    const gap = c.kind === 'steps' || c.kind === 'run' ? c.dur * .9 : c.kind === 'cry' || c.kind === 'fire' || c.kind === 'rain' || c.kind === 'wind' || c.kind === 'heartbeat' ? c.dur * .8 : 1.1;
    if (lastOf[c.kind] != null && c.at - lastOf[c.kind] < gap) continue;
    lastOf[c.kind] = c.at; kept.push(c);
  }
  for (const b of beds) kept.push({ at: b.start, kind: b.kind, dur: Math.max(1, b.end - b.start), v: BED_VOL, cls: 'soft', bed: true });
  return kept.sort((a, b) => a.at - b.at);
}

/* ---------------------------------------------------------------- the sounds ---- */
function mulberry(a) { return () => { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
const NB = new WeakMap();
function noiseOf(ctx) {
  let b = NB.get(ctx); if (b) return b;
  const sr = ctx.sampleRate, n = sr * 3, r = mulberry(1234); b = ctx.createBuffer(1, n, sr); const d = b.getChannelData(0);
  for (let i = 0; i < n; i++) d[i] = r() * 2 - 1;
  NB.set(ctx, b); return b;
}
/** each sound is levelled so that, at the same loudness setting, a whisper-quiet sound (crying, wind) is as present as a loud one (a door) */
const NORM = { steps: 1.1, run: 1, doorSlam: .75, doorCreak: 4, knock: .9, cry: 9, gasp: 3.8, boom: .6, glass: 1, crash: .9, punch: .95, slap: 1.1, bang: .6, thunder: 1, fire: .55, rain: 1.6, wind: 4, ring: 1.2, honk: 3, screech: 3.5, engine: 2.5, splash: 1.2, crunch: 2, heartbeat: .8, clap: 3, bell: 1.1, birds: 4, crickets: 3, traffic: 4, waves: 2.5 };
const routed = (ctx, dest, kind) => { const g = ctx.createGain(); g.gain.value = NORM[kind] || 1; g.connect(dest); return g; };
/** the building blocks: a shaped noise burst and a shaped tone, sent to `dest` */
function kit(ctx, dest, rnd) {
  const noise = (t, dur, { type = 'lowpass', f = 800, f2 = null, q = 0.7, peak = 0.5, a = 0.004, d = null } = {}) => {
    const s = ctx.createBufferSource(); s.buffer = noiseOf(ctx); s.loop = true;
    const fl = ctx.createBiquadFilter(); fl.type = type; fl.frequency.setValueAtTime(f, t); fl.Q.value = q;
    if (f2) fl.frequency.exponentialRampToValueAtTime(Math.max(20, f2), t + dur);
    const g = ctx.createGain(); g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(peak, t + a);
    g.gain.exponentialRampToValueAtTime(0.0001, t + Math.max(a + .01, d == null ? dur : d));
    s.connect(fl); fl.connect(g); g.connect(dest); s.start(t, rnd() * 2); s.stop(t + dur + .05);
  };
  const tone = (t, dur, { type = 'sine', f0 = 100, f1 = null, peak = 0.5, a = 0.004, d = null, vib = 0, vibHz = 5.5 } = {}) => {
    const o = ctx.createOscillator(); o.type = type; o.frequency.setValueAtTime(f0, t);
    if (f1) o.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + dur);
    if (vib) { const l = ctx.createOscillator(), lg = ctx.createGain(); l.frequency.value = vibHz; lg.gain.value = vib; l.connect(lg); lg.connect(o.frequency); l.start(t); l.stop(t + dur + .05); }
    const g = ctx.createGain(); g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(peak, t + a);
    g.gain.exponentialRampToValueAtTime(0.0001, t + Math.max(a + .01, d == null ? dur : d));
    o.connect(g); g.connect(dest); o.start(t); o.stop(t + dur + .05);
    return { o, g };
  };
  /** a voiced sound with two vowel resonances (the crying) */
  const voice = (t, dur, f0, f1, peak) => {
    const o = ctx.createOscillator(); o.type = 'sawtooth'; o.frequency.setValueAtTime(f0, t); o.frequency.linearRampToValueAtTime(f1, t + dur);
    const l = ctx.createOscillator(), lg = ctx.createGain(); l.frequency.value = 5.8; lg.gain.value = 7; l.connect(lg); lg.connect(o.frequency); l.start(t); l.stop(t + dur + .05);
    const g = ctx.createGain(); g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(peak, t + .09); g.gain.setValueAtTime(peak, t + dur * .55); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    for (const [fr, qq, gv] of [[780, 7, 1], [1400, 8, .55], [2600, 9, .2]]) { const b = ctx.createBiquadFilter(); b.type = 'bandpass'; b.frequency.value = fr; b.Q.value = qq; const bg = ctx.createGain(); bg.gain.value = gv; o.connect(b); b.connect(bg); bg.connect(g); }
    g.connect(dest); o.start(t); o.stop(t + dur + .05);
  };
  return { noise, tone, voice, rnd };
}
const thud = (k, t, p = 1) => { k.tone(t, .22, { f0: 120, f1: 42, peak: .8 * p, d: .2 }); k.noise(t, .12, { f: 500, peak: .35 * p, d: .1 }); };
const PLAY = {
  steps(k, t, v, dur, o) {
    const gap = o && o.fast ? .27 : .5, n = Math.max(1, Math.floor(dur / gap));
    for (let i = 0; i < n; i++) {
      const tt = t + i * gap + (k.rnd() - .5) * .03, p = v * (i === 0 ? .8 : 1) * (.85 + k.rnd() * .25), f = (i % 2 ? 100 : 118) * (.92 + k.rnd() * .16);
      k.tone(tt, .1, { f0: f, f1: 52, peak: .5 * p, d: .09 }); k.noise(tt, .08, { f: 420, peak: .22 * p, d: .07 }); k.noise(tt + .01, .03, { type: 'bandpass', f: 1500, q: 1, peak: .05 * p, d: .03 });
    }
  },
  run(k, t, v, dur) { PLAY.steps(k, t, v, dur, { fast: true }); },
  doorSlam(k, t, v) {
    k.tone(t, .4, { f0: 95, f1: 36, peak: .95 * v, d: .38 }); k.noise(t, .3, { f: 1000, f2: 200, peak: .6 * v, d: .26 }); k.noise(t, .25, { type: 'bandpass', f: 240, q: 1.2, peak: .5 * v, d: .22 });
    k.noise(t + .03, .03, { type: 'bandpass', f: 3200, q: 3, peak: .25 * v, d: .03 });
    for (let i = 0; i < 6; i++) k.noise(t + .14 + i * .05 + k.rnd() * .02, .04, { type: 'bandpass', f: 1500 + k.rnd() * 800, q: 4, peak: (.16 - i * .02) * v, d: .04 });   // the door rattles in its frame
  },
  doorCreak(k, t, v, dur) {
    const o = k.tone(t, dur, { type: 'sawtooth', f0: 170, f1: 250, peak: .0001, a: .1, d: dur });
    o.g.gain.cancelScheduledValues(t); o.g.gain.setValueAtTime(0.0001, t); o.g.gain.linearRampToValueAtTime(.1 * v, t + .2); o.g.gain.linearRampToValueAtTime(.08 * v, t + dur * .7); o.g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    k.noise(t, dur, { type: 'bandpass', f: 600, f2: 1100, q: 7, peak: .08 * v, a: .15, d: dur });
  },
  knock(k, t, v) { for (let i = 0; i < 3; i++) { const tt = t + i * .2; k.tone(tt, .08, { f0: 210, f1: 120, peak: .55 * v, d: .07 }); k.noise(tt, .05, { type: 'bandpass', f: 900, q: 1.5, peak: .3 * v, d: .05 }); } },
  cry(k, t, v, dur) {
    const n = cl(Math.floor(dur / .62), 2, 5);
    for (let i = 0; i < n; i++) {
      const tt = t + i * .62, base = 330 - i * 12 + k.rnd() * 14;
      k.voice(tt, .46, base * 1.08, base * .82, .13 * v);
      k.noise(tt + .47, .17, { type: 'bandpass', f: 1300, f2: 1900, q: 1.2, peak: .05 * v, a: .06, d: .17 });   // the breath in between
    }
  },
  gasp(k, t, v) { k.noise(t, .34, { type: 'bandpass', f: 900, f2: 2400, q: 1.3, peak: .17 * v, a: .08, d: .34 }); },
  boom(k, t, v) {
    k.noise(t, .07, { type: 'highpass', f: 1800, peak: .55 * v, d: .06 });
    k.tone(t, 1.3, { f0: 150, f1: 28, peak: 1 * v, a: .01, d: 1.2 });
    k.noise(t, 1.7, { f: 3200, f2: 110, peak: .85 * v, a: .01, d: 1.6 });
    k.noise(t + .1, 2.2, { f: 160, f2: 60, peak: .45 * v, a: .25, d: 2.1 });
    for (let i = 0; i < 5; i++) k.noise(t + .5 + i * .22 + k.rnd() * .1, .05, { type: 'highpass', f: 2500, peak: .1 * v, d: .05 });   // debris
  },
  glass(k, t, v) {
    k.noise(t, .4, { type: 'highpass', f: 2600, peak: .4 * v, d: .35 });
    for (let i = 0; i < 16; i++) k.tone(t + k.rnd() * .6, .09, { f0: 2200 + k.rnd() * 4300, peak: .07 * v, d: .08 });
    thud(k, t, .35 * v);
  },
  crash(k, t, v) {
    thud(k, t, v); k.noise(t, .55, { type: 'bandpass', f: 800, f2: 300, q: .8, peak: .55 * v, d: .5 });
    for (let i = 0; i < 4; i++) k.tone(t + .04 + k.rnd() * .35, .25, { type: 'sawtooth', f0: 300 + k.rnd() * 700, f1: 200, peak: .04 * v, d: .22 });
  },
  punch(k, t, v) { thud(k, t, v); },
  slap(k, t, v) { k.noise(t, .06, { type: 'bandpass', f: 2200, q: 1, peak: .65 * v, d: .05 }); thud(k, t, .45 * v); },
  bang(k, t, v) { k.noise(t, .14, { type: 'highpass', f: 1000, peak: .9 * v, d: .12 }); k.tone(t, .35, { f0: 220, f1: 50, peak: .6 * v, d: .3 }); k.noise(t + .02, .5, { f: 1500, f2: 300, peak: .25 * v, d: .45 }); },
  thunder(k, t, v, dur) { k.noise(t, dur, { f: 220, f2: 70, peak: .7 * v, a: .4, d: dur }); k.tone(t + .1, dur, { f0: 55, f1: 32, peak: .4 * v, a: .5, d: dur }); },
  fire(k, t, v, dur) {
    k.noise(t, dur, { f: 900, peak: .06 * v, a: .5, d: dur });
    for (let x = 0; x < dur; x += .045) if (k.rnd() < .33) k.noise(t + x, .03, { type: 'highpass', f: 2600 + k.rnd() * 2000, peak: (.06 + k.rnd() * .2) * v, d: .025 });
  },
  rain(k, t, v, dur) { k.noise(t, dur, { type: 'highpass', f: 1600, peak: .1 * v, a: .6, d: dur }); k.noise(t, dur, { f: 6500, peak: .05 * v, a: .6, d: dur }); },
  wind(k, t, v, dur) { k.noise(t, dur, { type: 'bandpass', f: 380, f2: 620, q: .9, peak: .16 * v, a: Math.min(1, dur / 3), d: dur }); },
  ring(k, t, v) { for (let r = 0; r < 2; r++) for (let b = 0; b < 2; b++) { const tt = t + r * 1.2 + b * .55; k.tone(tt, .4, { f0: 1400, peak: .16 * v, a: .01, d: .4 }); k.tone(tt, .4, { f0: 1750, peak: .1 * v, a: .01, d: .4 }); } },
  honk(k, t, v) { for (const f of [415, 330]) k.tone(t, .45, { type: 'square', f0: f, peak: .07 * v, a: .02, d: .45 }); },
  screech(k, t, v) { k.tone(t, .8, { type: 'sawtooth', f0: 1900, f1: 1000, peak: .05 * v, a: .05, d: .8 }); k.noise(t, .8, { type: 'bandpass', f: 3200, f2: 1800, q: 2, peak: .13 * v, a: .05, d: .8 }); },
  engine(k, t, v, dur) { const o = k.tone(t, dur, { type: 'sawtooth', f0: 46, f1: 66, peak: .13 * v, a: .4, d: dur }); k.noise(t, dur, { f: 240, peak: .12 * v, a: .4, d: dur }); },
  splash(k, t, v) { k.noise(t, .6, { type: 'bandpass', f: 1500, f2: 700, q: .7, peak: .5 * v, d: .55 }); for (let i = 0; i < 6; i++) k.tone(t + .05 + k.rnd() * .5, .07, { f0: 420 + k.rnd() * 300, f1: 900 + k.rnd() * 400, peak: .06 * v, d: .06 }); },
  crunch(k, t, v) { for (let i = 0; i < 4; i++) k.noise(t + i * .14 + k.rnd() * .03, .04, { f: 2600, peak: .3 * v, d: .035 }); },
  heartbeat(k, t, v, dur) { for (let x = 0; x < dur; x += .85) { k.tone(t + x, .13, { f0: 64, f1: 40, peak: .55 * v, d: .12 }); k.tone(t + x + .21, .11, { f0: 56, f1: 38, peak: .4 * v, d: .1 }); } },
  clap(k, t, v, dur) { for (let i = 0; i < Math.round(dur * 6); i++) k.noise(t + i * .17 + k.rnd() * .1, .04, { type: 'bandpass', f: 1500, q: .7, peak: (.14 + k.rnd() * .16) * v, d: .035 }); },
  bell(k, t, v) { k.tone(t, 1.6, { f0: 1318, peak: .2 * v, d: 1.5 }); k.tone(t, 1.2, { f0: 2637, peak: .08 * v, d: 1.1 }); },
  // the place
  birds(k, t, v, dur) { for (let x = 0.4; x < dur - .4; x += .7 + k.rnd() * 1.6) { const f = 2600 + k.rnd() * 1900, n = 2 + Math.floor(k.rnd() * 3); for (let i = 0; i < n; i++) k.tone(t + x + i * .11, .09, { f0: f, f1: f * (k.rnd() < .5 ? 1.25 : .8), peak: .07 * v, a: .01, d: .08 }); } },
  crickets(k, t, v, dur) { for (const f of [4300, 4650]) { const o = k.tone(t, dur, { f0: f, peak: .0001, a: .5, d: dur }); o.g.gain.cancelScheduledValues(t); o.g.gain.setValueAtTime(0.0001, t); o.g.gain.linearRampToValueAtTime(.03 * v, t + .6); o.g.gain.setValueAtTime(.03 * v, Math.max(t + .6, t + dur - .6)); o.g.gain.linearRampToValueAtTime(0.0001, t + dur); } k.noise(t, dur, { type: 'highpass', f: 5200, peak: .02 * v, a: .6, d: dur }); },
  traffic(k, t, v, dur) { k.noise(t, dur, { f: 260, peak: .14 * v, a: .6, d: dur }); for (let x = 1; x < dur - 1; x += 2.5 + k.rnd() * 3) k.noise(t + x, 1.4, { type: 'bandpass', f: 300, f2: 700, q: .8, peak: .08 * v, a: .5, d: 1.4 }); },
  waves(k, t, v, dur) { for (let x = 0; x < dur; x += 5.5) k.noise(t + x, 5, { f: 450, f2: 900, peak: .2 * v, a: 2.2, d: 5 }); },
};
export const __play = (ctx, cue, dest) => { const k = kit(ctx, routed(ctx, dest, cue.kind), mulberry(99)); PLAY[cue.kind](k, cue.at, cue.v, cue.dur, {}); };
export function playCue(ctx, cue, dest, delay = 0) {
  const p = PLAY[cue.kind]; if (!p) return;
  const k = kit(ctx, routed(ctx, dest || ctx.destination, cue.kind), mulberry((cue.seed || Math.round(cue.at * 1000)) + 7));
  try { p(k, ctx.currentTime + Math.max(0, delay), cue.v == null ? 1 : cue.v, cue.dur || 1, {}); } catch (e) { /* a sound that cannot be made is skipped */ }
}

/* ---------------------------------------------------------------- export ---- */
/** two mono tracks {soft, hit} at `rate` for the whole film, or null when the film has no sounds */
export async function renderTrack(S, rate = 48000, Offline = globalThis.OfflineAudioContext) {
  const cues = sfxCues(S); if (!cues.length || !Offline) return null;
  const total = num(S.total, 60), oc = new Offline(2, Math.ceil((total + 3) * rate), rate);
  const merger = oc.createChannelMerger(2), soft = oc.createGain(), hit = oc.createGain();
  soft.connect(merger, 0, 0); hit.connect(merger, 0, 1); merger.connect(oc.destination);
  cues.forEach((c, n) => {
    const p = PLAY[c.kind]; if (!p) return;
    const k = kit(oc, routed(oc, c.cls === 'hit' ? hit : soft, c.kind), mulberry(n * 7919 + 13));
    try { p(k, Math.max(0, c.at), c.v, c.dur, {}); } catch (e) { /* skip */ }
  });
  const buf = await oc.startRendering();
  return { soft: buf.getChannelData(0), hit: buf.getChannelData(1), n: cues.length };
}
/** adds the sounds under the narration in place (a Float32Array mono track at `rate`): the voice ducks the soft sounds, impacts dip a little */
export function mixDucked(narr, tr, rate, level = DEFAULT_LEVEL) {
  const L = LEVELS[levelOf(level)]; if (!narr || !tr || !L) return narr;
  const win = Math.max(1, Math.round(rate * .02)), n = narr.length;
  let env = 0; const atk = 1 - Math.exp(-1 / (rate * .03)), rel = 1 - Math.exp(-1 / (rate * .25));
  const K = .34 * L;
  for (let i = 0; i < n; i += win) {
    let s = 0; const e = Math.min(n, i + win);
    for (let j = i; j < e; j += 4) s += narr[j] * narr[j];
    const r = Math.sqrt(s / Math.max(1, (e - i) / 4));
    for (let j = i; j < e; j++) {
      env += ((r > env ? atk : rel) * win) * (r - env) / win;     // smooth, fast up, slow down
      const speak = cl(env / .06, 0, 1);
      const v = narr[j] + (tr.soft[j] || 0) * K * (1 - .62 * speak) + (tr.hit[j] || 0) * K * (1 - .22 * speak);
      narr[j] = v > 1 ? 1 : v < -1 ? -1 : v;
    }
  }
  return narr;
}

/* ---------------------------------------------------------------- the picture of it ---- */
const VIS = { boom: 1, doorSlam: .35, crash: .5, glass: .3, punch: .3, bang: .35 };
const ez = (u) => { u = cl(u, 0, 1); return 1 - Math.pow(1 - u, 3); };
function fireballProp(sc, tag) {
  const at = () => (sc._fx || []).filter((e) => e.kind === 'boom').map((e) => e.t);
  const part = (u) => u;
  return {
    screen: true, layer: 'front', x: 800, y: 450, _sfx: tag,
    svg: '<g><circle r="330" fill="#ff5a14" opacity=".55"/><circle r="250" fill="#ff9a1f" opacity=".8"/><circle r="165" fill="#ffd54a"/><circle r="85" fill="#fff6d0"/><circle r="380" fill="none" stroke="#fff0c0" stroke-width="14" opacity=".6"/></g>',
    animate: (t) => { let best = null; for (const b of at()) { const u = (t - b) / 1.25; if (u >= 0 && u <= 1) best = u; } if (best == null) return { opacity: 0, scale: .01 }; return { scale: .15 + 1.9 * ez(best), opacity: Math.pow(1 - best, 1.4) * .95 }; },
  };
}
function smokeProp(sc) {
  const at = () => (sc._fx || []).filter((e) => e.kind === 'boom').map((e) => e.t);
  return {
    screen: true, layer: 'front', x: 800, y: 450, _sfx: 'smoke',
    svg: '<g fill="#1b1b1f"><circle cx="-220" cy="40" r="170"/><circle cx="40" cy="-60" r="210"/><circle cx="260" cy="30" r="160"/><circle cx="-60" cy="120" r="190"/></g>',
    animate: (t) => { let best = null; for (const b of at()) { const u = (t - b - .25) / 2.6; if (u >= 0 && u <= 1) best = u; } if (best == null) return { opacity: 0, scale: .01 }; return { scale: .6 + 1.1 * ez(best), y: -120 * best, opacity: Math.sin(Math.PI * Math.min(1, best * 1.15)) * .55 }; },
  };
}
/** The visual half of the sounds: an explosion flashes, shows a fireball and smoke and shakes the camera; a slam, crash or punch gives a small shake. */
export function prepare(SC, S) {
  const res = { booms: 0, shakes: 0 };
  const sx = S || { SC }; if (!sx.SC) sx.SC = SC;
  setTimes(sx);
  SC.forEach((sc) => {
    if (!sc || typeof sc !== 'object' || !(sc._fx && sc._fx.length) || sc._fxWrapped || sc.sfx === false) return;
    sc._fxWrapped = true;
    const hasBoom = sc._fx.some((e) => e.kind === 'boom');
    if (hasBoom) { sc.props = (sc.props || []).concat([smokeProp(sc), fireballProp(sc, 'ball')]); res.booms++; }
    const baseCam = sc.camera, baseFlash = sc.flash;
    sc.camera = (t) => {
      let c = null; try { c = (typeof baseCam === 'function' ? baseCam(t) : baseCam) || null; } catch (e) { c = null; }
      c = c ? { ...c } : { zoom: 1, x: 800, y: 450, rot: 0 };
      let sh = 0; for (const e of sc._fx || []) { const w = VIS[e.kind]; if (!w) continue; const u = (t - e.t) / (e.kind === 'boom' ? .9 : .35); if (u >= 0 && u <= 1) sh = Math.max(sh, w * (1 - u)); }
      if (sh > 0) { c.x = num(c.x, 800) + Math.sin(t * 83) * 16 * sh; c.y = num(c.y, 450) + Math.cos(t * 71) * 12 * sh; }
      return c;
    };
    sc.flash = (t) => {
      let v = 0; try { v = typeof baseFlash === 'function' ? +baseFlash(t) || 0 : 0; } catch (e) { v = 0; }
      for (const e of sc._fx || []) { if (e.kind !== 'boom') continue; const u = (t - e.t) / .4; if (u >= 0 && u <= 1) v = Math.max(v, .9 * (1 - u)); }
      return v;
    };
    res.shakes++;
  });
  return res;
}
/** gives every scene the times (in scene seconds) of the sounds that have a picture; call again after the voiceover is matched */
export function setTimes(S) {
  const cues = sfxCues(S), st = startsOf(S), SC = S.SC || [];
  SC.forEach((sc) => { if (sc && typeof sc === 'object') sc._fx = []; });
  for (const c of cues) { if (!VIS[c.kind]) continue; const sc = SC[c.scene]; if (sc) sc._fx.push({ kind: c.kind, t: Math.max(0, c.at - num(st[c.scene])) }); }
  return cues;
}
