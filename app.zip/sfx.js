// SOUND EFFECTS THAT BRING THE SCENE TO LIFE (all drawn with the Web Audio API: no sound files, nothing to download).
//
// TWO WAYS A FILM GETS ITS SOUNDS
//  1. THE SOUND SCRIPT (preferred): the AI writes it in each beat, tied to the word that causes it:
//        beat({..., say:"She walked in and shut the door.", fx:'steps@"walked" -> doorClose@"shut"'})
//     or a scene's own list: sfx:[{sound:'doorClose', on:'shut'}, {sound:'steps', at:0.4, v:0.5}].  'amb:rain' adds a very quiet bed
//     for the place; fx:'none' keeps a scene silent. As soon as ONE scene of the film has a sound script, ONLY scripted sounds play.
//  2. THE BACKUP (older films, no script): a short list of clear physical phrases ("slammed the door", "footsteps", "burst into tears").
//     Words with other meanings never make a sound ("window" is not wind, "fired from my job" is not fire, "ran out of money" is not
//     running, "search engine" is not a car). No background beds are guessed.
//
// Every sound is mild on purpose: soft attacks, nothing harsh above 7 kHz, and one shared small-room echo so the sounds sit in the same
// space as the picture instead of on top of it. They sink under the narrator's voice (mixDucked).
//
//  sfxCues(S)          the list of {at, kind, dur, v, cls} for a film. S = {SC, st, total, syncedCaptions?, sync?}. Times come from the
//                      captions (the real word times after voiceover sync), so a sound lands on the word that causes it.
//  renderTrack(S,rate) all of them as two mono tracks {soft, hit} for the export (OfflineAudioContext).
//  mixDucked(narr,tr,rate,level) adds them under the narration.
//  playCue(ctx,cue)    one sound on a live AudioContext (the preview).
//  prepare(SC)/setTimes(S) the visual half: flash + fireball + shake on an explosion, shake on a slam, crash or punch.
// No look-behind regex (older iPhones).

const num = (v, d = 0) => (Number.isFinite(+v) ? +v : d);
const cl = (v, a, b) => Math.max(a, Math.min(b, v));

export const LEVELS = { off: 0, soft: 0.6, normal: 1 };
export const DEFAULT_LEVEL = 'normal';
export const levelOf = (v) => (Object.prototype.hasOwnProperty.call(LEVELS, v) ? v : DEFAULT_LEVEL);

const DOORW = '(?:the\\s+|a\\s+|her\\s+|his\\s+|their\\s+|that\\s+|my\\s+|our\\s+|front\\s+|back\\s+)*';
/** THE BACKUP: [kind, regex, seconds it lasts, loudness 0..1, class]. Only phrases that can mean nothing but the sound. */
export const RULES = [
  ['boom', /\b(explod\w*|explosions?|detonat\w*|(?:bomb|grenade)s?\s+(?:went off|exploded)|blew up (?:the|a)\s+(?:car|house|building|bridge|truck))\b/, 2.4, 1, 'hit'],
  ['doorSlam', new RegExp('\\b(slam(?:med|s|ming)?\\s+' + DOORW + 'door|door\\s+slam\\w*|banged\\s+' + DOORW + 'door\\s+shut)\\b'), 1.4, 0.9, 'hit'],
  ['doorClose', new RegExp('\\b((?:shut|closed|closes|closing|shuts)\\s+' + DOORW + 'door|door\\s+(?:shut|closed|clicked shut))\\b'), 1, 0.7, 'soft'],
  ['doorCreak', new RegExp('\\b(open(?:ed|s|ing)?\\s+' + DOORW + 'door|door\\s+(?:creak\\w*|swung open|opened)|creaked open)\\b'), 1.2, 0.55, 'soft'],
  ['knock', new RegExp('\\b(knock(?:ed|s|ing)?\\s+(?:on|at)\\s+' + DOORW + '(?:door|window)|knock,? knock)\\b'), 1, 0.65, 'soft'],
  ['run', /\b(sprint(?:ed|s|ing)?|ran (?:away|off|toward\w*|to the|down the|across|through|into the|after)|running (?:down|through|across|toward\w*|after)|raced (?:down|across|through|toward\w*)|fled)\b/, 1.8, 0.5, 'soft'],
  ['steps', /\b(footsteps?|tiptoe\w*|crept|walk(?:ed|s|ing)? (?:in|into|out|across|down|up|through|over|toward\w*|away|to the|back to|along|around|past)|paced (?:the|back)|stomp(?:ed|ing))\b/, 2.2, 0.45, 'soft'],
  ['cry', /\b(burst into tears|in tears|sobb(?:ed|ing)|wept|weeping|started crying|began to cry|cried (?:herself|himself|quietly|softly|out)|she cried\b(?!\s*out)|he cried\b(?!\s*out))\b/, 3, 0.6, 'soft'],
  ['gasp', /\b(gasp(?:ed|s|ing)?)\b/, 0.7, 0.5, 'soft'],
  ['glass', /\b(shatter(?:ed|s|ing)?|smashed (?:the|a|his|her) (?:glass|window|bottle|vase|mirror|plate))\b/, 1.2, 0.7, 'hit'],
  ['crash', /\b(crashed into|car crash|crashed through|collided with|head-on collision)\b/, 1.4, 0.85, 'hit'],
  ['slap', /\b(slapped (?:him|her|them|me|his|her)|a slap)\b/, 0.4, 0.65, 'hit'],
  ['punch', /\b(punched|kicked (?:him|her|them|the door|me)|threw a punch)\b/, 0.4, 0.7, 'hit'],
  ['bang', /\b(gunshots?|gun went off|gunfire|fired (?:a|the|his|her) (?:gun|pistol|rifle|shot)|shots rang out)\b/, 1.2, 0.8, 'hit'],
  ['thunder', /\b(thunder\w*)\b/, 3, 0.6, 'hit'],
  ['fire', /\b(on fire|in flames|flames|burning (?:house|building|car|room|forest)|bonfire|campfire|fireplace|blaze|inferno|caught fire)\b/, 3.6, 0.45, 'soft'],
  ['rain', /\b(rain(?:ed|ing|drops)?|downpour|drizzl\w*)\b/, 4, 0.45, 'soft'],
  ['wind', /\b(wind (?:howl\w*|blew|whistl\w*|picked up)|howling wind|breeze|gusts? of wind)\b/, 3.2, 0.4, 'soft'],
  ['ring', /\b(phone (?:rang|ringing|rings|buzzed)|doorbell)\b/, 2.4, 0.5, 'soft'],
  ['honk', /\b(honk\w*|car horn)\b/, 0.7, 0.5, 'soft'],
  ['screech', /\b(tires? screech\w*|screeched to a (?:halt|stop)|skidded)\b/, 0.9, 0.5, 'soft'],
  ['engine', /\b(engine (?:roared|started|revved|hummed|purred)|started the (?:car|engine)|drove (?:off|away)|revved)\b/, 2.6, 0.4, 'soft'],
  ['splash', /\b(splash\w*|(?:dove|dived|jumped|fell) into the (?:water|pool|river|lake|sea|ocean))\b/, 0.9, 0.6, 'soft'],
  ['crunch', /\b(crunch\w*|munch\w*|chewing)\b/, 0.9, 0.45, 'soft'],
  ['heartbeat', /\b(heart (?:pound\w*|rac\w*|beat\w* fast|thump\w*)|heartbeat)\b/, 3.2, 0.5, 'soft'],
  ['clap', /\b(applau\w*|clapped|crowd cheered|standing ovation)\b/, 1.8, 0.45, 'soft'],
  ['bell', /\b(bell rang|church bells?|school bell)\b/, 1.6, 0.45, 'soft'],
  ['typing', /\b(typ(?:ed|ing) (?:on|away|fast|furiously)|keyboard clack\w*)\b/, 2, 0.4, 'soft'],
  ['notify', /\b(notification|(?:phone|screen) (?:pinged|lit up|buzzed)|a text came in|got a message)\b/, 1, 0.45, 'soft'],
];
/** quiet beds for a place; only played when the sound script asks for one ('amb:rain') */
export const BEDS = ['room', 'city', 'forest', 'night', 'rain', 'waves', 'wind', 'fire', 'office', 'crowd'];
const BED_VOL = 0.35;
/** what the AI may call a sound -> the sound the app makes */
const ALIAS = {
  steps: 'steps', step: 'steps', footsteps: 'steps', footstep: 'steps', walk: 'steps', walking: 'steps',
  run: 'run', running: 'run', footstepsfast: 'run',
  doorclose: 'doorClose', doorshut: 'doorClose', door: 'doorClose', close: 'doorClose',
  dooropen: 'doorCreak', doorcreak: 'doorCreak', creak: 'doorCreak', open: 'doorCreak',
  doorslam: 'doorSlam', slam: 'doorSlam', knock: 'knock', knocking: 'knock',
  cry: 'cry', sob: 'cry', sniff: 'cry', sniffle: 'cry', crying: 'cry', gasp: 'gasp', breath: 'gasp', sigh: 'sigh',
  glass: 'glass', shatter: 'glass', crash: 'crash', slap: 'slap', punch: 'punch', hit: 'thud', impact: 'thud', thud: 'thud', fall: 'thud', drop: 'thud',
  boom: 'boom', explosion: 'boom', explode: 'boom', bang: 'bang', gunshot: 'bang', shot: 'bang',
  thunder: 'thunder', fire: 'fire', crackle: 'fire', rain: 'rain', wind: 'wind',
  ring: 'ring', phone: 'ring', phonering: 'ring', ringtone: 'ring', notify: 'notify', notification: 'notify', ping: 'notify', message: 'notify', text: 'notify',
  honk: 'honk', horn: 'honk', screech: 'screech', engine: 'engine', car: 'engine', drive: 'engine', cardoor: 'carDoor',
  splash: 'splash', water: 'splash', crunch: 'crunch', eat: 'crunch', chew: 'crunch', heartbeat: 'heartbeat', heart: 'heartbeat',
  clap: 'clap', applause: 'clap', cheer: 'clap', bell: 'bell', ding: 'bell',
  typing: 'typing', keyboard: 'typing', type: 'typing', click: 'click', mouse: 'click', switch: 'click', paper: 'paper', page: 'paper', book: 'paper',
  whoosh: 'whoosh', swoosh: 'whoosh', swish: 'whoosh', sit: 'cloth', cloth: 'cloth', rustle: 'cloth', chair: 'cloth', coin: 'coin', money: 'coin', cash: 'coin',
  pour: 'pour', drink: 'pour', cup: 'cup', mug: 'cup', plate: 'cup', kiss: 'none', laugh: 'none', scream: 'none',
};
/** [seconds it lasts, loudness, class] for a scripted sound */
const KIND = {
  steps: [2.2, .45, 'soft'], run: [1.8, .45, 'soft'], doorClose: [1, .6, 'soft'], doorCreak: [1.2, .5, 'soft'], doorSlam: [1.4, .8, 'hit'],
  knock: [1, .6, 'soft'], cry: [3, .55, 'soft'], gasp: [.7, .45, 'soft'], sigh: [1.2, .4, 'soft'], glass: [1.2, .65, 'hit'], crash: [1.4, .8, 'hit'],
  slap: [.4, .6, 'hit'], punch: [.4, .65, 'hit'], thud: [.5, .55, 'hit'], boom: [2.4, .9, 'hit'], bang: [1.2, .75, 'hit'], thunder: [3, .55, 'hit'],
  fire: [3.6, .4, 'soft'], rain: [4, .4, 'soft'], wind: [3.2, .38, 'soft'], ring: [2.4, .45, 'soft'], notify: [1, .45, 'soft'], honk: [.7, .45, 'soft'],
  screech: [.9, .45, 'soft'], engine: [2.6, .38, 'soft'], carDoor: [.8, .6, 'soft'], splash: [.9, .55, 'soft'], crunch: [.9, .4, 'soft'],
  heartbeat: [3.2, .45, 'soft'], clap: [1.8, .4, 'soft'], bell: [1.6, .4, 'soft'], typing: [2, .38, 'soft'], click: [.3, .45, 'soft'],
  paper: [.9, .4, 'soft'], whoosh: [.6, .35, 'soft'], cloth: [.8, .38, 'soft'], coin: [.8, .4, 'soft'], pour: [1.6, .4, 'soft'], cup: [.5, .45, 'soft'],
};
export const SOUND_NAMES = Object.keys(KIND);
const kindOf = (w) => { const k = String(w || '').toLowerCase().replace(/[^a-z]/g, ''); const a = ALIAS[k] || (KIND[w] ? w : null); return a === 'none' ? null : a; };
const bedOf = (w) => { const k = String(w || '').toLowerCase().replace(/[^a-z]/g, ''); const m = { room: 'room', indoor: 'room', inside: 'room', house: 'room', home: 'room', city: 'city', street: 'city', traffic: 'city', town: 'city', forest: 'forest', park: 'forest', garden: 'forest', birds: 'forest', woods: 'forest', jungle: 'forest', night: 'night', crickets: 'night', rain: 'rain', storm: 'rain', sea: 'waves', ocean: 'waves', beach: 'waves', waves: 'waves', wind: 'wind', desert: 'wind', fire: 'fire', fireplace: 'fire', office: 'office', crowd: 'crowd', party: 'crowd', school: 'crowd', market: 'crowd', restaurant: 'crowd' }; return m[k] || null; };

const words = (text) => String(text || '').split(/\s+/).filter(Boolean);
/** the second each word of a caption is spoken (real timings when the voiceover was matched, else spread by word length) */
function wordTimes(c) {
  const ws = words(c.text);
  if (Array.isArray(c.wordTimings) && c.wordTimings.length === ws.length) return c.wordTimings.map((w) => num(w.start));
  const a = c.speechFrom != null ? num(c.speechFrom) : num(c.from), b = c.speechTo != null ? num(c.speechTo) : num(c.to);
  const wt = ws.map((w) => w.replace(/[^a-z0-9]/gi, '').length + 2), sum = wt.reduce((x, y) => x + y, 0) || 1;
  let acc = 0; return wt.map((w) => { const t = a + (b - a) * acc / sum; acc += w; return t; });
}
function startsOf(S) {
  if (Array.isArray(S.st) && S.st.length) return S.st;
  let T = 0; return (S.SC || []).map((sc) => { const t = T; T += Math.max(.5, num(sc && sc.duration, 5)); return t; });
}
const clean = (w) => String(w || '').toLowerCase().replace(/[^a-z0-9']/g, '');
const scriptOf = (sc) => (sc ? (sc.fx !== undefined ? sc.fx : sc.sfx !== undefined && sc.sfx !== false && sc.sfx !== true ? sc.sfx : sc.sounds !== undefined ? sc.sounds : undefined) : undefined);
/** one item of a sound script -> {kind|bed, word?, at?, v?} */
function parseItem(x) {
  if (x == null) return null;
  if (Array.isArray(x)) return parseItem({ sound: x[0], at: typeof x[1] === 'number' ? x[1] : undefined, on: typeof x[1] === 'string' ? x[1] : undefined, v: x[2] });
  if (typeof x === 'object') {
    const name = x.sound || x.kind || x.fx || x.sfx || x.name || '';
    const amb = x.amb || x.ambience || x.bed;
    if (amb) { const b = bedOf(amb); return b ? { bed: b, v: x.v ?? x.vol } : null; }
    const m = /^\s*(?:amb|ambience|bed)\s*:\s*([a-z]+)/i.exec(String(name)); if (m) { const b = bedOf(m[1]); return b ? { bed: b } : null; }
    const k = kindOf(name); if (!k) return null;
    const on = x.on ?? x.word ?? (typeof x.at === 'string' && isNaN(+x.at) ? x.at : undefined);
    const at = x.at ?? x.t ?? x.time;
    return { kind: k, word: on != null ? String(on).replace(/^["']|["']$/g, '') : undefined, at: on == null && at != null && isFinite(+at) ? +at : undefined, v: x.v ?? x.vol ?? x.volume, dur: x.dur };
  }
  const str = String(x).trim(); if (!str) return null;
  const am = /^(?:amb|ambience|bed)\s*:\s*([a-z]+)/i.exec(str); if (am) { const b = bedOf(am[1]); return b ? { bed: b } : null; }
  // kind(0.4)@"word"  |  kind@1.2  |  kind@word  |  kind
  const m = /^([a-zA-Z][\w-]*)\s*(?:\(\s*([\d.]+)\s*\))?\s*(?:@\s*(?:"([^"]*)"|'([^']*)'|([\d.]+)|([^\s,]+)))?/.exec(str);
  if (!m) return null;
  const k = kindOf(m[1]); if (!k) return null;
  const word = m[3] ?? m[4] ?? m[6];
  return { kind: k, v: m[2] != null ? +m[2] : undefined, word: word != null ? word : undefined, at: m[5] != null ? +m[5] : undefined };
}
function parseScript(v) {
  if (v == null || v === false) return [];
  if (typeof v === 'string') { if (/^\s*(none|silent|silence|off|no)\s*$/i.test(v)) return []; return v.split(/->|→|,|;|\|/).map(parseItem).filter(Boolean); }
  if (Array.isArray(v)) return v.map(parseItem).filter(Boolean);
  if (typeof v === 'object') return [parseItem(v)].filter(Boolean);
  return [];
}

/** every sound of the film, in order */
export function sfxCues(S) {
  const out = [], SC = (S && S.SC) || [], st = startsOf(S), total = num(S && S.total, st.length ? st[st.length - 1] + 5 : 60);
  const beds = [];
  const scripted = SC.some((sc) => scriptOf(sc) !== undefined);
  SC.forEach((sc, i) => {
    if (!sc || typeof sc !== 'object') return;
    const t0 = num(st[i]), end = st[i + 1] != null ? num(st[i + 1]) : total;
    const synced = !!(S.sync && S.syncedCaptions && S.syncedCaptions[i]);
    const caps = (synced ? S.syncedCaptions[i] : sc.captions || []).filter((c) => c && c.text);
    const shift = synced ? 0 : t0;
    if (scripted) {
      // the words of the scene with the second each one is spoken
      const ws = []; for (const c of caps) { const t = wordTimes(c), w = words(c.text); w.forEach((x, k) => ws.push({ w: clean(x), t: num(t[k], c.from) + shift })); }
      const used = new Set();
      for (const it of parseScript(scriptOf(sc))) {
        if (it.bed) { if (end - t0 > 1.5) { const last = beds[beds.length - 1]; if (last && last.kind === it.bed && Math.abs(last.end - t0) < .3) last.end = end; else beds.push({ kind: it.bed, start: t0, end, v: it.v }); } continue; }
        const [d0, v0, cls] = KIND[it.kind];
        let at = t0 + .15;
        if (it.word) {
          const target = clean(it.word.split(/\s+/)[0]);
          let k = ws.findIndex((x, j) => !used.has(j) && x.w && (x.w === target || (target.length > 3 && x.w.startsWith(target))));
          if (k < 0) k = ws.findIndex((x) => x.w && target && x.w.indexOf(target) >= 0);
          if (k >= 0) { used.add(k); at = ws[k].t; }
        } else if (it.at != null) at = t0 + Math.max(0, it.at);
        at = cl(at, t0, Math.max(t0, end - .05));
        const v = cl(it.v != null && isFinite(+it.v) ? +it.v : v0, .05, 1);
        out.push({ at, kind: it.kind, dur: Math.min(it.dur ? num(it.dur, d0) : d0, Math.max(.4, end - at)), v, cls, scene: i });
      }
      return;
    }
    for (const c of caps) {
      const raw = String(c.text), low = raw.toLowerCase(), wts = wordTimes(c).map((t) => t + shift);
      const offs = []; let p = 0; for (const w of words(low)) { const k = low.indexOf(w, p); offs.push(k); p = k + w.length; }
      for (const [kind, re, dur, v, cls] of RULES) {
        const g = new RegExp(re.source, 'g'); let m;
        while ((m = g.exec(low))) {
          let wi = 0; for (let k = 0; k < offs.length; k++) if (offs[k] <= m.index) wi = k;
          // the sound lands on the verb at the end of the phrase ("shut the door" -> on "door" is late; on the first word is right)
          const at = cl(num(wts[wi], c.from + shift), t0, end - 0.05);
          out.push({ at, kind, dur: Math.min(dur, Math.max(.4, end - at)), v: v * .85, cls, scene: i });
          if (m[0].length === 0) g.lastIndex++;
        }
      }
    }
  });
  // the same sound twice within a moment is one sound
  out.sort((a, b) => a.at - b.at);
  const kept = [], lastOf = {};
  for (const c of out) {
    const gap = c.kind === 'steps' || c.kind === 'run' ? c.dur * .9 : c.kind === 'cry' || c.kind === 'fire' || c.kind === 'rain' || c.kind === 'wind' || c.kind === 'heartbeat' || c.kind === 'typing' ? c.dur * .8 : .9;
    if (lastOf[c.kind] != null && c.at - lastOf[c.kind] < gap) continue;
    lastOf[c.kind] = c.at; kept.push(c);
  }
  for (const b of beds) kept.push({ at: b.start, kind: b.kind, dur: Math.max(1, b.end - b.start), v: cl(b.v != null ? +b.v : BED_VOL, .05, .6), cls: 'soft', bed: true });
  return kept.sort((a, b) => a.at - b.at);
}

/* ---------------------------------------------------------------- the sounds ---- */
function mulberry(a) { return () => { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
const NB = new WeakMap(), BB = new WeakMap(), IR = new WeakMap();
function noiseOf(ctx) {
  let b = NB.get(ctx); if (b) return b;
  const sr = ctx.sampleRate, n = sr * 3, r = mulberry(1234); b = ctx.createBuffer(1, n, sr); const d = b.getChannelData(0);
  for (let i = 0; i < n; i++) d[i] = r() * 2 - 1;
  NB.set(ctx, b); return b;
}
/** brown noise: deep and soft, the base of rooms, distant cities and wind (white noise sounds like hiss) */
function brownOf(ctx) {
  let b = BB.get(ctx); if (b) return b;
  const sr = ctx.sampleRate, n = sr * 4, r = mulberry(4321); b = ctx.createBuffer(1, n, sr); const d = b.getChannelData(0);
  let last = 0; for (let i = 0; i < n; i++) { last = (last + .02 * (r() * 2 - 1)) / 1.02; d[i] = last * 3.5; }
  BB.set(ctx, b); return b;
}
/** a small, soft room: the shared echo that makes every sound sit in the same space as the picture */
function roomOf(ctx) {
  let b = IR.get(ctx); if (b) return b;
  const sr = ctx.sampleRate, n = Math.round(sr * 1.1), r = mulberry(777); b = ctx.createBuffer(1, n, sr); const d = b.getChannelData(0);
  let lp = 0; for (let i = 0; i < n; i++) { const t = i / sr; lp += .25 * ((r() * 2 - 1) - lp); d[i] = lp * Math.exp(-t * 5.2) * (t < .012 ? t / .012 : 1); }
  IR.set(ctx, b); return b;
}
/** the blend bus: takes the harsh top off, adds a little of the room, gently evens out loud moments */
function busOf(ctx, dest) {
  const inp = ctx.createGain(), hs = ctx.createBiquadFilter(), lp = ctx.createBiquadFilter(), dry = ctx.createGain(), wet = ctx.createGain(), comp = ctx.createDynamicsCompressor();
  hs.type = 'highshelf'; hs.frequency.value = 5000; hs.gain.value = -5;
  lp.type = 'lowpass'; lp.frequency.value = 9000; lp.Q.value = .5;
  dry.gain.value = .86; wet.gain.value = .24;
  comp.threshold.value = -18; comp.knee.value = 12; comp.ratio.value = 3; comp.attack.value = .01; comp.release.value = .25;
  inp.connect(hs); hs.connect(lp); lp.connect(dry); dry.connect(comp);
  try { const cv = ctx.createConvolver(); cv.normalize = true; cv.buffer = roomOf(ctx); lp.connect(cv); cv.connect(wet); wet.connect(comp); } catch (e) { /* no echo on this browser */ }
  comp.connect(dest);
  return inp;
}
/** each sound is levelled so that, at the same loudness setting, a quiet sound (a sniff, wind) is as present as a loud one (a door) */
const NORM = { steps: 1.6, run: 1.4, doorClose: 1.3, doorCreak: 2.6, doorSlam: .7, knock: .9, cry: 3.4, gasp: 3, sigh: 3, boom: .55, glass: .9, crash: .8, punch: .9, slap: 1, thud: 1.1, bang: .55, thunder: .9, fire: .6, rain: 1.3, wind: 2.6, ring: 1, notify: 1.2, honk: 2.2, screech: 2.4, engine: 2, carDoor: 1.2, splash: 1.1, crunch: 1.8, heartbeat: .8, clap: 2.4, bell: 1, typing: 1.6, click: 1.5, paper: 2.2, whoosh: 1.6, cloth: 2.4, coin: 1, pour: 1.8, cup: 1.2,
  room: 1.6, city: 1.4, forest: 1.5, night: 1.6, waves: 1.1, office: 1.4, crowd: 1.6 };
const routed = (ctx, dest, kind) => { const g = ctx.createGain(); g.gain.value = NORM[kind] || 1; g.connect(dest); return g; };
/** the building blocks: a shaped noise burst and a shaped tone, sent to `dest` */
function kit(ctx, dest, rnd) {
  const noise = (t, dur, { type = 'lowpass', f = 800, f2 = null, q = 0.7, peak = 0.5, a = 0.006, d = null, brown = false } = {}) => {
    const s = ctx.createBufferSource(); s.buffer = brown ? brownOf(ctx) : noiseOf(ctx); s.loop = true;
    const fl = ctx.createBiquadFilter(); fl.type = type; fl.frequency.setValueAtTime(f, t); fl.Q.value = q;
    if (f2) fl.frequency.exponentialRampToValueAtTime(Math.max(20, f2), t + dur);
    const g = ctx.createGain(); g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(peak, t + a);
    g.gain.exponentialRampToValueAtTime(0.0001, t + Math.max(a + .01, d == null ? dur : d));
    s.connect(fl); fl.connect(g); g.connect(dest); s.start(t, rnd() * 2); s.stop(t + dur + .05);
    return { s, fl, g };
  };
  const tone = (t, dur, { type = 'sine', f0 = 100, f1 = null, peak = 0.5, a = 0.006, d = null, vib = 0, vibHz = 5.5 } = {}) => {
    const o = ctx.createOscillator(); o.type = type; o.frequency.setValueAtTime(f0, t);
    if (f1) o.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + dur);
    if (vib) { const l = ctx.createOscillator(), lg = ctx.createGain(); l.frequency.value = vibHz; lg.gain.value = vib; l.connect(lg); lg.connect(o.frequency); l.start(t); l.stop(t + dur + .05); }
    const g = ctx.createGain(); g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(peak, t + a);
    g.gain.exponentialRampToValueAtTime(0.0001, t + Math.max(a + .01, d == null ? dur : d));
    o.connect(g); g.connect(dest); o.start(t); o.stop(t + dur + .05);
    return { o, g };
  };
  /** a steady sound that fades in and out (beds, rain, fire): `env` seconds of fade at each end */
  const bed = (t, dur, opt, env = 1.2) => {
    const e = Math.min(env, dur / 3), n = noise(t, dur, { ...opt, a: e, d: dur });
    n.g.gain.cancelScheduledValues(t); n.g.gain.setValueAtTime(0.0001, t); n.g.gain.linearRampToValueAtTime(opt.peak, t + e);
    n.g.gain.setValueAtTime(opt.peak, t + dur - e); n.g.gain.linearRampToValueAtTime(0.0001, t + dur);
    return n;
  };
  return { noise, tone, bed, rnd };
}
/** a soft body impact: low and short, no "boing" */
const thud = (k, t, p = 1) => { k.noise(t, .2, { f: 260, f2: 90, peak: .7 * p, d: .18, brown: true }); k.tone(t, .16, { f0: 90, f1: 48, peak: .35 * p, d: .14 }); };
/** one footstep: heel then toe, both soft noise (a real step has no pitch) */
const step = (k, tt, p, hard = 1) => {
  k.noise(tt, .09, { f: 340 * hard, peak: .55 * p, d: .08, brown: true });
  k.noise(tt + .045, .06, { type: 'bandpass', f: 900 + k.rnd() * 300, q: 1.1, peak: .14 * p, d: .05 });
  k.noise(tt + .05, .05, { type: 'bandpass', f: 2600, q: .9, peak: .03 * p, d: .04 });
};
const PLAY = {
  steps(k, t, v, dur, o) {
    const gap = o && o.fast ? .3 : .52, n = cl(Math.floor(dur / gap), 1, 10);
    for (let i = 0; i < n; i++) {
      const tt = t + i * gap + (k.rnd() - .5) * .04, fade = i === 0 ? .7 : i >= n - 1 ? .75 : 1;
      step(k, tt, v * fade * (.8 + k.rnd() * .3), o && o.fast ? 1.25 : 1);
    }
  },
  run(k, t, v, dur) { PLAY.steps(k, t, v, dur, { fast: true }); },
  doorClose(k, t, v) {
    k.noise(t, .22, { f: 220, f2: 80, peak: .6 * v, d: .2, brown: true });                    // the door meets the frame
    k.noise(t + .005, .04, { type: 'bandpass', f: 2300, q: 3, peak: .2 * v, d: .03 });           // the latch clicks
    k.tone(t, .12, { f0: 130, f1: 70, peak: .18 * v, d: .1 });
  },
  doorCreak(k, t, v, dur) {
    k.noise(t, .04, { type: 'bandpass', f: 2100, q: 3, peak: .14 * v, d: .03 });                // the handle
    const d = Math.min(dur, 1.1), o = k.tone(t + .08, d, { type: 'triangle', f0: 190, f1: 260, peak: .0001, a: .1, d, vib: 6, vibHz: 9 });
    o.g.gain.cancelScheduledValues(t + .08); o.g.gain.setValueAtTime(0.0001, t + .08); o.g.gain.linearRampToValueAtTime(.05 * v, t + .3); o.g.gain.exponentialRampToValueAtTime(0.0001, t + .08 + d);
    k.noise(t + .08, d, { type: 'bandpass', f: 700, f2: 1000, q: 5, peak: .05 * v, a: .2, d });
  },
  doorSlam(k, t, v) {
    k.noise(t, .35, { f: 300, f2: 70, peak: .9 * v, d: .32, brown: true }); k.tone(t, .3, { f0: 85, f1: 38, peak: .5 * v, d: .28 });
    k.noise(t, .05, { type: 'bandpass', f: 1800, q: 1.5, peak: .22 * v, d: .04 });
    for (let i = 0; i < 3; i++) k.noise(t + .12 + i * .06, .04, { type: 'bandpass', f: 1200 + k.rnd() * 500, q: 3, peak: (.06 - i * .015) * v, d: .04 });
  },
  knock(k, t, v) { for (let i = 0; i < 3; i++) { const tt = t + i * .22 + (k.rnd() - .5) * .02; k.noise(tt, .09, { f: 420, peak: .5 * v, d: .08, brown: true }); k.noise(tt, .03, { type: 'bandpass', f: 1300, q: 1.5, peak: .14 * v, d: .03 }); } },
  /** crying = soft sniffles and a shaky breath (a synthetic "voice" crying sounded fake) */
  cry(k, t, v, dur) {
    const n = cl(Math.round(dur / .9), 2, 4);
    for (let i = 0; i < n; i++) {
      const tt = t + i * (.75 + k.rnd() * .35);
      k.noise(tt, .16, { type: 'bandpass', f: 2200 + k.rnd() * 600, q: 2.2, peak: .12 * v, a: .07, d: .16 });
      k.noise(tt + .2, .12, { type: 'bandpass', f: 2600, q: 2.2, peak: .08 * v, a: .05, d: .12 });
      const br = k.noise(tt + .4, .5, { type: 'bandpass', f: 900, q: 1.1, peak: .07 * v, a: .1, d: .5 });
      br.g.gain.setValueAtTime(.07 * v, tt + .5); br.g.gain.linearRampToValueAtTime(.03 * v, tt + .56); br.g.gain.linearRampToValueAtTime(.06 * v, tt + .62);
    }
  },
  gasp(k, t, v) { k.noise(t, .32, { type: 'bandpass', f: 1100, f2: 2000, q: 1.2, peak: .14 * v, a: .07, d: .32 }); },
  sigh(k, t, v) { k.noise(t, 1, { type: 'bandpass', f: 700, f2: 450, q: 1, peak: .1 * v, a: .18, d: 1 }); },
  boom(k, t, v) {
    k.noise(t, .06, { type: 'bandpass', f: 1600, q: .8, peak: .3 * v, d: .05 });
    k.tone(t, 1.2, { f0: 110, f1: 30, peak: .8 * v, a: .01, d: 1.1 });
    k.noise(t, 1.8, { f: 1500, f2: 90, peak: .8 * v, a: .01, d: 1.7, brown: true });
    k.noise(t + .1, 2.2, { f: 140, f2: 50, peak: .45 * v, a: .3, d: 2.1, brown: true });
    for (let i = 0; i < 4; i++) k.noise(t + .5 + i * .25 + k.rnd() * .1, .05, { type: 'bandpass', f: 1800, q: 1, peak: .05 * v, d: .05 });
  },
  glass(k, t, v) {
    k.noise(t, .35, { type: 'bandpass', f: 3500, q: .8, peak: .25 * v, d: .3 });
    for (let i = 0; i < 10; i++) k.tone(t + k.rnd() * .5, .08, { f0: 2400 + k.rnd() * 2600, peak: .035 * v, d: .07 });
    thud(k, t, .3 * v);
  },
  crash(k, t, v) { thud(k, t, v); k.noise(t, .55, { type: 'bandpass', f: 700, f2: 280, q: .8, peak: .45 * v, d: .5 }); for (let i = 0; i < 3; i++) k.noise(t + .1 + k.rnd() * .3, .06, { type: 'bandpass', f: 1500 + k.rnd() * 800, q: 2, peak: .08 * v, d: .05 }); },
  punch(k, t, v) { thud(k, t, v); k.noise(t, .04, { type: 'bandpass', f: 1400, q: 1, peak: .12 * v, d: .035 }); },
  slap(k, t, v) { k.noise(t, .05, { type: 'bandpass', f: 2000, q: 1, peak: .45 * v, d: .045 }); thud(k, t, .35 * v); },
  thud(k, t, v) { thud(k, t, v); },
  bang(k, t, v) { k.noise(t, .1, { type: 'bandpass', f: 1500, q: .6, peak: .7 * v, d: .09 }); k.tone(t, .3, { f0: 160, f1: 45, peak: .45 * v, d: .26 }); k.noise(t + .02, .9, { f: 900, f2: 200, peak: .2 * v, d: .85, brown: true }); },
  thunder(k, t, v, dur) { k.noise(t, dur, { f: 200, f2: 60, peak: .75 * v, a: .5, d: dur, brown: true }); k.noise(t + .3, dur * .7, { f: 500, f2: 120, peak: .25 * v, a: .2, d: dur * .7, brown: true }); },
  fire(k, t, v, dur) {
    k.bed(t, dur, { f: 700, peak: .12 * v, brown: true }, .8);
    for (let x = .2; x < dur - .2; x += .06) if (k.rnd() < .28) k.noise(t + x, .025, { type: 'bandpass', f: 1800 + k.rnd() * 1800, q: 1.5, peak: (.03 + k.rnd() * .09) * v, d: .02 });
  },
  rain(k, t, v, dur) { k.bed(t, dur, { type: 'bandpass', f: 2200, q: .4, peak: .1 * v }, 1.5); k.bed(t, dur, { f: 500, peak: .1 * v, brown: true }, 1.5); },
  wind(k, t, v, dur) { const n = k.bed(t, dur, { type: 'bandpass', f: 420, f2: 650, q: .8, peak: .2 * v, brown: true }, Math.min(1.5, dur / 3)); n.fl.Q.setValueAtTime(.8, t); },
  ring(k, t, v) { for (let r = 0; r < 2; r++) { const tt = t + r * 1.1; for (const [f, p] of [[880, .1], [1320, .05]]) k.tone(tt, .5, { f0: f, peak: p * v, a: .015, d: .5, vib: 3, vibHz: 18 }); } },
  notify(k, t, v) { k.tone(t, .35, { f0: 988, peak: .1 * v, a: .01, d: .35 }); k.tone(t + .11, .5, { f0: 1319, peak: .08 * v, a: .01, d: .5 }); },
  honk(k, t, v) { for (const f of [415, 349]) k.tone(t, .4, { type: 'triangle', f0: f, peak: .08 * v, a: .03, d: .4 }); },
  screech(k, t, v) { k.noise(t, .8, { type: 'bandpass', f: 2600, f2: 1600, q: 3, peak: .1 * v, a: .06, d: .8 }); },
  engine(k, t, v, dur) { const o = k.tone(t, dur, { type: 'sawtooth', f0: 42, f1: 58, peak: .0001, a: .6, d: dur }); o.g.gain.cancelScheduledValues(t); o.g.gain.setValueAtTime(.0001, t); o.g.gain.linearRampToValueAtTime(.05 * v, t + .6); o.g.gain.linearRampToValueAtTime(.0001, t + dur); k.bed(t, dur, { f: 220, peak: .14 * v, brown: true }, .6); },
  carDoor(k, t, v) { k.noise(t, .25, { f: 260, f2: 90, peak: .6 * v, d: .22, brown: true }); k.noise(t, .04, { type: 'bandpass', f: 1600, q: 2, peak: .15 * v, d: .035 }); },
  splash(k, t, v) { k.noise(t, .6, { type: 'bandpass', f: 1300, f2: 600, q: .7, peak: .4 * v, d: .55 }); for (let i = 0; i < 5; i++) k.noise(t + .1 + k.rnd() * .4, .05, { type: 'bandpass', f: 1500 + k.rnd() * 900, q: 4, peak: .05 * v, d: .045 }); },
  crunch(k, t, v) { for (let i = 0; i < 4; i++) k.noise(t + i * .16 + k.rnd() * .03, .04, { type: 'bandpass', f: 2200, q: 1, peak: .2 * v, d: .035 }); },
  heartbeat(k, t, v, dur) { for (let x = 0; x < dur; x += .85) { k.noise(t + x, .12, { f: 120, peak: .7 * v, d: .11, brown: true }); k.noise(t + x + .22, .1, { f: 110, peak: .5 * v, d: .09, brown: true }); } },
  clap(k, t, v, dur) { for (let i = 0; i < Math.round(dur * 7); i++) k.noise(t + i * .14 + k.rnd() * .1, .04, { type: 'bandpass', f: 1300 + k.rnd() * 500, q: .8, peak: (.08 + k.rnd() * .1) * v, d: .035 }); },
  bell(k, t, v) { k.tone(t, 1.6, { f0: 1046, peak: .12 * v, d: 1.5 }); k.tone(t, 1.2, { f0: 2093, peak: .03 * v, d: 1.1 }); },
  typing(k, t, v, dur) { for (let x = 0; x < dur - .1; x += .08 + k.rnd() * .12) { k.noise(t + x, .03, { type: 'bandpass', f: 2000 + k.rnd() * 1200, q: 2, peak: (.06 + k.rnd() * .05) * v, d: .025 }); if (k.rnd() < .5) k.noise(t + x, .03, { f: 400, peak: .1 * v, d: .025, brown: true }); } },
  click(k, t, v) { k.noise(t, .03, { type: 'bandpass', f: 2400, q: 3, peak: .2 * v, d: .025 }); },
  paper(k, t, v, dur) { for (let x = 0; x < Math.min(dur, .9); x += .07) if (k.rnd() < .6) k.noise(t + x, .09, { type: 'bandpass', f: 3000 + k.rnd() * 1500, q: .8, peak: (.03 + k.rnd() * .05) * v, a: .02, d: .09 }); },
  whoosh(k, t, v, dur) { k.noise(t, dur, { type: 'bandpass', f: 350, f2: 1400, q: 1.3, peak: .12 * v, a: dur * .55, d: dur }); },
  cloth(k, t, v, dur) { k.noise(t, Math.min(dur, .7), { type: 'bandpass', f: 1200, f2: 800, q: .7, peak: .08 * v, a: .1, d: Math.min(dur, .7) }); },
  coin(k, t, v) { for (let i = 0; i < 3; i++) k.tone(t + i * .09 + k.rnd() * .03, .4, { f0: 3100 + k.rnd() * 900, peak: .04 * v, d: .35 }); },
  pour(k, t, v, dur) { k.bed(t, Math.min(dur, 1.6), { type: 'bandpass', f: 900, f2: 1600, q: 2, peak: .09 * v }, .25); },
  cup(k, t, v) { k.tone(t, .25, { f0: 1700, peak: .05 * v, d: .22 }); k.noise(t, .05, { f: 500, peak: .2 * v, d: .045, brown: true }); },
  // BEDS (only when the sound script asks: amb:rain): very quiet, steady, faded in and out
  room(k, t, v, dur) { k.bed(t, dur, { f: 180, peak: .08 * v, brown: true }, 1.5); },
  city(k, t, v, dur) { k.bed(t, dur, { f: 320, peak: .14 * v, brown: true }, 2); for (let x = 2; x < dur - 2; x += 4 + k.rnd() * 5) k.noise(t + x, 2.4, { f: 380, f2: 600, peak: .05 * v, a: 1, d: 2.4, brown: true }); },
  office(k, t, v, dur) { PLAY.room(k, t, v, dur); for (let x = 1.5; x < dur - 1; x += 2 + k.rnd() * 4) PLAY.typing(k, t + x, v * .35, .8); },
  crowd(k, t, v, dur) { k.bed(t, dur, { type: 'bandpass', f: 520, q: .9, peak: .12 * v, brown: true }, 1.5); k.bed(t, dur, { type: 'bandpass', f: 1100, q: 1.5, peak: .03 * v }, 1.5); },
  forest(k, t, v, dur) {
    k.bed(t, dur, { f: 520, peak: .07 * v, brown: true }, 2);
    for (let x = 1 + k.rnd(); x < dur - 1; x += 2.5 + k.rnd() * 4) { const f = 2300 + k.rnd() * 1300, n = 2 + Math.floor(k.rnd() * 2); for (let i = 0; i < n; i++) k.tone(t + x + i * .13, .1, { f0: f, f1: f * 1.18, peak: .018 * v, a: .02, d: .09 }); }
  },
  night(k, t, v, dur) {
    for (let x = .5; x < dur - .5; x += .9 + k.rnd() * .5) for (let i = 0; i < 3; i++) k.noise(t + x + i * .045, .03, { type: 'bandpass', f: 4300, q: 12, peak: .05 * v, a: .008, d: .028 });
    k.bed(t, dur, { f: 260, peak: .05 * v, brown: true }, 2);
  },
  waves(k, t, v, dur) { for (let x = 0; x < dur; x += 5) { const w = k.noise(t + x, 5, { f: 380, f2: 750, peak: .0001, a: 2, d: 5, brown: true }); w.g.gain.cancelScheduledValues(t + x); w.g.gain.setValueAtTime(.0001, t + x); w.g.gain.linearRampToValueAtTime(.18 * v, t + x + 2.2); w.g.gain.linearRampToValueAtTime(.0001, t + x + 5); } },
};
export const __play = (ctx, cue, dest) => { const k = kit(ctx, routed(ctx, dest, cue.kind), mulberry(99)); PLAY[cue.kind](k, cue.at, cue.v, cue.dur, {}); };
const LIVEBUS = new WeakMap();
export function playCue(ctx, cue, dest, delay = 0) {
  const p = PLAY[cue.kind]; if (!p) return;
  const out = dest || ctx.destination;
  let m = LIVEBUS.get(ctx); if (!m) { m = new Map(); LIVEBUS.set(ctx, m); }
  let bus = m.get(out); if (!bus) { bus = busOf(ctx, out); m.set(out, bus); }
  const k = kit(ctx, routed(ctx, bus, cue.kind), mulberry((cue.seed || Math.round(cue.at * 1000)) + 7));
  try { p(k, ctx.currentTime + Math.max(0, delay), cue.v == null ? 1 : cue.v, cue.dur || 1, {}); } catch (e) { /* a sound that cannot be made is skipped */ }
}

/* ---------------------------------------------------------------- export ---- */
/** two mono tracks {soft, hit} at `rate` for the whole film, or null when the film has no sounds */
export async function renderTrack(S, rate = 48000, Offline = globalThis.OfflineAudioContext) {
  const cues = sfxCues(S); if (!cues.length || !Offline) return null;
  const total = num(S.total, 60), oc = new Offline(2, Math.ceil((total + 3) * rate), rate);
  const merger = oc.createChannelMerger(2), soft = oc.createGain(), hit = oc.createGain();
  soft.connect(merger, 0, 0); hit.connect(merger, 0, 1); merger.connect(oc.destination);
  const busS = busOf(oc, soft), busH = busOf(oc, hit);
  cues.forEach((c, n) => {
    const p = PLAY[c.kind]; if (!p) return;
    const k = kit(oc, routed(oc, c.cls === 'hit' ? busH : busS, c.kind), mulberry(n * 7919 + 13));
    try { p(k, Math.max(0, c.at), c.v, c.dur, {}); } catch (e) { /* skip */ }
  });
  const buf = await oc.startRendering();
  return { soft: buf.getChannelData(0), hit: buf.getChannelData(1), n: cues.length };
}
/** adds the sounds under the narration in place (a Float32Array mono track at `rate`): the voice ducks the soft sounds, impacts dip a little */
export function mixDucked(narr, tr, rate, level = DEFAULT_LEVEL) {
  const L = LEVELS[levelOf(level)]; if (!narr || !tr || !L) return narr;
  const win = Math.max(1, Math.round(rate * .02)), n = narr.length;
  let env = 0; const atk = 1 - Math.exp(-1 / (rate * .03)), rel = 1 - Math.exp(-1 / (rate * .25));
  const K = 1.05 * L;   // the effects sit about 12-15 dB under a normal voice: heard clearly, never louder than the words
  for (let i = 0; i < n; i += win) {
    let s = 0; const e = Math.min(n, i + win);
    for (let j = i; j < e; j += 4) s += narr[j] * narr[j];
    const r = Math.sqrt(s / Math.max(1, (e - i) / 4));
    for (let j = i; j < e; j++) {
      env += ((r > env ? atk : rel) * win) * (r - env) / win;     // smooth, fast up, slow down
      const speak = cl(env / .06, 0, 1);
      const v = narr[j] + (tr.soft[j] || 0) * K * (1 - .62 * speak) + (tr.hit[j] || 0) * K * (1 - .22 * speak);
      narr[j] = v > 1 ? 1 : v < -1 ? -1 : v;
    }
  }
  return narr;
}

/* ---------------------------------------------------------------- the picture of it ---- */
const VIS = { boom: 1, doorSlam: .35, crash: .5, glass: .3, punch: .3, bang: .35 };
const ez = (u) => { u = cl(u, 0, 1); return 1 - Math.pow(1 - u, 3); };
function fireballProp(sc, tag) {
  const at = () => (sc._fx || []).filter((e) => e.kind === 'boom').map((e) => e.t);
  const part = (u) => u;
  return {
    screen: true, layer: 'front', x: 800, y: 450, _sfx: tag,
    svg: '<g><circle r="330" fill="#ff5a14" opacity=".55"/><circle r="250" fill="#ff9a1f" opacity=".8"/><circle r="165" fill="#ffd54a"/><circle r="85" fill="#fff6d0"/><circle r="380" fill="none" stroke="#fff0c0" stroke-width="14" opacity=".6"/></g>',
    animate: (t) => { let best = null; for (const b of at()) { const u = (t - b) / 1.25; if (u >= 0 && u <= 1) best = u; } if (best == null) return { opacity: 0, scale: .01 }; return { scale: .15 + 1.9 * ez(best), opacity: Math.pow(1 - best, 1.4) * .95 }; },
  };
}
function smokeProp(sc) {
  const at = () => (sc._fx || []).filter((e) => e.kind === 'boom').map((e) => e.t);
  return {
    screen: true, layer: 'front', x: 800, y: 450, _sfx: 'smoke',
    svg: '<g fill="#1b1b1f"><circle cx="-220" cy="40" r="170"/><circle cx="40" cy="-60" r="210"/><circle cx="260" cy="30" r="160"/><circle cx="-60" cy="120" r="190"/></g>',
    animate: (t) => { let best = null; for (const b of at()) { const u = (t - b - .25) / 2.6; if (u >= 0 && u <= 1) best = u; } if (best == null) return { opacity: 0, scale: .01 }; return { scale: .6 + 1.1 * ez(best), y: -120 * best, opacity: Math.sin(Math.PI * Math.min(1, best * 1.15)) * .55 }; },
  };
}
/** The visual half of the sounds: an explosion flashes, shows a fireball and smoke and shakes the camera; a slam, crash or punch gives a small shake. */
export function prepare(SC, S) {
  const res = { booms: 0, shakes: 0 };
  const sx = S || { SC }; if (!sx.SC) sx.SC = SC;
  setTimes(sx);
  SC.forEach((sc) => {
    if (!sc || typeof sc !== 'object' || !(sc._fx && sc._fx.length) || sc._fxWrapped || sc.sfx === false) return;
    sc._fxWrapped = true;
    const hasBoom = sc._fx.some((e) => e.kind === 'boom');
    if (hasBoom) { sc.props = (sc.props || []).concat([smokeProp(sc), fireballProp(sc, 'ball')]); res.booms++; }
    const baseCam = sc.camera, baseFlash = sc.flash;
    sc.camera = (t) => {
      let c = null; try { c = (typeof baseCam === 'function' ? baseCam(t) : baseCam) || null; } catch (e) { c = null; }
      c = c ? { ...c } : { zoom: 1, x: 800, y: 450, rot: 0 };
      let sh = 0; for (const e of sc._fx || []) { const w = VIS[e.kind]; if (!w) continue; const u = (t - e.t) / (e.kind === 'boom' ? .9 : .35); if (u >= 0 && u <= 1) sh = Math.max(sh, w * (1 - u)); }
      if (sh > 0) { c.x = num(c.x, 800) + Math.sin(t * 83) * 16 * sh; c.y = num(c.y, 450) + Math.cos(t * 71) * 12 * sh; }
      return c;
    };
    sc.flash = (t) => {
      let v = 0; try { v = typeof baseFlash === 'function' ? +baseFlash(t) || 0 : 0; } catch (e) { v = 0; }
      for (const e of sc._fx || []) { if (e.kind !== 'boom') continue; const u = (t - e.t) / .4; if (u >= 0 && u <= 1) v = Math.max(v, .9 * (1 - u)); }
      return v;
    };
    res.shakes++;
  });
  return res;
}
/** gives every scene the times (in scene seconds) of the sounds that have a picture; call again after the voiceover is matched */
export function setTimes(S) {
  const cues = sfxCues(S), st = startsOf(S), SC = S.SC || [];
  SC.forEach((sc) => { if (sc && typeof sc === 'object') sc._fx = []; });
  for (const c of cues) { if (!VIS[c.kind]) continue; const sc = SC[c.scene]; if (sc) sc._fx.push({ kind: c.kind, t: Math.max(0, c.at - num(st[c.scene])) }); }
  return cues;
}
