/* BACK + TUTORIAL BUTTONS (header of every screen)

   Back:     tells the Animato Studio Pro page to take the user back ('animato:back').
   Tutorial: opens a panel where the user watches the tutorials without leaving the app.

   >>> TO ADD A TUTORIAL (owner): open Tutorial, tap the play icon at the top-left of the panel 3 times, enter your passcode and paste the link.
       It is saved on the server (src/tutorials.js) and every user sees it. Passcode = TUTORIAL_ADMIN_KEY in wrangler.jsonc.
       url can be a YouTube / Vimeo link, a direct video file (.mp4 / .webm), or any web page.
   TUTORIALS below is only a built-in fallback shown when nothing has been saved on the server yet (can stay empty). */
(function () {
  "use strict";

  var TUTORIALS = [
    // { title: "Getting started", url: "https://www.youtube.com/watch?v=XXXXXXXXXXX", note: "Make your first animation in 2 minutes" },
    // { title: "Adding your own voice", url: "https://youtu.be/XXXXXXXXXXX" },
  ];

  var LIST = TUTORIALS, LOADED = false, CACHE_KEY = "stk_tut_cache", KEY_KEY = "stk_tut_key";
  function lsGet(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
  function lsSet(k, v) { try { localStorage.setItem(k, v); } catch (e) {} }
  function setList(items) {
    LIST = (Array.isArray(items) && items.length) ? items : TUTORIALS;
    LOADED = true;
    try { lsSet(CACHE_KEY, JSON.stringify(Array.isArray(items) ? items : [])); } catch (e) {}
  }
  (function () { try { var c = JSON.parse(lsGet(CACHE_KEY) || "null"); if (Array.isArray(c)) { LIST = c.length ? c : TUTORIALS; LOADED = true; } } catch (e) {} })();
  function loadRemote() {
    return fetch("/api/tutorials", { cache: "no-store" })
      .then(function (r) { if (!r.ok) throw new Error("http " + r.status); return r.json(); })
      .then(function (d) { if (d && Array.isArray(d.items)) setList(d.items); return true; })
      .catch(function () { LOADED = true; return false; });
  }
  function admin(body) {
    return fetch("/api/tutorials/admin", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) })
      .then(function (r) { return r.json().catch(function () { return {}; }).then(function (d) { d.status = r.status; return d; }); })
      .catch(function () { return { error: "network" }; });
  }

  /* ---------- Back ---------- */
  function goBack() {
    window.parent.postMessage({ type: 'animato:back' }, '*');
  }

  /* ---------- Turn a link into something that can be shown inside the panel ---------- */
  function toEmbed(url) {
    var u;
    try { u = new URL(url, location.href); } catch (e) { return { kind: "link", src: url }; }
    var h = u.hostname.replace(/^www\./, "").replace(/^m\./, "");
    var id;
    if (h === "youtu.be") id = u.pathname.slice(1).split("/")[0];
    else if (h === "youtube.com" || h === "youtube-nocookie.com") {
      if (u.pathname === "/watch") id = u.searchParams.get("v");
      else { var m = u.pathname.match(/^\/(embed|shorts|live|v)\/([^/?]+)/); if (m) id = m[2]; }
    }
    if (id && /^[\w-]{6,}$/.test(id)) return { kind: "iframe", src: "https://www.youtube-nocookie.com/embed/" + id + "?rel=0&playsinline=1", open: u.href };
    if (h === "vimeo.com" || h === "player.vimeo.com") {
      var vm = u.pathname.match(/(\d{5,})/);
      if (vm) return { kind: "iframe", src: "https://player.vimeo.com/video/" + vm[1], open: u.href };
    }
    if (/\.(mp4|webm|mov|m4v|ogg)$/i.test(u.pathname)) return { kind: "video", src: u.href, open: u.href };
    if (u.protocol === "https:" || u.protocol === "http:") return { kind: "iframe", src: u.href, open: u.href };
    return { kind: "link", src: u.href, open: u.href };
  }

  /* ---------- Panel ---------- */
  var css =
    ".stk-hbtn{display:inline-flex;align-items:center;gap:6px;flex:none;background:none;border:1px solid var(--line2);color:var(--fg);border-radius:999px;padding:6px 12px;font:inherit;font-size:12.5px;line-height:1.2;cursor:pointer;white-space:nowrap;min-height:34px}" +
    ".stk-hbtn:hover{background:var(--card2)}.stk-hbtn:focus-visible{outline:2px solid var(--ac);outline-offset:2px}" +
    ".stk-hbtn svg{width:16px;height:16px;flex:none}" +
    ".stk-hbtn.stk-tut{border-color:var(--ac);color:var(--ac)}" +
    ".stk-hl{display:flex;align-items:center;gap:10px;min-width:0}.stk-hr{display:flex;align-items:center;gap:8px;flex:none}" +
    ".top>.stk-hl{flex:1 1 auto}.top .stk-hr{margin-left:auto}.top .stk-hr .pm-home{margin-right:0}" +
    "@media (max-width:520px){#stkTut .stk-hbtn .stk-lbl{display:none}#stkTut .stk-hbtn{padding:6px 9px}.top .stk-hr{gap:6px}.top .brand h1{font-size:15px;line-height:1.15}.top .brand-logo{display:none}}" +
    ".pm-top .stk-hr{gap:10px}.pm-top .stk-tut{background:var(--ac);border-color:var(--ac);color:var(--acf);font-weight:650;font-size:14px;padding:9px 16px;min-height:44px;box-shadow:0 6px 18px color-mix(in srgb,var(--ac) 35%,transparent);animation:stkPulse 2.4s ease-out 3}" +
    ".pm-top .stk-tut:hover{background:var(--ac);opacity:.92}.pm-top .stk-tut svg{width:18px;height:18px}.pm-top .stk-s{display:none}" +
    "@keyframes stkPulse{0%{box-shadow:0 0 0 0 color-mix(in srgb,var(--ac) 55%,transparent)}70%,100%{box-shadow:0 0 0 14px transparent}}" +
    "@media (prefers-reduced-motion:reduce){.pm-top .stk-tut{animation:none}}" +
    "@media (max-width:400px){.pm-top .stk-w{display:none}.pm-top .stk-s{display:inline}.pm-top .stk-tut{padding:9px 13px}}" +
    "#stkTut{position:fixed;inset:0;z-index:3400;display:none;flex-direction:column;background:rgba(0,0,0,.6)}#stkTut.on{display:flex}" +
    "#stkTut .stk-card{margin:auto;width:min(880px,100%);max-height:100%;display:flex;flex-direction:column;background:var(--card);color:var(--fg);border:1px solid var(--line2);border-radius:18px;overflow:hidden;box-shadow:0 18px 60px rgba(0,0,0,.5)}" +
    "@media (max-width:600px){#stkTut .stk-card{margin:0;border-radius:0;height:100%;border:0}}" +
    "#stkTut .stk-bar{display:flex;align-items:center;gap:10px;padding:12px 14px calc(12px);border-bottom:1px solid var(--line);padding-top:calc(12px + env(safe-area-inset-top,0px))}" +
    "#stkTut .stk-bar h2{margin:0;font-size:16px;flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}" +
    "#stkTut .stk-body{overflow:auto;padding:14px;-webkit-overflow-scrolling:touch}" +
    "#stkTut .stk-list{display:grid;gap:8px;margin:0;padding:0;list-style:none}" +
    "#stkTut .stk-item{display:flex;align-items:center;gap:12px;width:100%;text-align:left;background:var(--card2);border:1px solid var(--line2);color:var(--fg);border-radius:14px;padding:12px;font:inherit;cursor:pointer}" +
    "#stkTut .stk-item:hover{border-color:var(--ac)}#stkTut .stk-item:focus-visible{outline:2px solid var(--ac);outline-offset:2px}" +
    "#stkTut .stk-play{flex:none;width:38px;height:38px;border-radius:50%;background:var(--ac);color:var(--acf);display:flex;align-items:center;justify-content:center}" +
    "#stkTut .stk-item b{display:block;font-size:14.5px}#stkTut .stk-item small{display:block;color:var(--mu);font-size:12.5px;margin-top:2px}" +
    "#stkTut .stk-frame{position:relative;width:100%;aspect-ratio:16/9;background:#000;border-radius:12px;overflow:hidden}" +
    "#stkTut .stk-frame iframe,#stkTut .stk-frame video{position:absolute;inset:0;width:100%;height:100%;border:0;background:#000}" +
    "#stkTut .stk-foot{display:flex;flex-wrap:wrap;gap:8px;margin-top:12px}" +
    "#stkTut .stk-empty{color:var(--mu);font-size:14px;line-height:1.55;text-align:center;padding:26px 8px;margin:0}" +
    "#stkTut .stk-ic{padding:6px;width:34px;justify-content:center}#stkTut .stk-ic svg{width:18px;height:18px}" +
    "#stkTut .stk-form{display:grid;gap:10px}#stkTut .stk-form label{display:grid;gap:4px;font-size:12.5px;color:var(--mu)}" +
    "#stkTut .stk-form input{width:100%;box-sizing:border-box;background:var(--bg);border:1px solid var(--line2);color:var(--fg);border-radius:12px;padding:11px 12px;font:inherit;font-size:15px}" +
    "#stkTut .stk-form input:focus-visible{outline:2px solid var(--ac);outline-offset:1px}" +
    "#stkTut .stk-go{background:var(--ac);border-color:var(--ac);color:var(--acf);font-weight:600;justify-content:center;padding:11px 14px;font-size:14px}" +
    "#stkTut .stk-go:hover{background:var(--ac);opacity:.92}#stkTut .stk-go[disabled]{opacity:.55;cursor:default}" +
    "#stkTut .stk-msg{min-height:18px;margin:0;font-size:13px;color:var(--mu)}#stkTut .stk-msg.err{color:var(--err)}#stkTut .stk-msg.ok{color:var(--ok)}" +
    "#stkTut .stk-sub{margin:18px 0 8px;font-size:13px;font-weight:650;color:var(--mu)}" +
    "#stkTut .stk-row{display:flex;align-items:center;gap:6px;padding:8px 0;border-top:1px solid var(--line)}#stkTut .stk-row span{flex:1;min-width:0;font-size:13.5px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}" +
    "#stkTut .stk-row .stk-hbtn{padding:4px 9px;min-height:30px;font-size:12px}" +
    "#stkTut .stk-title{margin:12px 0 0;font-size:15px;font-weight:650}#stkTut .stk-note{margin:4px 0 0;color:var(--mu);font-size:13px}";

  var ICON_BACK = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 5l-7 7 7 7"/></svg>';
  var ICON_PLAY = '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M8 5.5v13l11-6.5z"/></svg>';

  var root, bodyEl, titleEl, backEl, current = -1, lastFocus = null, taps = [];

  function el(tag, cls, text) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text != null) e.textContent = text;
    return e;
  }

  function build() {
    if (root) return;
    root = el("div"); root.id = "stkTut";
    root.setAttribute("role", "dialog"); root.setAttribute("aria-modal", "true"); root.setAttribute("aria-labelledby", "stkTutTitle");
    var card = el("div", "stk-card"), bar = el("div", "stk-bar");
    backEl = el("button", "stk-hbtn"); backEl.type = "button"; backEl.hidden = true;
    backEl.innerHTML = ICON_BACK + '<span class="stk-lbl">All tutorials</span>';
    backEl.onclick = showList;
    titleEl = el("h2", null, "Tutorials"); titleEl.id = "stkTutTitle";
    var close = el("button", "stk-hbtn", "Close"); close.type = "button"; close.onclick = closePanel;
    // owner door: tap this play icon 3 times to open the "add a tutorial link" section
    var ic = el("button", "stk-hbtn stk-tut stk-ic"); ic.type = "button"; ic.setAttribute("aria-label", "Tutorials"); ic.innerHTML = ICON_PLAY;
    ic.addEventListener("click", function () {
      var t = Date.now(); taps = taps.filter(function (x) { return t - x < 1500; }); taps.push(t);
      if (taps.length >= 3) { taps = []; showAdmin(); }
    });
    bar.appendChild(backEl); bar.appendChild(ic); bar.appendChild(titleEl); bar.appendChild(close);
    bodyEl = el("div", "stk-body");
    card.appendChild(bar); card.appendChild(bodyEl); root.appendChild(card);
    root.addEventListener("click", function (e) { if (e.target === root) closePanel(); });
    document.body.appendChild(root);
  }

  function clearBody() {
    // removing the player stops the video / sound
    while (bodyEl.firstChild) bodyEl.removeChild(bodyEl.firstChild);
  }

  function showList() {
    current = -1;
    clearBody();
    backEl.hidden = true;
    titleEl.textContent = "Tutorials";
    if (!LIST.length) {
      bodyEl.appendChild(el("p", "stk-empty", LOADED ? "Tutorials are coming soon. Please check back shortly." : "Loading tutorials…"));
      return;
    }
    if (LIST.length === 1) { play(0, true); return; }
    var ul = el("ul", "stk-list");
    LIST.forEach(function (t, i) {
      var li = el("li"), b = el("button", "stk-item"); b.type = "button";
      var ic = el("span", "stk-play"); ic.innerHTML = ICON_PLAY;
      var tx = el("span"); tx.appendChild(el("b", null, t.title || "Tutorial " + (i + 1)));
      if (t.note) tx.appendChild(el("small", null, t.note));
      b.appendChild(ic); b.appendChild(tx);
      b.onclick = function () { play(i, false); };
      li.appendChild(b); ul.appendChild(li);
    });
    bodyEl.appendChild(ul);
  }

  function play(i, single) {
    var t = LIST[i]; if (!t) return;
    current = i;
    clearBody();
    backEl.hidden = !!single;
    titleEl.textContent = t.title || "Tutorial";
    var info = toEmbed(t.url), frame = el("div", "stk-frame");
    if (info.kind === "video") {
      var v = el("video"); v.controls = true; v.playsInline = true; v.setAttribute("playsinline", ""); v.preload = "metadata"; v.src = info.src;
      frame.appendChild(v);
    } else if (info.kind === "iframe") {
      var f = document.createElement("iframe");
      // this app is cross-origin isolated: "credentialless" lets it show a video site that is not
      f.setAttribute("credentialless", "");
      f.setAttribute("allow", "autoplay; encrypted-media; picture-in-picture; fullscreen");
      f.setAttribute("allowfullscreen", "");
      f.setAttribute("referrerpolicy", "strict-origin-when-cross-origin");
      f.title = t.title || "Tutorial";
      f.src = info.src;
      frame.appendChild(f);
    }
    if (info.kind !== "link") bodyEl.appendChild(frame);
    if (t.note) bodyEl.appendChild(el("p", "stk-note", t.note));
    if (info.open) {
      var foot = el("div", "stk-foot");
      var a = el("a", "stk-hbtn", "Not loading? Open in a new tab");
      a.href = info.open; a.target = "_blank"; a.rel = "noopener noreferrer";
      foot.appendChild(a); bodyEl.appendChild(foot);
    }
  }

  var ERR = {
    "wrong-key": "Wrong passcode.",
    "locked": "Too many wrong tries. Please wait 15 minutes and try again.",
    "not-configured": "The passcode is not set on the server yet. Set TUTORIAL_ADMIN_KEY in wrangler.jsonc and deploy.",
    "bad-url": "That link is not valid. Paste the full link, starting with https://",
    "full": "The list is full (50 tutorials). Remove one first.",
    "network": "Could not reach the server. Check your internet and try again.",
    "no-store": "The tutorial storage is not set up on the server yet. Deploy the latest version."
  };
  function showAdmin() {
    current = -2;
    clearBody();
    backEl.hidden = false;
    titleEl.textContent = "Add a tutorial";
    var form = el("form", "stk-form"); form.setAttribute("autocomplete", "off");
    function field(label, type, ph, val) {
      var l = el("label", null, label), i = el("input"); i.type = type; i.placeholder = ph || ""; if (val) i.value = val;
      i.autocomplete = type === "password" ? "off" : "off"; i.setAttribute("autocapitalize", "off"); i.spellcheck = false;
      l.appendChild(i); form.appendChild(l); return i;
    }
    var key = field("Owner passcode", "password", "Your passcode", lsGet(KEY_KEY) || "");
    var link = field("Tutorial link (YouTube, Vimeo or a video file)", "url", "https://youtu.be/…");
    var title = field("Title", "text", "Getting started");
    var note = field("Short note (optional)", "text", "");
    var msg = el("p", "stk-msg"); msg.setAttribute("role", "status");
    var go = el("button", "stk-hbtn stk-go", "Add tutorial"); go.type = "submit";
    form.appendChild(go); form.appendChild(msg);
    var sub = el("p", "stk-sub", "Saved tutorials (everyone sees these)"), listEl = el("div");

    function say(t, cls) { msg.textContent = t || ""; msg.className = "stk-msg" + (cls ? " " + cls : ""); }
    function fail(d) { say(ERR[d && d.error] || (d && d.error) || "Something went wrong. Please try again.", "err"); }
    function draw() {
      while (listEl.firstChild) listEl.removeChild(listEl.firstChild);
      var real = LIST === TUTORIALS ? [] : LIST;
      if (!real.length) { listEl.appendChild(el("p", "stk-note", "Nothing saved yet.")); return; }
      real.forEach(function (t) {
        var row = el("div", "stk-row"), name = el("span", null, t.title || t.url);
        var up = el("button", "stk-hbtn", "↑"), dn = el("button", "stk-hbtn", "↓"), rm = el("button", "stk-hbtn", "Remove");
        up.type = dn.type = rm.type = "button"; up.setAttribute("aria-label", "Move up"); dn.setAttribute("aria-label", "Move down");
        function mv(dir) { return function () { run({ action: "move", id: t.id, dir: dir }); }; }
        up.onclick = mv("up"); dn.onclick = mv("down");
        var armed = false, tm;
        rm.onclick = function () {
          if (!armed) { armed = true; rm.textContent = "Tap again"; tm = setTimeout(function () { armed = false; rm.textContent = "Remove"; }, 3000); return; }
          clearTimeout(tm); run({ action: "remove", id: t.id });
        };
        row.appendChild(name); row.appendChild(up); row.appendChild(dn); row.appendChild(rm); listEl.appendChild(row);
      });
    }
    function run(extra, done) {
      if (!key.value) { say("Enter your passcode first.", "err"); key.focus(); return; }
      go.disabled = true; say("Saving…");
      admin(Object.assign({ key: key.value }, extra)).then(function (d) {
        go.disabled = false;
        if (d && d.ok) { lsSet(KEY_KEY, key.value); setList(d.items); say(extra.action === "add" ? "Saved. Every user can now see it." : "Done.", "ok"); draw(); if (done) done(); }
        else fail(d);
      });
    }
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      if (!link.value.trim()) { say("Paste the tutorial link.", "err"); link.focus(); return; }
      run({ action: "add", url: link.value.trim(), title: title.value, note: note.value }, function () { link.value = ""; title.value = ""; note.value = ""; });
    });
    bodyEl.appendChild(form); bodyEl.appendChild(sub); bodyEl.appendChild(listEl);
    draw();
    loadRemote().then(function () { if (current === -2) draw(); });
    try { (key.value ? link : key).focus({ preventScroll: true }); } catch (e) {}
  }

  function openPanel() {
    build();
    lastFocus = document.activeElement;
    showList();
    loadRemote().then(function () { if (root.classList.contains("on") && current === -1) showList(); });
    root.classList.add("on");
    document.addEventListener("keydown", onKey, true);
    var first = bodyEl.querySelector("button,a,iframe") || root.querySelector(".stk-bar button:not([hidden])");
    try { first && first.focus({ preventScroll: true }); } catch (e) {}
  }

  function closePanel() {
    if (!root) return;
    clearBody();
    root.classList.remove("on");
    document.removeEventListener("keydown", onKey, true);
    try { lastFocus && lastFocus.focus && lastFocus.focus({ preventScroll: true }); } catch (e) {}
  }

  function onKey(e) {
    if (e.key === "Escape") { e.stopPropagation(); if ((current >= 0 && LIST.length > 1) || current === -2) showList(); else closePanel(); }
  }

  /* ---------- Wire up every header button (they are plain HTML in index.html) ---------- */
  function init() {
    var st = document.createElement("style"); st.textContent = css; document.head.appendChild(st);
    Array.prototype.forEach.call(document.querySelectorAll("[data-stk-back]"), function (b) {
      b.innerHTML = ICON_BACK + '<span class="stk-lbl">Back</span>';
      b.addEventListener("click", goBack);
    });
    Array.prototype.forEach.call(document.querySelectorAll("[data-stk-tutorial]"), function (b) {
      b.innerHTML = ICON_PLAY + '<span class="stk-lbl"><span class="stk-w">Watch tutorial</span><span class="stk-s">Tutorial</span></span>';
      b.addEventListener("click", openPanel);
    });
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
  else init();

  window.AnimatoTutorials = { open: openPanel, close: closePanel, get list() { return LIST; }, back: goBack };
})();
