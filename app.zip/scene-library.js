// Scene library: ready-made, layered, textured places (a subway platform, a hospital ward, a pine forest...) that the AI can call by name,
// so it only has to draw a set when nothing here fits. Fewer tokens, better looking films.
//
//   LOC.subway()                                   -> a full 1600x900 background (SVG string)
//   LOC.subway({time:'night', weather:'rain', seed:4})
//   LOC.get('subway night rain')                   -> same, from one phrase (also what a beat's  s:'subway night rain'  means)
//
// One place x 5 times of day x 5 kinds of weather x 12 colour/detail seeds = 300 combinations per place (indoor places show time and weather through windows and lights).
// Pure functions only (no DOM), so they are unit tested in Node and run unchanged in the export.
// Every picture is built as stacked layers (sky, far, middle, structure, floor, props, light, weather, finish) that are
// tagged data-layer="..." so the layers can be moved apart later (depth, parallax).

export const W = 1600;
export const H = 900;

const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const hex2rgb = (h) => {
  h = String(h || '#000').replace('#', '');
  if (h.length === 3) h = h.replace(/./g, '$&$&');
  const n = parseInt(h.slice(0, 6), 16) || 0;
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
};
const rgb2hex = (r, g, b) => '#' + [r, g, b].map((v) => clamp(Math.round(v), 0, 255).toString(16).padStart(2, '0')).join('');
export const mix = (a, b, t) => { const A = hex2rgb(a), B = hex2rgb(b); return rgb2hex(A[0] + (B[0] - A[0]) * t, A[1] + (B[1] - A[1]) * t, A[2] + (B[2] - A[2]) * t); };
export const shade = (c, f) => { const A = hex2rgb(c); return rgb2hex(A[0] * f, A[1] * f, A[2] * f); };
const hueShift = (c, deg) => {
  if (!deg) return c;
  const [r, g, b] = hex2rgb(c).map((v) => v / 255);
  const mx = Math.max(r, g, b), mn = Math.min(r, g, b), l = (mx + mn) / 2, d = mx - mn;
  let h = 0, s = 0;
  if (d) {
    s = l > .5 ? d / (2 - mx - mn) : d / (mx + mn);
    h = mx === r ? (g - b) / d + (g < b ? 6 : 0) : mx === g ? (b - r) / d + 2 : (r - g) / d + 4;
    h *= 60;
  }
  h = (h + deg + 360) % 360;
  const f = (n) => { const k = (n + h / 30) % 12; return l - s * Math.min(l, 1 - l) * Math.max(-1, Math.min(k - 3, 9 - k, 1)); };
  return rgb2hex(f(0) * 255, f(8) * 255, f(4) * 255);
};
const hashStr = (s) => { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; };
const rng = (a) => () => { a |= 0; a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
const f1 = (v) => (Math.round(v * 10) / 10);

export const TIMES = Object.freeze(['day', 'morning', 'dusk', 'night', 'overcast']);
export const WEATHERS = Object.freeze(['clear', 'rain', 'snow', 'fog', 'storm']);
export const SEEDS = 12;

const TIME = {
  day:      { sky: ['#4f9fe8', '#d2ecff'], tint: '#ffffff', tk: 0,   dim: 1,    lamps: 0,   sun: { x: 1260, y: 150, r: 56, c: '#fff1ae' }, key: '#fff3cf' },
  morning:  { sky: ['#6a8fd8', '#ffd3a0'], tint: '#ffb27a', tk: .16, dim: .97,  lamps: .2,  sun: { x: 260,  y: 560, r: 74, c: '#ffd9a0' }, key: '#ffd9a8' },
  dusk:     { sky: ['#37296b', '#ff9a62'], tint: '#ff7a4a', tk: .26, dim: .84,  lamps: .75, sun: { x: 1240, y: 600, r: 86, c: '#ffb56e' }, key: '#ffb37a' },
  night:    { sky: ['#050a1f', '#1d2d62'], tint: '#16224f', tk: .6,  dim: .5,   lamps: 1,   moon: { x: 1240, y: 150, r: 46 }, stars: 90, key: '#bcd0ff' },
  overcast: { sky: ['#8793a1', '#dce1e7'], tint: '#9aa3ad', tk: .3,  dim: .9,   lamps: .25, key: '#e6ebf0' },
};
const WX = {
  clear: { desat: 0, dim: 1 },
  rain:  { desat: .3, dim: .86, rain: 70 },
  snow:  { desat: .22, dim: .98, snow: 90, white: .35 },
  fog:   { desat: .38, dim: .96, fog: 1 },
  storm: { desat: .4, dim: .7, rain: 130, flash: true },
};

let UID = 0;
const uid = () => 'sl' + (++UID).toString(36);

/** The drawing kit a place is built with. One kit per picture: it knows the time of day, weather and seed. */
export function makeKit(id, o = {}) {
  const time = TIME[o.time] ? o.time : 'day';
  const weather = WX[o.weather] ? o.weather : 'clear';
  const T = TIME[time], X = WX[weather];
  const seed = Math.abs(o.seed | 0) % 1000;
  const r = rng(hashStr(id) + seed * 7919 + 13);
  const hue = [0, 28, -28, 55, -55, 90, -90, 140, 180, -140, 18, -18][seed % 12];
  const layers = [];
  const k = { id, time, weather, seed, T, X, r, layers, night: time === 'night', out: true };
  let cur = null;

  const rd = (a, b) => a + r() * (b - a);
  k.rd = rd;
  k.pick = (arr) => arr[Math.floor(r() * arr.length) % arr.length];
  k.uid = uid;
  // colour grading: g = outdoors (sky, weather and time shift everything), gi = indoors (lights are on, so a milder shift)
  const wxg = (c) => (X.desat ? mix(shade(c, X.dim), '#8a949f', X.desat) : c);
  k.g = (c) => { c = wxg(shade(mix(c, T.tint, T.tk), T.dim)); return X.white ? mix(c, '#eef4fa', X.white * .25) : c; };
  k.gi = (c) => shade(mix(c, T.tint, T.tk * .3), 1 - (1 - T.dim) * .3);
  k.v = (c, amt = 1) => hueShift(c, hue * amt);          // colour variety from the seed
  k.sh = shade; k.mix = mix;
  k.lampOn = T.lamps >= .5;
  k.lampK = T.lamps;

  k.begin = (name) => { cur = { name, s: '' }; };
  k.end = () => { if (cur) layers.push(cur); cur = null; };
  k.add = (s) => { cur.s += s; return s; };
  k.layer = (name, fn) => { k.begin(name); fn(); k.end(); };

  // --- basic shapes -----------------------------------------------------------------------------------
  k.rect = (x, y, w, h, fill, ex = '') => k.add(`<rect x="${f1(x)}" y="${f1(y)}" width="${f1(w)}" height="${f1(h)}" fill="${fill}" ${ex}/>`);
  const defsGrad = (stops, x1 = 0, y1 = 0, x2 = 0, y2 = 1, kind = 'linearGradient', ex = '') => {
    const i = uid();
    return [i, `<defs><${kind} id="${i}" ${kind === 'linearGradient' ? `x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}"` : ex}>${stops.map((s, j) => `<stop offset="${s[0] ?? j / (stops.length - 1)}" stop-color="${s[1] || s}" ${s[2] != null ? `stop-opacity="${s[2]}"` : ''}/>`).join('')}</${kind}></defs>`];
  };
  k.vg = (x, y, w, h, c0, c1, ex = '') => { const [i, d] = defsGrad([[0, c0], [1, c1]]); return k.add(`${d}<rect x="${f1(x)}" y="${f1(y)}" width="${f1(w)}" height="${f1(h)}" fill="url(#${i})" ${ex}/>`); };
  k.hg = (x, y, w, h, c0, c1, ex = '') => { const [i, d] = defsGrad([[0, c0], [1, c1]], 0, 0, 1, 0); return k.add(`${d}<rect x="${f1(x)}" y="${f1(y)}" width="${f1(w)}" height="${f1(h)}" fill="url(#${i})" ${ex}/>`); };
  k.glow = (x, y, rad, c = '#ffd76b', op = .5) => { const [i, d] = defsGrad([[0, c, op], [.45, c, op * .35], [1, c, 0]], 0, 0, 0, 0, 'radialGradient'); return k.add(`${d}<ellipse cx="${f1(x)}" cy="${f1(y)}" rx="${f1(rad)}" ry="${f1(rad)}" fill="url(#${i})"/>`); };
  k.shaft = (x, y, w, h, c = '#fff3b0', op = .25, spread = 1.8) => { const [i, d] = defsGrad([[0, c, op], [1, c, 0]]); return k.add(`${d}<polygon points="${f1(x - w / 2)},${f1(y)} ${f1(x + w / 2)},${f1(y)} ${f1(x + w * spread / 2)},${f1(y + h)} ${f1(x - w * spread / 2)},${f1(y + h)}" fill="url(#${i})"/>`); };
  k.shadow = (cx, y, rx, ry = rx * .16, op = .38) => { const [i, d] = defsGrad([[0, '#000', op], [.55, '#000', op * .5], [1, '#000', 0]], 0, 0, 0, 0, 'radialGradient'); return k.add(`${d}<ellipse cx="${f1(cx)}" cy="${f1(y)}" rx="${f1(rx)}" ry="${f1(ry)}" fill="url(#${i})"/>`); };
  k.poly = (pts, fill, ex = '') => k.add(`<polygon points="${pts.map((p) => f1(p[0]) + ',' + f1(p[1])).join(' ')}" fill="${fill}" ${ex}/>`);
  k.line = (x1, y1, x2, y2, c, w = 2, op = 1) => k.add(`<line x1="${f1(x1)}" y1="${f1(y1)}" x2="${f1(x2)}" y2="${f1(y2)}" stroke="${c}" stroke-width="${w}" stroke-opacity="${op}" stroke-linecap="round"/>`);
  k.circle = (x, y, rad, fill, ex = '') => k.add(`<circle cx="${f1(x)}" cy="${f1(y)}" r="${f1(rad)}" fill="${fill}" ${ex}/>`);
  k.path = (d, fill, ex = '') => k.add(`<path d="${d}" fill="${fill}" ${ex}/>`);
  // a solid object: lit top, shaded bottom, soft outline. c is already graded.
  k.obj = (x, y, w, h, c, o2 = {}) => {
    const rx = o2.r ?? 4;
    k.vg(x, y, w, h, shade(c, 1.12), shade(c, .8), `rx="${rx}" stroke="#101420" stroke-opacity=".5" stroke-width="${o2.sw ?? 3}"`);
    if (o2.hl !== false) k.rect(x + 3, y + 3, Math.max(2, w - 6), Math.min(5, h / 6), '#fff', 'opacity=".14" rx="2"');
    return '';
  };

  // --- textures (patterns, so they are cheap) ---------------------------------------------------------
  k.tex = (kind, x, y, w, h, o2 = {}) => {
    const op = o2.op ?? .5, c = o2.c || '#000', i = uid(), s = o2.s || 1;
    let pat = '';
    if (kind === 'brick') { const bw = 72 * s, bh = 30 * s; pat = `<pattern id="${i}" width="${bw}" height="${bh * 2}" patternUnits="userSpaceOnUse"><path d="M0,${bh}H${bw}M0,${bh * 2}H${bw}M${bw / 2},0V${bh}M0,${bh}V${bh * 2}M${bw},${bh}V${bh * 2}" stroke="${c}" stroke-width="2.4" fill="none"/><rect x="2" y="2" width="${bw / 2 - 4}" height="${bh - 4}" fill="#fff" opacity=".05"/><rect x="${bw / 2 + 2}" y="${bh + 2}" width="${bw / 2 - 4}" height="${bh - 4}" fill="#000" opacity=".06"/></pattern>`; }
    else if (kind === 'tile') { const t = (o2.t || 60) * s; pat = `<pattern id="${i}" width="${t}" height="${t}" patternUnits="userSpaceOnUse"><path d="M0,0H${t}M0,0V${t}" stroke="${c}" stroke-width="2.2" fill="none"/><rect x="3" y="3" width="${t - 6}" height="${t * .35}" fill="#fff" opacity=".07"/></pattern>`; }
    else if (kind === 'planks') { const t = (o2.t || 46) * s; pat = `<pattern id="${i}" width="${t * 6}" height="${t}" patternUnits="userSpaceOnUse"><path d="M0,0H${t * 6}M${t * 2.2},0V${t}M${t * 4.6},${t}V0" stroke="${c}" stroke-width="2" fill="none"/><path d="M6,${t * .4}q40,-5 90,0M${t * 2.6},${t * .7}q50,4 110,-1" stroke="${c}" stroke-width="1" fill="none" opacity=".5"/></pattern>`; }
    else if (kind === 'panel') { const t = (o2.t || 120) * s; pat = `<pattern id="${i}" width="${t}" height="${t}" patternUnits="userSpaceOnUse"><rect x="6" y="6" width="${t - 12}" height="${t - 12}" fill="none" stroke="${c}" stroke-width="2.2"/><rect x="10" y="10" width="${t - 20}" height="3" fill="#fff" opacity=".07"/></pattern>`; }
    else if (kind === 'stripes') { const t = (o2.t || 26) * s; pat = `<pattern id="${i}" width="${t}" height="${t}" patternUnits="userSpaceOnUse" patternTransform="rotate(${o2.a ?? 0})"><rect width="${t / 2}" height="${t}" fill="${c}"/></pattern>`; }
    else if (kind === 'grid') { const t = (o2.t || 50) * s; pat = `<pattern id="${i}" width="${t}" height="${t}" patternUnits="userSpaceOnUse"><path d="M0,0H${t}M0,0V${t}" stroke="${c}" stroke-width="1.5" fill="none"/></pattern>`; }
    else if (kind === 'metal') { const t = (o2.t || 90) * s; pat = `<pattern id="${i}" width="${t}" height="${t}" patternUnits="userSpaceOnUse"><path d="M0,0H${t}M0,0V${t}" stroke="${c}" stroke-width="2" fill="none"/><circle cx="8" cy="8" r="2.4" fill="${c}"/><circle cx="${t - 8}" cy="8" r="2.4" fill="${c}"/></pattern>`; }
    else { // speckle: plaster, concrete, asphalt, sand
      const n = Math.min(120, Math.round((w * h) / (o2.dens || 5200)) + 24), rr = rng(hashStr(i) + 5);
      let sp = '';
      for (let j = 0; j < n; j++) sp += `<circle cx="${f1(rr() * 200)}" cy="${f1(rr() * 200)}" r="${f1(.7 + rr() * 2.2)}" fill="${rr() < .5 ? '#000' : '#fff'}" opacity="${f1((.06 + rr() * .14) * 10) / 10}"/>`;
      pat = `<pattern id="${i}" width="200" height="200" patternUnits="userSpaceOnUse">${sp}</pattern>`;
    }
    return k.add(`<defs>${pat}</defs><rect x="${f1(x)}" y="${f1(y)}" width="${f1(w)}" height="${f1(h)}" fill="url(#${i})" opacity="${op}"/>`);
  };

  // --- sky and far shapes -----------------------------------------------------------------------------
  k.skyColors = () => {
    let a = T.sky[0], b = T.sky[1];
    if (weather === 'rain') { a = mix(a, '#5d6874', .55); b = mix(b, '#9aa4ae', .5); }
    if (weather === 'storm') { a = mix(a, '#20262f', .7); b = mix(b, '#4a5360', .6); }
    if (weather === 'fog') { a = mix(a, '#b9c2cb', .6); b = mix(b, '#dfe5ea', .6); }
    if (weather === 'snow') { a = mix(a, '#aab5c2', .45); b = mix(b, '#e9eef4', .5); }
    return [a, b];
  };
  k.stars = (n = T.stars || 0, ymax = 420) => { let q = ''; if (weather === 'clear' || weather === 'snow') for (let j = 0; j < n; j++) q += `<circle cx="${f1(r() * W)}" cy="${f1(r() * ymax)}" r="${f1(.8 + r() * 1.8)}" fill="#fff" opacity="${f1((.35 + r() * .65) * 100) / 100}"/>`; return k.add(q); };
  k.clouds = (ymin = 60, ymax = 330, n = 6, col = '#fff', op = .8) => {
    const dark = weather === 'storm' ? .45 : weather === 'rain' ? .75 : 1;
    const cc = k.night ? mix(col, '#2a3b6e', .75) : time === 'dusk' ? mix(col, '#ff9a7a', .45) : time === 'morning' ? mix(col, '#ffc99a', .4) : col;
    const c2 = weather === 'storm' || weather === 'rain' ? mix(cc, '#5a6470', 1 - dark) : cc;
    for (let j = 0; j < n; j++) {
      const cx = r() * W, cy = ymin + r() * (ymax - ymin), s = .7 + r() * 1.1;
      let q = '';
      for (let b = 0; b < 5; b++) q += `<ellipse cx="${f1(cx + (b - 2) * 48 * s)}" cy="${f1(cy + (b % 2 ? -10 : 6) * s)}" rx="${f1((70 - Math.abs(b - 2) * 12) * s)}" ry="${f1((34 - Math.abs(b - 2) * 5) * s)}" fill="${c2}"/>`;
      k.add(`<g opacity="${f1(op * (.55 + r() * .45) * 100) / 100}">${q}<ellipse cx="${f1(cx)}" cy="${f1(cy + 26 * s)}" rx="${f1(150 * s)}" ry="${f1(14 * s)}" fill="${shade(c2, .8)}" opacity=".35"/></g>`);
    }
    return '';
  };
  k.sky = (o2 = {}) => {
    const [a, b] = k.skyColors(), y1 = o2.h ?? 760;
    k.vg(0, 0, W, y1, a, b);
    if (T.stars && !o2.noStars) k.stars();
    if (T.sun && weather !== 'storm' && weather !== 'rain' && weather !== 'fog' && !o2.noSun) { const s = T.sun; k.glow(s.x, s.y, s.r * 3.6, s.c, .55); k.circle(s.x, s.y, s.r, s.c, 'opacity=".95"'); }
    if (T.moon && weather !== 'storm' && weather !== 'rain' && !o2.noSun) { const m = T.moon; k.glow(m.x, m.y, m.r * 3.4, '#dfe8ff', .32); k.circle(m.x, m.y, m.r, '#f6f2d4'); k.circle(m.x - m.r * .3, m.y + m.r * .15, m.r * .18, '#d8d3b0', 'opacity=".6"'); k.circle(m.x + m.r * .25, m.y - m.r * .3, m.r * .12, '#d8d3b0', 'opacity=".55"'); }
    if (!o2.noClouds) k.clouds(60, o2.cloudY ?? 330, weather === 'clear' ? 4 : weather === 'overcast' ? 7 : 8, '#ffffff', weather === 'clear' ? .75 : .9);
    return '';
  };
  k.hills = (y, amp, col, o2 = {}) => {
    const n = o2.n ?? 9, st = W / n, pts = [[-20, H], [-20, y]];
    for (let j = 0; j <= n + 1; j++) pts.push([j * st - 20 + rd(-st * .25, st * .25), y - Math.abs(Math.sin(j * 1.7 + (o2.ph || 0))) * amp * rd(.5, 1)]);
    pts.push([W + 20, y], [W + 20, H]);
    const c = k.g(col);
    const [i, d] = defsGrad([[0, shade(c, 1.18)], [1, shade(c, .9)]]);
    k.add(`${d}<polygon points="${pts.map((p) => f1(p[0]) + ',' + f1(p[1])).join(' ')}" fill="url(#${i})"/>`);
    if (o2.snow) pts.slice(2, -2).forEach((p) => { if (p[1] < y - amp * .55) k.poly([[p[0], p[1]], [p[0] - 46, p[1] + 52], [p[0] - 14, p[1] + 40], [p[0], p[1] + 62], [p[0] + 18, p[1] + 38], [p[0] + 52, p[1] + 54]], k.g('#f3f7fb'), 'opacity=".95"'); });
    return '';
  };
  k.skyline = (y, hr, col, o2 = {}) => {
    const rr = rng(hashStr(id) + (o2.seed || 0) * 31 + seed * 17 + 3);
    let x = -20;
    const c = k.g(col), win = k.lampK > .4 ? k.g(o2.lit || '#ffd76b') : null;
    while (x < W + 20) {
      const bw = (o2.minW || 80) + rr() * ((o2.maxW || 170) - (o2.minW || 80)), bh = hr[0] + rr() * (hr[1] - hr[0]);
      const bc = shade(c, .9 + rr() * .22);
      k.vg(x, y - bh, bw, bh + 4, shade(bc, 1.1), shade(bc, .86), 'stroke="#0a0e1a" stroke-opacity=".25" stroke-width="2"');
      k.rect(x + bw * .72, y - bh, bw * .28, bh + 4, '#000', 'opacity=".12"');
      if (o2.roof !== false && rr() < .4) k.rect(x + bw * .3, y - bh - 14, bw * .12, 14, shade(bc, .8));
      if (o2.windows !== false) {
        let q = '';
        const cols = Math.max(2, Math.floor(bw / 26)), rows = Math.floor((bh - 20) / 34);
        for (let a = 0; a < cols; a++) for (let b = 0; b < rows; b++) {
          const lit = win && rr() < (o2.litChance ?? .3);
          q += `<rect x="${f1(x + 10 + a * ((bw - 20) / cols))}" y="${f1(y - bh + 14 + b * 34)}" width="${f1((bw - 20) / cols - 8)}" height="18" fill="${lit ? win : shade(bc, .78)}" opacity="${lit ? .95 : .55}"/>`;
        }
        k.add(q);
      }
      x += bw + rr() * (o2.gap ?? 6);
    }
    return '';
  };
  k.trees = (y, n, kind, col, o2 = {}) => {
    const rr = rng(hashStr(id) + seed * 5 + (o2.seed || 0) * 13 + 1), size = o2.size || 1;
    const items = [];
    for (let j = 0; j < n; j++) { let x = rr() * (W + 120) - 60; if (o2.edge) x = rr() < .5 ? rr() * 330 - 60 : 1270 + rr() * 390; items.push({ x, s: (.6 + rr() * .8) * size, t: rr() }); }
    items.sort((a, b) => a.s - b.s);
    for (const it of items) {
      const x = it.x, s = it.s, cc = k.g(shade(col, .85 + it.t * .3)), tr = k.g('#5a3b24');
      if (kind === 'pine') {
        k.rect(x - 7 * s, y - 50 * s, 14 * s, 50 * s, tr);
        for (let b = 0; b < 4; b++) k.poly([[x, y - (230 - b * 34) * s], [x - (46 + b * 22) * s, y - (118 - b * 30) * s], [x + (46 + b * 22) * s, y - (118 - b * 30) * s]], shade(cc, 1.1 - b * .07), 'stroke="#08140c" stroke-opacity=".3" stroke-width="2"');
        k.shadow(x, y + 4, 60 * s, 8 * s, .3);
      } else if (kind === 'palm') {
        k.path(`M${f1(x)},${f1(y)} q${f1(14 * s)},${f1(-120 * s)} ${f1(-10 * s)},${f1(-230 * s)}`, 'none', `stroke="${tr}" stroke-width="${f1(14 * s)}" stroke-linecap="round"`);
        for (let b = 0; b < 7; b++) { const a = -Math.PI / 2 + (b - 3) * .55; k.path(`M${f1(x - 10 * s)},${f1(y - 230 * s)} q${f1(Math.cos(a) * 70 * s)},${f1(Math.sin(a) * 60 * s - 20 * s)} ${f1(Math.cos(a) * 140 * s)},${f1(Math.sin(a) * 80 * s + 40 * s)}`, 'none', `stroke="${cc}" stroke-width="${f1(10 * s)}" stroke-linecap="round"`); }
      } else if (kind === 'bare') {
        k.path(`M${f1(x)},${f1(y)} v${f1(-120 * s)} m0,${f1(40 * s)} l${f1(-50 * s)},${f1(-50 * s)} m50,${f1(50 * s)} l${f1(46 * s)},${f1(-60 * s)} m-46,${f1(-30 * s)} l${f1(-30 * s)},${f1(-50 * s)}`, 'none', `stroke="${shade(tr, .8)}" stroke-width="${f1(9 * s)}" stroke-linecap="round" stroke-linejoin="round"`);
      } else { // round
        k.rect(x - 9 * s, y - 90 * s, 18 * s, 90 * s, tr);
        k.circle(x, y - 150 * s, 74 * s, shade(cc, .85));
        k.circle(x - 30 * s, y - 130 * s, 50 * s, cc);
        k.circle(x + 34 * s, y - 168 * s, 48 * s, shade(cc, 1.1));
        k.circle(x - 10 * s, y - 180 * s, 30 * s, shade(cc, 1.18), 'opacity=".7"');
        k.shadow(x, y + 4, 90 * s, 10 * s, .3);
      }
    }
    return '';
  };

  // --- ground and floors ------------------------------------------------------------------------------
  // a floor in perspective: gradient, converging lines, seams that get denser far away, a light sheen
  k.floor = (y, col, o2 = {}) => {
    const c = o2.indoor ? k.gi(col) : k.g(col), vx = o2.vx ?? 800, vy = o2.vy ?? y - 360;
    k.vg(0, y, W, H - y, shade(c, o2.far ?? .86), shade(c, o2.near ?? 1.08));
    const kind = o2.kind || 'plain';
    if (kind === 'wood') { k.tex('planks', 0, y, W, H - y, { c: shade(c, .45), op: .55, t: 54 }); }
    else if (kind === 'tile') { k.tex('tile', 0, y, W, H - y, { c: shade(c, .55), op: .5, t: 70 }); }
    else if (kind === 'asphalt' || kind === 'concrete' || kind === 'sand' || kind === 'dirt') k.tex('speckle', 0, y, W, H - y, { op: kind === 'sand' ? .5 : .85, dens: 3200 });
    else if (kind === 'grass') {
      let q = ''; const rr = rng(hashStr(id) + 99 + seed);
      for (let j = 0; j < 150; j++) { const gx = rr() * W, gy = y + 6 + rr() * (H - y - 6), gh = 8 + (gy - y) * .06; q += `<path d="M${f1(gx)},${f1(gy)}l${f1(-3)},${f1(-gh)}M${f1(gx)},${f1(gy)}l${f1(2)},${f1(-gh * 1.1)}M${f1(gx)},${f1(gy)}l${f1(6)},${f1(-gh * .8)}" stroke="${rr() < .5 ? shade(c, 1.35) : shade(c, .6)}" stroke-width="2" stroke-linecap="round" opacity=".55"/>`; }
      k.add(q);
    }
    if (o2.persp) {
      let q = '';
      for (let j = -14; j <= 14; j++) { const x2 = vx + j * 230; q += `<line x1="${vx + j * 14}" y1="${y}" x2="${x2}" y2="${H}" stroke="${shade(c, .5)}" stroke-width="1.8" opacity="${f1(.34 - Math.abs(j) * .012) > 0 ? f1(.34 - Math.abs(j) * .012) : .05}"/>`; }
      let yy = y, step = 5;
      while (yy < H) { q += `<line x1="0" y1="${f1(yy)}" x2="${W}" y2="${f1(yy)}" stroke="${shade(c, .5)}" stroke-width="1.5" opacity=".26"/>`; yy += step; step *= 1.32; }
      k.add(q);
    }
    if (o2.edge !== false) k.rect(0, y - 1, W, 4, shade(c, .5), 'opacity=".55"');
    const wet = weather === 'rain' || weather === 'storm';
    if (wet || o2.sheen) k.sheen(y, o2.sheenC || (o2.indoor ? '#ffe9bd' : T.key), wet ? .26 : (o2.sheen || .14));
    if (weather === 'snow' && !o2.indoor && o2.snow !== false) { k.vg(0, y, W, H - y, '#f2f7fb', '#dde7f0', 'opacity=".55"'); k.rect(0, y - 1, W, 8, '#fff', 'opacity=".6"'); }
    return '';
  };
  k.sheen = (y, c, op) => { const [i, d] = defsGrad([[0, c, op], [1, c, 0]]); return k.add(`${d}<rect x="0" y="${f1(y)}" width="${W}" height="${f1(H - y)}" fill="url(#${i})"/>`); };
  k.wall = (y0, y1, col, o2 = {}) => {
    const c = o2.outdoor ? k.g(col) : k.gi(col);
    k.vg(0, y0, W, y1 - y0, shade(c, 1.06), shade(c, .9));
    if (o2.kind === 'brick') k.tex('brick', 0, y0, W, y1 - y0, { c: shade(c, .45), op: .7, s: o2.s || 1 });
    else if (o2.kind === 'tile') k.tex('tile', 0, y0, W, y1 - y0, { c: shade(c, .6), op: .55, t: o2.t || 54 });
    else if (o2.kind === 'panel') k.tex('panel', 0, y0, W, y1 - y0, { c: shade(c, .6), op: .6, t: o2.t || 120 });
    else if (o2.kind === 'metal') k.tex('metal', 0, y0, W, y1 - y0, { c: shade(c, .55), op: .7, t: o2.t || 100 });
    else if (o2.kind === 'planks') { k.tex('planks', 0, y0, W, y1 - y0, { c: shade(c, .5), op: .6, t: 60 }); }
    else if (o2.kind === 'stone') { k.tex('brick', 0, y0, W, y1 - y0, { c: shade(c, .5), op: .75, s: 2.2 }); k.tex('speckle', 0, y0, W, y1 - y0, { op: .8, dens: 2600 }); }
    else if (o2.kind === 'none') { /* plain */ }
    else k.tex('speckle', 0, y0, W, y1 - y0, { op: .7, dens: 4200 });
    if (o2.occlude !== false) { const [i, d] = defsGrad([[0, '#000', 0], [1, '#000', .22]]); k.add(`${d}<rect x="0" y="${f1(y1 - 90)}" width="${W}" height="90" fill="url(#${i})"/>`); const [j, e] = defsGrad([[0, '#000', .2], [1, '#000', 0]]); k.add(`${e}<rect x="0" y="${f1(y0)}" width="${W}" height="70" fill="url(#${j})"/>`); }
    return '';
  };
  k.baseboard = (y, c, h = 16) => { k.rect(0, y - h, W, h, shade(k.gi(c), .9)); k.rect(0, y - h, W, 3, '#fff', 'opacity=".12"'); k.rect(0, y - 3, W, 3, '#000', 'opacity=".25"'); return ''; };
  k.wainscot = (y0, y1, c) => { const cc = k.gi(c); k.vg(0, y0, W, y1 - y0, shade(cc, 1.05), shade(cc, .88)); k.tex('panel', 0, y0, W, y1 - y0, { c: shade(cc, .55), op: .6, t: 130 }); k.rect(0, y0 - 6, W, 8, shade(cc, 1.15)); k.rect(0, y0 + 2, W, 2, '#000', 'opacity=".25"'); return ''; };

  // --- lights -----------------------------------------------------------------------------------------
  k.lamp = (x, y, rad = 150, c = '#ffd76b', op = .55) => (k.lampK < .2 ? '' : k.glow(x, y, rad, c, op * Math.min(1, .25 + k.lampK)));
  k.lampIn = (x, y, rad = 220, c = '#ffe2a8', op) => k.glow(x, y, rad, c, op ?? (.28 + .3 * k.lampK));
  k.window = (x, y, w, h, o2 = {}) => {
    const [a, b] = k.skyColors(), i = uid();
    const frame = k.gi(o2.frame || '#e8e2d6');
    k.add(`<defs><clipPath id="${i}"><rect x="${x}" y="${y}" width="${w}" height="${h}"/></clipPath></defs><g clip-path="url(#${i})">`);
    k.vg(x, y, w, h, a, b);
    if (T.stars) { let q = ''; for (let j = 0; j < 14; j++) q += `<circle cx="${f1(x + r() * w)}" cy="${f1(y + r() * h * .6)}" r="1.4" fill="#fff" opacity=".8"/>`; k.add(q); }
    if (T.sun && weather === 'clear') k.glow(x + w * .7, y + h * .55, w * .6, T.sun.c, .5);
    if (T.moon && weather === 'clear') k.circle(x + w * .72, y + h * .28, Math.min(w, h) * .12, '#f6f2d4');
    if (o2.view === 'nature') {
      const base = y + h;
      k.poly([[x - 10, base], [x - 10, base - h * .3], [x + w * .3, base - h * .5], [x + w * .6, base - h * .32], [x + w + 10, base - h * .46], [x + w + 10, base]], k.g('#6a8a7a'));
      k.poly([[x - 10, base], [x - 10, base - h * .16], [x + w * .5, base - h * .26], [x + w + 10, base - h * .12], [x + w + 10, base]], k.g('#4f8a4a'));
      for (let a = 0; a < 5; a++) { const tx = x + 14 + a * (w / 5), ts = .5 + (a % 3) * .2; k.rect(tx - 2, base - h * .22 - 14 * ts, 4, 14 * ts + 6, k.g('#5a3b24')); k.circle(tx, base - h * .22 - 22 * ts, 16 * ts, k.g('#3f8a4a')); }
    } else if (o2.view !== 'none') {
      const base = y + h, rr = rng(hashStr(id) + x);
      let bx = x - 10;
      const bc = k.g(o2.city || '#6f86a8');
      while (bx < x + w) { const bw = 30 + rr() * 50, bh = h * (.18 + rr() * .4); k.rect(bx, base - bh, bw, bh, shade(bc, .85 + rr() * .3)); if (k.lampK > .4) { let q = ''; for (let a2 = 0; a2 < 3; a2++) for (let b2 = 0; b2 < Math.floor(bh / 26); b2++) if (rr() < .35) q += `<rect x="${f1(bx + 6 + a2 * 14)}" y="${f1(base - bh + 8 + b2 * 26)}" width="8" height="12" fill="#ffd76b" opacity=".9"/>`; k.add(q); } bx += bw + 3; }
    }
    if (weather === 'rain' || weather === 'storm') { let q = ''; for (let j = 0; j < 30; j++) { const rx = x + r() * w, ry = y + r() * h; q += `<line x1="${f1(rx)}" y1="${f1(ry)}" x2="${f1(rx - 5)}" y2="${f1(ry + 22)}" stroke="#cfe3f5" stroke-width="1.6" opacity=".5"/>`; } k.add(q); }
    k.add('</g>');
    const [gi2, gd] = defsGrad([[0, '#fff', .22], [.5, '#fff', 0], [1, '#fff', 0]], 0, 0, 1, 1);
    k.add(`${gd}<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="url(#${gi2})"/>`);
    const fw = o2.fw ?? 10;
    k.add(`<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="none" stroke="${frame}" stroke-width="${fw}"/>`);
    if (o2.bars !== false) { const nx = o2.cols ?? 2, ny = o2.rows ?? 2; let q = ''; for (let j = 1; j < nx; j++) q += `<rect x="${f1(x + w * j / nx - fw / 4)}" y="${y}" width="${fw / 2}" height="${h}" fill="${frame}"/>`; for (let j = 1; j < ny; j++) q += `<rect x="${x}" y="${f1(y + h * j / ny - fw / 4)}" width="${w}" height="${fw / 2}" fill="${frame}"/>`; k.add(q); }
    k.rect(x - 8, y + h, w + 16, 10, shade(frame, .85), 'rx="2"');
    // light spilling in
    if (o2.spill !== false && k.lampK < .6 && weather !== 'storm') k.shaft(x + w / 2, y + h, w * .9, 360, T.key, weather === 'clear' ? .2 : .08, 2.2);
    return '';
  };
  k.door = (x, y, w, h, c, o2 = {}) => {
    const cc = k.gi(c);
    k.rect(x - 8, y - 8, w + 16, h + 8, shade(cc, .75));
    k.vg(x, y, w, h, shade(cc, 1.08), shade(cc, .86), 'stroke="#101420" stroke-opacity=".4" stroke-width="2"');
    k.rect(x + w * .12, y + h * .08, w * .76, h * .34, '#000', 'opacity=".12"');
    k.rect(x + w * .12, y + h * .52, w * .76, h * .38, '#000', 'opacity=".12"');
    if (o2.glass) k.rect(x + w * .18, y + h * .12, w * .64, h * .26, k.g('#bfe6ff'), 'opacity=".75"');
    k.circle(x + w * .85, y + h * .54, 5, '#d9b84a');
    return '';
  };
  k.person = (x, y, s = 1, col = '#4a5570', o2 = {}) => { // a far, soft silhouette (background crowd), feet at y
    const c = k.g(col), hd = k.g(o2.skin || '#8a6a55');
    k.shadow(x, y, 26 * s, 5 * s, .3);
    k.rect(x - 8 * s, y - 40 * s, 6 * s, 40 * s, shade(c, .8), 'rx="2"');
    k.rect(x + 2 * s, y - 40 * s, 6 * s, 40 * s, shade(c, .7), 'rx="2"');
    k.vg(x - 14 * s, y - 100 * s, 28 * s, 64 * s, shade(c, 1.1), shade(c, .85), 'rx="9"');
    k.circle(x, y - 114 * s, 12 * s, hd);
    k.path(`M${f1(x - 12 * s)},${f1(y - 116 * s)} q${f1(12 * s)},${f1(-18 * s)} ${f1(24 * s)},0 z`, shade(c, .5));
    return '';
  };
  k.crowd = (y, n, x0 = 0, x1 = W, s = .8, cols) => {
    const rr = rng(hashStr(id) + seed * 3 + 41), cs = cols || ['#4a5570', '#7a4a5a', '#3f6a5a', '#8a7a4a', '#5a4a7a', '#6a6a78'];
    const a = []; for (let j = 0; j < n; j++) a.push([x0 + rr() * (x1 - x0), cs[Math.floor(rr() * cs.length)], s * (.85 + rr() * .3)]);
    a.sort((p, q) => p[2] - q[2]);
    for (const [px, pc, ps] of a) k.person(px, y + (ps - s) * 30, ps, pc, { skin: ['#8a6a55', '#c89a78', '#5a3b2e', '#e0b898'][Math.floor(rr() * 4)] });
    return '';
  };
  k.car = (x, y, s = 1, col = '#c0392b', o2 = {}) => { // side view, wheels on y
    const c = k.g(col), face = o2.flip ? -1 : 1;
    k.shadow(x, y + 4, 150 * s, 12 * s, .4);
    k.add(`<g transform="translate(${f1(x)},${f1(y)}) scale(${f1(face * s)},${f1(s)})">`);
    k.add(`<path d="M-130,-8 L-130,-44 Q-120,-56 -92,-58 L-60,-88 Q-50,-98 -30,-98 L50,-98 Q70,-98 82,-84 L110,-58 Q132,-54 134,-36 L134,-8 Z" fill="${c}" stroke="#101420" stroke-opacity=".55" stroke-width="4"/>`);
    k.add(`<path d="M-50,-84 L-34,-92 L40,-92 L72,-60 L-72,-60 Z" fill="${k.g('#9fd2f0')}" stroke="#101420" stroke-opacity=".5" stroke-width="3"/><path d="M-2,-92 V-60" stroke="${shade(c, .6)}" stroke-width="5"/>`);
    k.add(`<rect x="-130" y="-30" width="264" height="12" fill="#000" opacity=".16"/><rect x="108" y="-44" width="22" height="9" fill="${k.lampK > .4 ? '#fff3b0' : '#e8e8e8'}"/><rect x="-132" y="-44" width="14" height="9" fill="#e84a3a"/>`);
    for (const wx of [-78, 78]) k.add(`<circle cx="${wx}" cy="-4" r="26" fill="#14161c"/><circle cx="${wx}" cy="-4" r="13" fill="#a9afb8"/><circle cx="${wx}" cy="-4" r="4" fill="#555c66"/>`);
    k.add('</g>');
    if (k.lampK > .4) k.glow(x + face * 130 * s, y - 40 * s, 140 * s, '#fff3b0', .4);
    return '';
  };
  k.streetLamp = (x, y, h = 300, o2 = {}) => {
    const c = k.g(o2.c || '#2a2f3c');
    k.shadow(x, y + 2, 24, 4, .35);
    k.rect(x - 5, y - h, 10, h, c);
    k.rect(x - 14, y - 16, 28, 16, shade(c, 1.2));
    k.path(`M${x},${y - h} q0,-40 40,-40`, 'none', `stroke="${c}" stroke-width="8" stroke-linecap="round"`);
    k.rect(x + 20, y - h - 46, 44, 12, shade(c, 1.1), 'rx="5"');
    if (k.lampK > .2) { k.glow(x + 42, y - h - 30, 190, '#ffd98a', .5 * Math.min(1, k.lampK + .2)); k.shaft(x + 42, y - h - 30, 40, h + 20, '#ffe8b0', .22 * k.lampK, 4); }
    return '';
  };
  k.sign = (x, y, w, h, text, bg = '#12263f', fg = '#ffd54a', size = 28) => {
    k.vg(x, y, w, h, shade(k.gi(bg), 1.1), shade(k.gi(bg), .85), 'rx="6" stroke="#0a0e18" stroke-width="3"');
    if (text) k.add(`<text x="${f1(x + w / 2)}" y="${f1(y + h / 2 + size * .35)}" text-anchor="middle" font-family="Arial Black,Arial,sans-serif" font-weight="900" font-size="${size}" fill="${fg}">${String(text).replace(/[<>&]/g, '')}</text>`);
    return '';
  };
  k.neon = (x, y, w, h, text, c = '#ff3d9a', size = 36) => {
    const lit = !k.out || k.lampK > .5;
    const col = lit ? c : mix(c, '#888', .5);
    k.glow(x + w / 2, y + h / 2, Math.max(w, h) * .9, c, lit ? .5 : .12);
    k.add(`<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="8" fill="#0c0f1c" stroke="${col}" stroke-width="4"/>`);
    if (text) k.add(`<text x="${f1(x + w / 2)}" y="${f1(y + h / 2 + size * .35)}" text-anchor="middle" font-family="Arial Black,Arial,sans-serif" font-size="${size}" font-weight="900" fill="${col}">${String(text).replace(/[<>&]/g, '')}</text>`);
    return '';
  };
  k.plant = (x, y, s = 1, col = '#3f8a4a') => {
    const c = k.gi(col), pot = k.gi('#9a5b3a');
    k.shadow(x, y + 3, 40 * s, 6 * s, .35);
    for (let j = 0; j < 7; j++) { const a = -Math.PI / 2 + (j - 3) * .42; k.path(`M${f1(x)},${f1(y - 50 * s)} q${f1(Math.cos(a) * 50 * s)},${f1(Math.sin(a) * 70 * s)} ${f1(Math.cos(a) * 62 * s)},${f1(Math.sin(a) * 100 * s)}`, 'none', `stroke="${shade(c, .8 + (j % 3) * .15)}" stroke-width="${f1(14 * s)}" stroke-linecap="round"`); }
    k.poly([[x - 26 * s, y - 52 * s], [x + 26 * s, y - 52 * s], [x + 20 * s, y], [x - 20 * s, y]], pot, 'stroke="#101420" stroke-opacity=".4" stroke-width="3"');
    return '';
  };
  k.box = (x, y, w, h, c) => { const cc = k.gi(c); k.shadow(x + w / 2, y + h + 2, w * .65, 6, .3); k.obj(x, y, w, h, cc, { r: 3 }); k.rect(x + w * .42, y, w * .16, h, '#000', 'opacity=".12"'); return ''; };

  // --- weather, finish --------------------------------------------------------------------------------
  k.weatherLayer = () => {
    if (!k.out) return;
    const rr = rng(hashStr(id) + seed + 7);
    if (X.fog) { k.vg(0, 300, W, 520, '#e6ecf2', '#e6ecf2', 'opacity="0"'); const [i, d] = defsGrad([[0, '#e8eef4', 0], [.5, '#e8eef4', .55], [1, '#e8eef4', .2]]); k.add(`${d}<rect x="0" y="260" width="${W}" height="560" fill="url(#${i})"/>`); }
    if (X.rain) { let q = ''; for (let j = 0; j < X.rain; j++) { const x = rr() * (W + 100), y = rr() * H, l = 30 + rr() * 40; q += `<line x1="${f1(x)}" y1="${f1(y)}" x2="${f1(x - l * .22)}" y2="${f1(y + l)}" stroke="#d6e6f5" stroke-width="${f1(1.2 + rr() * 1.2)}" opacity="${f1(.2 + rr() * .3)}"/>`; } k.add(q); }
    if (X.snow) { let q = ''; for (let j = 0; j < X.snow; j++) q += `<circle cx="${f1(rr() * W)}" cy="${f1(rr() * H)}" r="${f1(1.6 + rr() * 3.2)}" fill="#fff" opacity="${f1(.5 + rr() * .5)}"/>`; k.add(q); }
    if (X.flash) k.glow(rd(300, 1300), 120, 520, '#e6f0ff', .16);
  };
  k.finish = () => {
    k.layer('weather', () => k.weatherLayer());
    k.layer('finish', () => {
      const [i, d] = defsGrad([[0, '#000', 0], [.62, '#000', 0], [1, '#000', k.night ? .5 : .32]], 0, 0, 0, 0, 'radialGradient', 'cx="0.5" cy="0.5" r="0.75"');
      k.add(`${d}<rect width="${W}" height="${H}" fill="url(#${i})"/>`);
      if (T.tk) k.add(`<rect width="${W}" height="${H}" fill="${T.tint}" opacity="${f1(T.tk * .14 * 100) / 100}"/>`);
    });
  };
  return k;
}

/** Wraps layers into one SVG fragment (what the engine draws as the background). */
export function composeSvg(k) {
  return `<g data-bgpolish="library" data-place="${k.id}" data-time="${k.time}" data-weather="${k.weather}" data-seed="${k.seed}">` + k.layers.map((L) => `<g data-layer="${L.name}">${L.s}</g>`).join('') + '</g>';
}
