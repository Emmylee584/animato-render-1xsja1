// BACKGROUND MUSIC, MADE BY THE APP (Web Audio only: no music files, no downloads, no licences, nothing that can be claimed by Content ID).
//
// Every film gets its own score, written from its scenes:
//   - ONE key for the whole film (from the film's title), so a mood change never jumps to a foreign key.
//   - each scene's mood picks the chords, the tempo and the instruments: warm, hopeful, calm, sad, mystery, tense, hype, epic, playful.
//     The AI can name it (beat({..., music:'tense'})) or a whole film (movie({..., music:'hopeful'})); otherwise it comes from the scene's
//     mood word (m:'night', m:'tense', ...) and the words said.
//   - scenes with the same mood play as one section; a new mood crossfades in over a bar.
//   - it starts at once (the first second is the hook), and ends on a held chord that fades out.
// Soft on purpose: warm pads, a felt-piano line, a round bass; no harsh highs. In the export it sinks under the narrator's voice.
//
//   musicPlan(S)                  {events, segs, bpm...}: every note of the film. S = {SC, st, total, title?, music?}. Pure and deterministic.
//   renderMusicInto(narr,S,rate,level)  adds the score under a mono narration track in place, 30 s at a time (low memory), ducking under speech.
//   livePlayer(ctx, dest)         the preview: player.tick(T, playing) schedules the notes a moment ahead, follows seeks and pauses.

const num = (v, d = 0) => (Number.isFinite(+v) ? +v : d);
const cl = (v, a, b) => Math.max(a, Math.min(b, v));

export const LEVELS = { off: 0, soft: 0.55, normal: 1 };
export const DEFAULT_LEVEL = 'normal';
export const levelOf = (v) => (Object.prototype.hasOwnProperty.call(LEVELS, v) ? v : DEFAULT_LEVEL);
export const MOODS = ['warm', 'hopeful', 'calm', 'sad', 'mystery', 'tense', 'hype', 'epic', 'playful'];

const MAJ = [0, 2, 4, 5, 7, 9, 11], MIN = [0, 2, 3, 5, 7, 8, 10];
/**
 * the recipe of each mood: scale, tempo, chord degrees (one chord a bar), and which instruments play.
 *  pad: filter brightness; keys: the felt-piano line ('arp8' | 'arp4' | 'bar' | 0); bass: 'bar' | 'half' | 'pulse8' | 0; kick: 'four' | 'half' | 'heart' | 0; shaker: 0 | 1
 */
const R = {
  warm:    { sc: MAJ, bpm: 84,  ch: [0, 4, 5, 3], pad: 1300, keys: 'arp4', bass: 'bar', kick: 0, shaker: 0, gain: .9 },
  hopeful: { sc: MAJ, bpm: 92,  ch: [0, 3, 5, 4], pad: 1700, keys: 'arp8', bass: 'half', kick: 'half', shaker: 0, gain: .9 },
  calm:    { sc: MAJ, bpm: 70,  ch: [0, 3, 0, 4], pad: 1000, keys: 'bar', bass: 'bar', kick: 0, shaker: 0, gain: .8 },
  sad:     { sc: MIN, bpm: 68,  ch: [0, 5, 2, 6], pad: 900, keys: 'bar', bass: 'bar', kick: 0, shaker: 0, gain: .85 },
  mystery: { sc: MIN, bpm: 76,  ch: [0, 0, 5, 4], pad: 750, keys: 'arp4', bass: 'pulse8', kick: 0, shaker: 0, gain: .8 },
  tense:   { sc: MIN, bpm: 96,  ch: [0, 0, 5, 4], pad: 700, keys: 0, bass: 'pulse8', kick: 'heart', shaker: 0, gain: .85 },
  hype:    { sc: MIN, bpm: 112, ch: [5, 3, 0, 4], pad: 1900, keys: 'arp8', bass: 'pulse8', kick: 'four', shaker: 1, gain: .95 },
  epic:    { sc: MIN, bpm: 88,  ch: [0, 5, 2, 6], pad: 1500, keys: 'arp4', bass: 'half', kick: 'half', shaker: 0, gain: 1 },
  playful: { sc: MAJ, bpm: 104, ch: [0, 5, 1, 4], pad: 1600, keys: 'arp8', bass: 'half', kick: 0, shaker: 1, gain: .85 },
};
/** words -> mood (the scene's own music:'' wins, then the film's, then the scene's mood word, then what is said) */
const WORDS = [
  ['tense', /\b(tense|danger\w*|fear\w*|scared|scary|threat\w*|chase\w*|panic\w*|storm\w*|alarm\w*|attack\w*|suspense|urgent|angry|rage|horror|creep\w*)\b/],
  ['sad', /\b(sad\w*|cold|lonely|alone|grief|griev\w*|cry\w*|tears?|loss|lost|funeral|died|death|broken|heartbreak\w*|rain\w*|regret\w*|sorrow)\b/],
  ['hype', /\b(hype|party|celebrat\w*|win\w*|won|victory|cheer\w*|success\w*|viral|million\w*|rich|money|boss|fast|energy|dance\w*)\b/],
  ['epic', /\b(epic|battle|war|hero\w*|legend\w*|climax|final|rise|rising|power\w*|army|king|queen|destiny|empire)\b/],
  ['mystery', /\b(myster\w*|secret\w*|dark|night|midnight|shadow\w*|strange|unknown|hidden|clue\w*|suddenly|noticed|whisper\w*|moon\w*)\b/],
  ['playful', /\b(funny|playful|silly|joke\w*|laugh\w*|prank\w*|cute|kids?|puppy|cat|silly|giggl\w*)\b/],
  ['calm', /\b(calm|peace\w*|quiet|morning|gentle|soft|relax\w*|slow\w*|sleep\w*|dream\w*|breath\w*)\b/],
  ['hopeful', /\b(hope\w*|new|began|begin\w*|start\w*|future|tomorrow|finally|believe\w*|dream|change\w*|chance|better|grow\w*)\b/],
  ['warm', /\b(warm|happy|love\w*|family|home|friend\w*|smile\w*|sun\w*|kind\w*|together|thank\w*)\b/],
];
export function moodOf(sc, film) {
  const own = String((sc && sc.music) || '').toLowerCase().trim();
  if (R[own]) return own;
  if (own === 'none' || own === 'off') return 'none';
  const f = String(film || '').toLowerCase().trim(); if (R[f]) return f;
  const m = String((sc && sc.mood) || '').toLowerCase();
  for (const [k, re] of WORDS) if (re.test(m)) return k;
  const said = (String((sc && (sc.narration || sc.name)) || '') + ' ' + ((sc && sc.captions) || []).map((c) => c && c.text).join(' ')).toLowerCase();
  let best = null, n = 0;
  for (const [k, re] of WORDS) { const g = said.match(new RegExp(re.source, 'g')); if (g && g.length > n) { n = g.length; best = k; } }
  return best || 'warm';
}
function hash(s) { let h = 2166136261; s = String(s || ''); for (let k = 0; k < s.length; k++) { h ^= s.charCodeAt(k); h = Math.imul(h, 16777619); } return h >>> 0; }
function rng(seed) { let a = seed >>> 0 || 1; return () => { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
const hz = (m) => 440 * Math.pow(2, (m - 69) / 12);
function startsOf(S) {
  if (Array.isArray(S.st) && S.st.length) return S.st;
  let T = 0; return (S.SC || []).map((sc) => { const t = T; T += Math.max(.5, num(sc && sc.duration, 5)); return t; });
}

/** every note of the film */
export function musicPlan(S) {
  const SC = (S && S.SC) || [], st = startsOf(S || {}), total = num(S && S.total, st.length ? st[st.length - 1] + 5 : 30);
  const film = S && (S.music || (S.meta && S.meta.music));
  if (String(film || '').toLowerCase() === 'none' || String(film || '').toLowerCase() === 'off') return { events: [], segs: [], total };
  const seed = hash((S && S.title) || SC.map((s) => s && (s.narration || s.name)).join('|').slice(0, 400));
  const r = rng(seed);
  const tonic = 57 + Math.floor(r() * 7);           // A3..D#4 for the major moods; the minor moods use the relative minor (same notes)
  // sections: neighbouring scenes with the same mood
  const segs = [];
  /* when the AI directs the music (movie music:'' or a beat's music:''), a cue holds until the next cue, like a composer's score;
     otherwise each scene's mood is read from its mood word and its words */
  const directed = R[String(film || '').toLowerCase().trim()] || SC.some((sc) => sc && typeof sc.music === 'string' && sc.music.trim());
  let held = R[String(film || '').toLowerCase().trim()] ? String(film).toLowerCase().trim() : null;
  SC.forEach((sc, i) => {
    let m;
    if (directed) { const own = String((sc && sc.music) || '').toLowerCase().trim(); if (own === 'none' || own === 'off') m = 'none'; else { if (R[own]) held = own; m = held || moodOf(sc, null); if (!held) held = m; } }   // 'none' = this beat only (a breath of silence before a reveal)
    else m = moodOf(sc, film);
    const a = num(st[i]), b = st[i + 1] != null ? num(st[i + 1]) : total;
    const last = segs[segs.length - 1];
    if (last && last.mood === m) last.end = b; else segs.push({ mood: m, start: a, end: b });
  });
  if (!segs.length) segs.push({ mood: moodOf(null, film), start: 0, end: total });
  // a very short section (< 4 s) takes the mood of the one before it, so the music does not flicker
  for (let i = 1; i < segs.length; i++) if (segs[i].end - segs[i].start < 4) { segs[i - 1].end = segs[i].end; segs.splice(i--, 1); }
  for (let i = 1; i < segs.length; i++) if (segs[i].mood === segs[i - 1].mood) { segs[i - 1].end = segs[i].end; segs.splice(i--, 1); }
  const ev = [];
  const XF = 1.6;   // crossfade seconds
  segs.forEach((g, gi) => {
    if (g.mood === 'none') return;
    const rc = R[g.mood], minor = rc.sc === MIN, root = minor ? tonic - 3 : tonic, beat = 60 / rc.bpm, bar = beat * 4;
    const from = Math.max(0, g.start - (gi ? XF / 2 : 0)), to = Math.min(total + 2.5, g.end + (gi < segs.length - 1 ? XF / 2 : 2.5));
    const fadeIn = gi ? XF : .35, fadeOut = gi < segs.length - 1 ? XF : 2.5;
    const gain = (t) => rc.gain * cl((t - from) / fadeIn, 0, 1) * cl((to - t) / fadeOut, 0, 1) * (1 + .12 * cl((t - total * .7) / (total * .3 + 1e-6), 0, 1));
    const deg = (d, oct = 0) => root + 12 * oct + rc.sc[((d % 7) + 7) % 7] + 12 * Math.floor(d / 7);
    const chord = (c) => [deg(c), deg(c + 2), deg(c + 4)];
    const nb = Math.ceil((to - from) / bar);
    for (let b = 0; b < nb; b++) {
      const t0 = from + b * bar; if (t0 >= to) break;
      const c = rc.ch[b % rc.ch.length], notes = chord(c), gv = gain(t0 + bar / 2); if (gv <= .001) continue;
      // PAD: the chord, held for the bar, voiced around middle C
      for (const n of notes) ev.push({ t: t0, dur: bar + .25, inst: 'pad', f: hz(n), v: .055 * gv, cut: rc.pad, seg: gi });
      // BASS
      const bn = hz(deg(c) - 24);
      if (rc.bass === 'bar') ev.push({ t: t0, dur: bar * .95, inst: 'bass', f: bn, v: .16 * gv, seg: gi });
      else if (rc.bass === 'half') for (let h = 0; h < 2; h++) ev.push({ t: t0 + h * bar / 2, dur: bar / 2 * .9, inst: 'bass', f: bn, v: .15 * gv, seg: gi });
      else if (rc.bass === 'pulse8') for (let e = 0; e < 8; e++) ev.push({ t: t0 + e * beat / 2, dur: beat / 2 * .7, inst: 'pulse', f: bn * 2, v: (e % 2 ? .05 : .07) * gv, cut: rc.pad * .8, seg: gi });
      // KEYS: a felt piano
      if (rc.keys === 'bar') { ev.push({ t: t0, dur: bar * 1.4, inst: 'keys', f: hz(notes[2] + 12), v: .06 * gv, seg: gi }); if (r() < .6) ev.push({ t: t0 + beat * 2, dur: bar, inst: 'keys', f: hz(notes[1] + 12), v: .045 * gv, seg: gi }); }
      else if (rc.keys === 'arp4' || rc.keys === 'arp8') {
        const step = rc.keys === 'arp8' ? beat / 2 : beat, k = Math.round(bar / step), pat = [0, 1, 2, 1, 2, 0, 1, 2];
        for (let e = 0; e < k; e++) { if (rc.keys === 'arp8' && e % 2 && r() < .35) continue; const n = notes[pat[e % pat.length]] + 12 + (e >= k - 1 && r() < .3 ? 12 : 0); ev.push({ t: t0 + e * step, dur: step * 2.2, inst: 'keys', f: hz(n), v: (e % 4 === 0 ? .055 : .038) * gv, seg: gi }); }
      }
      // DRUMS (soft, round: no clicks)
      if (rc.kick === 'four') for (let e = 0; e < 4; e++) ev.push({ t: t0 + e * beat, dur: .3, inst: 'kick', f: 60, v: .2 * gv, seg: gi });
      else if (rc.kick === 'half') for (let e = 0; e < 2; e++) ev.push({ t: t0 + e * 2 * beat, dur: .35, inst: 'kick', f: 55, v: .17 * gv, seg: gi });
      else if (rc.kick === 'heart') for (let e = 0; e < 2; e++) { ev.push({ t: t0 + e * 2 * beat, dur: .25, inst: 'kick', f: 52, v: .16 * gv, seg: gi }); ev.push({ t: t0 + e * 2 * beat + .22, dur: .2, inst: 'kick', f: 48, v: .1 * gv, seg: gi }); }
      if (rc.shaker) for (let e = 0; e < 8; e++) ev.push({ t: t0 + e * beat / 2, dur: .07, inst: 'shaker', f: 0, v: (e % 2 ? .02 : .012) * gv, seg: gi });
    }
  });
  // the end: one held chord that rings out
  const lastSeg = segs[segs.length - 1];
  if (lastSeg && lastSeg.mood !== 'none') {
    const rc = R[lastSeg.mood], minor = rc.sc === MIN, root = minor ? tonic - 3 : tonic;
    for (const n of [0, 4, 7].map((x, i) => root + (minor && i === 1 ? 3 : x))) ev.push({ t: Math.max(0, total - .4), dur: 3, inst: 'pad', f: hz(n), v: .05, cut: rc.pad * .8, seg: segs.length - 1 });
  }
  ev.sort((a, b) => a.t - b.t);
  return { events: ev.filter((e) => e.t < total + 2.5), segs, total, tonic };
}

/* ------------------------------------------------------------------ the instruments ---- */
const NB = new WeakMap();
function noiseOf(ctx) { let b = NB.get(ctx); if (b) return b; const sr = ctx.sampleRate, n = sr, r = rng(99); b = ctx.createBuffer(1, n, sr); const d = b.getChannelData(0); for (let i = 0; i < n; i++) d[i] = r() * 2 - 1; NB.set(ctx, b); return b; }
function env(g, t, a, peak, hold, rel) { g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(peak, t + a); if (hold > a) g.gain.setValueAtTime(peak, t + hold); g.gain.exponentialRampToValueAtTime(0.0001, t + Math.max(a + .02, hold) + rel); }
/** one note on `ctx` at context time `t` (with `skip` seconds of it already gone, for a note joined in the middle) */
function playNote(ctx, out, e, t, skip = 0) {
  const dur = Math.max(.05, e.dur - skip), stop = t + dur + 2;
  if (e.inst === 'pad') {
    const f = ctx.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = e.cut || 1200; f.Q.value = .4;
    const g = ctx.createGain(); env(g, t, skip ? .2 : Math.min(1.2, dur * .4), e.v, dur * .8, 1.4);
    for (const [type, det] of [['sawtooth', -7], ['triangle', 6]]) { const o = ctx.createOscillator(); o.type = type; o.frequency.value = e.f; o.detune.value = det; const og = ctx.createGain(); og.gain.value = type === 'sawtooth' ? .5 : 1; o.connect(og); og.connect(f); o.start(t); o.stop(stop); }
    f.connect(g); g.connect(out);
  } else if (e.inst === 'keys') {
    const g = ctx.createGain(), f = ctx.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = 2400; f.Q.value = .3;
    g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(e.v, t + .006); g.gain.exponentialRampToValueAtTime(e.v * .25, t + .35); g.gain.exponentialRampToValueAtTime(0.0001, t + Math.max(.5, dur) + .4);
    for (const [type, mul, lv] of [['sine', 1, 1], ['triangle', 2, .18], ['sine', 3, .05]]) { const o = ctx.createOscillator(); o.type = type; o.frequency.value = e.f * mul; const og = ctx.createGain(); og.gain.value = lv; o.connect(og); og.connect(f); o.start(t); o.stop(t + Math.max(.5, dur) + .5); }
    f.connect(g); g.connect(out);
  } else if (e.inst === 'bass') {
    const o = ctx.createOscillator(), f = ctx.createBiquadFilter(), g = ctx.createGain(); o.type = 'triangle'; o.frequency.value = e.f; f.type = 'lowpass'; f.frequency.value = 380;
    env(g, t, .03, e.v, dur * .85, .25); o.connect(f); f.connect(g); g.connect(out); o.start(t); o.stop(t + dur + .4);
  } else if (e.inst === 'pulse') {
    const o = ctx.createOscillator(), f = ctx.createBiquadFilter(), g = ctx.createGain(); o.type = 'sawtooth'; o.frequency.value = e.f; f.type = 'lowpass'; f.frequency.value = e.cut || 700; f.Q.value = 2;
    env(g, t, .01, e.v, .02, Math.max(.08, dur)); o.connect(f); f.connect(g); g.connect(out); o.start(t); o.stop(t + dur + .3);
  } else if (e.inst === 'kick') {
    const o = ctx.createOscillator(), g = ctx.createGain(); o.type = 'sine'; o.frequency.setValueAtTime(e.f * 1.6, t); o.frequency.exponentialRampToValueAtTime(e.f * .7, t + .12);
    g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(e.v, t + .008); g.gain.exponentialRampToValueAtTime(0.0001, t + dur); o.connect(g); g.connect(out); o.start(t); o.stop(t + dur + .05);
  } else if (e.inst === 'shaker') {
    const s = ctx.createBufferSource(), f = ctx.createBiquadFilter(), g = ctx.createGain(); s.buffer = noiseOf(ctx); s.loop = true; f.type = 'bandpass'; f.frequency.value = 5500; f.Q.value = .8;
    g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(e.v, t + .012); g.gain.exponentialRampToValueAtTime(0.0001, t + .07); s.connect(f); f.connect(g); g.connect(out); s.start(t); s.stop(t + .1);
  }
}
/** the music's own small chain: soft top, a little room, gentle glue */
function master(ctx, dest, level) {
  const inp = ctx.createGain(), lp = ctx.createBiquadFilter(), comp = ctx.createDynamicsCompressor(), out = ctx.createGain();
  lp.type = 'lowpass'; lp.frequency.value = 7000; lp.Q.value = .4;
  comp.threshold.value = -20; comp.knee.value = 14; comp.ratio.value = 2.5; comp.attack.value = .02; comp.release.value = .3;
  out.gain.value = level;
  inp.connect(lp); lp.connect(comp);
  try {
    const sr = ctx.sampleRate, n = Math.round(sr * 1.3), b = ctx.createBuffer(1, n, sr), d = b.getChannelData(0), r = rng(5); let l = 0;
    for (let i = 0; i < n; i++) { l += .2 * ((r() * 2 - 1) - l); d[i] = l * Math.exp(-i / sr * 3); }
    const cv = ctx.createConvolver(); cv.normalize = true; cv.buffer = b; const wet = ctx.createGain(); wet.gain.value = .28; lp.connect(cv); cv.connect(wet); wet.connect(comp);
  } catch (e) { /* no room on this browser */ }
  comp.connect(out); out.connect(dest);
  return { inp, out };
}

/* ------------------------------------------------------------------ export ---- */
/**
 * Adds the score under `narr` (a mono Float32Array at `rate`) in place. Rendered 30 s at a time with a short run-up, so a 10-minute film
 * never holds more than one slice of music in memory. The music sinks under the narrator's voice (to about a third) and comes back up
 * in the pauses.
 */
export async function renderMusicInto(narr, S, rate = 48000, level = DEFAULT_LEVEL, Offline = globalThis.OfflineAudioContext) {
  const L = LEVELS[levelOf(level)]; if (!narr || !L || !Offline) return narr;
  const plan = musicPlan(S); if (!plan.events.length) return narr;
  /* the music has nothing above 7 kHz, so it is made at half the rate (half the work on a phone) and stretched back when it is mixed */
  const n = narr.length, CH = 30, PRE = 6, mr = rate >= 32000 ? Math.round(rate / 2) : rate, ratio = mr / rate;
  const state = { env: 0 }, atk = 1 - Math.exp(-1 / (rate * .04)), rel = 1 - Math.exp(-1 / (rate * .3)), K = .5 * L;
  let ei = 0;
  for (let a = 0; a < n / rate; a += CH) {
    const b = Math.min(n / rate, a + CH), from = Math.max(0, a - PRE);
    const oc = new Offline(1, Math.ceil((b - from) * mr) + 2, mr), m = master(oc, oc.destination, 1);
    while (ei < plan.events.length && plan.events[ei].t + plan.events[ei].dur + 3 < from) ei++;
    for (let k = ei; k < plan.events.length; k++) { const e = plan.events[k]; if (e.t >= b) break; if (e.t + e.dur + 3 < from) continue; if (e.t >= from) playNote(oc, m.inp, e, e.t - from); }
    const buf = await oc.startRendering(), d = buf.getChannelData(0), off = (a - from) * mr, i0 = Math.round(a * rate), i1 = Math.min(n, Math.round(b * rate));
    const at = (j) => { const x = off + (j - i0) * ratio, k = Math.floor(x), f = x - k; return (d[k] || 0) * (1 - f) + (d[k + 1] || 0) * f; };
    // duck under the voice: a smooth follower of the narration's loudness
    const win = Math.max(1, Math.round(rate * .02));
    for (let i = i0; i < i1; i += win) {
      let s = 0; const e = Math.min(i1, i + win); for (let j = i; j < e; j += 4) s += narr[j] * narr[j];
      const r = Math.sqrt(s / Math.max(1, (e - i) / 4));
      for (let j = i; j < e; j++) {
        state.env += (r > state.env ? atk : rel) * (r - state.env);
        const speak = cl(state.env / .08, 0, 1), v = narr[j] + at(j) * K * (1 - .62 * speak);
        narr[j] = v > 1 ? 1 : v < -1 ? -1 : v;
      }
    }
  }
  return narr;
}

/* ------------------------------------------------------------------ preview ---- */
/** The preview: call tick(T, playing, S) every frame. Notes are scheduled 1.5 s ahead; a seek, pause or new film starts cleanly. */
export function livePlayer(ctx, dest) {
  let plan = null, key = '', m = null, ei = 0, origin = 0, at = -1, on = false, lvl = 1;
  const stop = () => { if (m) { const g = m.out.gain; try { g.cancelScheduledValues(ctx.currentTime); g.setValueAtTime(g.value, ctx.currentTime); g.linearRampToValueAtTime(0, ctx.currentTime + .15); } catch (e) { /* */ } const old = m; setTimeout(() => { try { old.out.disconnect(); } catch (e) { /* */ } }, 400); m = null; } on = false; };
  return {
    stop,
    setLevel(v) { lvl = v; if (m) m.out.gain.value = v; },
    tick(T, playing, S, k) {
      if (!playing || !lvl) { if (on) stop(); at = -1; return; }
      if (!plan || k !== key) { plan = musicPlan(S); key = k; if (on) stop(); }
      const now = ctx.currentTime, expect = origin + (now - at);
      if (!on || at < 0 || Math.abs(expect - T) > .3) {
        stop(); m = master(ctx, dest || ctx.destination, lvl); on = true; origin = T; at = now; ei = 0;
        // notes already sounding at T join in, so a pad does not wait for the next bar
        for (const e of plan.events) { if (e.t > T) break; if (e.t + e.dur > T && (e.inst === 'pad' || e.inst === 'bass')) playNote(ctx, m.inp, e, now + .02, T - e.t); }
        while (ei < plan.events.length && plan.events[ei].t <= T) ei++;
      }
      const ahead = origin + (now - at) + 1.5;
      while (ei < plan.events.length && plan.events[ei].t < ahead) { const e = plan.events[ei++]; playNote(ctx, m.inp, e, at + (e.t - origin)); }
    },
  };
}
