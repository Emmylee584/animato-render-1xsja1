// Scene library, part 1: INDOOR places (homes, shops, work, public buildings, vehicles, studios).
// Each place is { id, cat, aka, out, floor, make(k) } and draws itself as stacked layers with the kit from scene-library.js.
import { shade, mix } from './scene-library.js';

const W = 1600;

// ---- furniture and fittings: feet on y, already graded for indoor light ---------------------------------
export const F = {
  sofa(k, x, y, w = 360, c = '#6a5a8a') {
    c = k.gi(k.v(c)); k.shadow(x + w / 2, y + 8, w * .62, 13, .42);
    k.obj(x, y - 124, w, 100, shade(c, .88), { r: 16 }); k.obj(x + 22, y - 74, w - 44, 54, c, { r: 10 });
    k.obj(x - 16, y - 100, 52, 84, shade(c, .94), { r: 16 }); k.obj(x + w - 36, y - 100, 52, 84, shade(c, .94), { r: 16 });
    k.line(x + w / 2, y - 74, x + w / 2, y - 22, shade(c, .55), 3, .6); k.rect(x + 22, y - 22, 14, 22, '#2a2018'); k.rect(x + w - 36, y - 22, 14, 22, '#2a2018');
  },
  armchair(k, x, y, c = '#8a5a3a') { F.sofa(k, x, y, 170, c); },
  plant(k, x, y, s = 1, c) { k.plant(x, y, s, c); },
  bed(k, x, y, w = 460, c = '#6f8fb8') {
    c = k.gi(k.v(c)); k.shadow(x + w / 2, y + 8, w * .6, 14, .42);
    k.obj(x - 10, y - 190, 40, 190, k.gi('#6a4a30'), { r: 6 }); k.obj(x, y - 96, w, 70, k.gi('#e9e4da'), { r: 10 });
    k.obj(x + 8, y - 130, 120, 44, k.gi('#f4f0e8'), { r: 16 }); k.obj(x + 150, y - 84, w - 150, 66, c, { r: 8 });
    k.line(x + 180, y - 80, x + 180, y - 22, shade(c, .6), 3, .5); k.rect(x + w - 24, y - 40, 14, 40, '#2a1a10');
  },
  table(k, x, y, w = 400, c = '#8a5a3a', h = 130) {
    c = k.gi(k.v(c)); k.shadow(x + w / 2, y + 6, w * .58, 10, .35);
    k.obj(x - 10, y - h, w + 20, 22, shade(c, 1.1), { r: 5 }); k.rect(x + 20, y - h + 22, 14, h - 22, shade(c, .7)); k.rect(x + w - 34, y - h + 22, 14, h - 22, shade(c, .7));
  },
  chair(k, x, y, c = '#8a5a3a', flip = false) {
    c = k.gi(k.v(c)); k.shadow(x + 28, y + 5, 40, 6, .3); k.obj(x, y - 66, 56, 12, shade(c, 1.05), { r: 3 });
    k.rect(flip ? x + 44 : x, y - 140, 12, 76, shade(c, .85)); k.rect(x + 4, y - 56, 8, 56, shade(c, .7)); k.rect(x + 44, y - 56, 8, 56, shade(c, .7));
  },
  desk(k, x, y, w = 420, c = '#7a5a3a') {
    c = k.gi(k.v(c)); k.shadow(x + w / 2, y + 6, w * .6, 11, .38);
    k.obj(x, y - 130, w, 20, shade(c, 1.12), { r: 4 }); k.obj(x + 10, y - 110, 70, 110, shade(c, .85), { r: 3 }); k.obj(x + w - 80, y - 110, 70, 110, shade(c, .85), { r: 3 });
    for (let i = 0; i < 3; i++) k.rect(x + 18, y - 98 + i * 34, 54, 3, '#000', 'opacity=".25"');
  },
  monitor(k, x, y, w = 150, on = true) {
    const sc = on ? k.g('#7fd0ff') : '#10131c';
    k.obj(x + w / 2 - 6, y, 12, 34, '#2a2f3a', { hl: false }); k.obj(x + w / 2 - 40, y + 30, 80, 8, '#2a2f3a', { hl: false });
    k.obj(x, y - w * .6, w, w * .6, '#1a1e28', { r: 5 }); k.rect(x + 6, y - w * .6 + 6, w - 12, w * .6 - 12, sc, 'opacity=".9"');
    if (on) { k.glow(x + w / 2, y - w * .3, w * 1.1, '#7fd0ff', .25); for (let i = 0; i < 4; i++) k.rect(x + 14, y - w * .6 + 16 + i * 14, w * (.3 + (i % 3) * .15), 4, '#fff', 'opacity=".5"'); }
  },
  shelf(k, x, y, w = 300, h = 330, rows = 3, cols) {
    const c = k.gi('#6a4a30'); k.shadow(x + w / 2, y + 5, w * .6, 9, .35);
    k.obj(x, y - h, w, h, shade(c, .8), { r: 3 });
    const B = cols || ['#8a3b2e', '#2f5d7a', '#d9a441', '#4a7a4a', '#6b4a7a', '#d9d2c0', '#2a3b5a'];
    for (let r = 0; r < rows; r++) {
      const ry = y - h + 12 + r * ((h - 24) / rows), rh = (h - 24) / rows;
      k.rect(x + 8, ry, w - 16, rh - 6, '#000', 'opacity=".28"');
      let bx = x + 12, i = 0;
      while (bx < x + w - 20) { const bw = 12 + k.r() * 18, bh = rh * (.55 + k.r() * .35); k.rect(bx, ry + rh - 6 - bh, bw, bh, k.gi(B[(i++ + r) % B.length]), 'stroke="#000" stroke-opacity=".3" stroke-width="1.5"'); bx += bw + 2; }
      k.rect(x + 4, ry + rh - 6, w - 8, 6, shade(c, 1.1));
    }
  },
  fridge(k, x, y, c = '#cfd6dd') { c = k.gi(c); k.shadow(x + 55, y + 5, 80, 8, .35); k.obj(x, y - 320, 110, 320, c, { r: 8 }); k.rect(x + 4, y - 200, 102, 4, '#000', 'opacity=".4"'); k.rect(x + 86, y - 290, 6, 60, shade(c, .6)); k.rect(x + 86, y - 180, 6, 80, shade(c, .6)); },
  counter(k, x, y, w = 600, c = '#e8e2d6', top = '#6a6a72', upper = true) {
    c = k.gi(k.v(c, .3)); k.shadow(x + w / 2, y + 5, w * .55, 9, .35);
    k.obj(x, y - 130, w, 130, c, { r: 3 }); k.obj(x - 6, y - 144, w + 12, 16, k.gi(top), { r: 3 });
    for (let i = 0; i < Math.floor(w / 100); i++) { k.rect(x + 8 + i * 100, y - 118, 88, 104, '#000', 'opacity=".1"'); k.circle(x + 80 + i * 100, y - 66, 4, '#8a8f96'); }
    if (upper) { k.obj(x, y - 470, w, 130, c, { r: 3 }); for (let i = 0; i < Math.floor(w / 100); i++) k.line(x + 100 + i * 100, y - 470, x + 100 + i * 100, y - 340, '#000', 3, .25); }
  },
  stove(k, x, y, w = 150) { const c = k.gi('#bfc5cc'); k.obj(x, y - 130, w, 130, c, { r: 3 }); k.rect(x + 14, y - 104, w - 28, 70, '#14161c'); for (let i = 0; i < 4; i++) k.circle(x + 24 + i * ((w - 48) / 3), y - 120, 7, '#444'); },
  sink(k, x, y) { k.obj(x, y - 140, 120, 14, k.gi('#9aa0a8'), {}); k.path(`M${x + 50},${y - 140} v-50 q0,-20 24,-14`, 'none', `stroke="${k.gi('#9aa0a8')}" stroke-width="8" stroke-linecap="round"`); },
  tv(k, x, y, w = 360, on = true) {
    k.obj(x, y - w * .56, w, w * .56, '#101216', { r: 5 }); k.rect(x + 8, y - w * .56 + 8, w - 16, w * .56 - 16, on ? k.g('#5aa0d8') : '#0c0e12', 'opacity=".95"');
    if (on) { k.glow(x + w / 2, y - w * .28, w * .9, '#7fd0ff', .3); k.rect(x + 20, y - w * .56 + 24, w * .5, 10, '#fff', 'opacity=".5"'); }
    k.rect(x + w / 2 - 6, y, 12, 20, '#222');
  },
  lockers(k, x, y, n = 8, c = '#3f6a8a') { c = k.gi(k.v(c)); k.shadow(x + n * 44, y + 5, n * 48, 7, .35); for (let i = 0; i < n; i++) { k.obj(x + i * 88, y - 300, 86, 300, c, { r: 2 }); for (let j = 0; j < 4; j++) k.rect(x + i * 88 + 20, y - 270 + j * 20, 46, 3, '#000', 'opacity=".35"'); k.rect(x + i * 88 + 60, y - 150, 6, 30, shade(c, .5)); } },
  board(k, x, y, w, h, c = '#25483a', chalk = true) { k.obj(x - 10, y - 10, w + 20, h + 20, k.gi('#8a6a40'), { r: 3 }); k.vg(x, y, w, h, shade(k.gi(c), 1.1), shade(k.gi(c), .85)); if (chalk) { let q = ''; for (let i = 0; i < 5; i++) q += `<path d="M${x + 30},${y + 40 + i * 40} q${w * .2},${-14} ${w * (.3 + (i % 3) * .1)},0" stroke="#fff" stroke-width="3" fill="none" opacity=".6" stroke-linecap="round"/>`; k.add(q); } },
  whiteboard(k, x, y, w, h) { k.obj(x - 8, y - 8, w + 16, h + 16, k.gi('#9aa0a8'), { r: 3 }); k.vg(x, y, w, h, k.gi('#fbfbfd'), k.gi('#e3e6ec')); let q = ''; const cs = ['#2a62c9', '#c0392b', '#2a8a4a']; for (let i = 0; i < 4; i++) q += `<path d="M${x + 24},${y + 36 + i * 36} q${w * .15},-12 ${w * (.25 + (i % 3) * .12)},0" stroke="${cs[i % 3]}" stroke-width="3" fill="none" opacity=".7" stroke-linecap="round"/>`; k.add(q); },
  schoolDesk(k, x, y, s = 1) { const c = k.gi('#b98a5e'); k.shadow(x + 50 * s, y + 4, 70 * s, 7, .3); k.obj(x, y - 80 * s, 110 * s, 12 * s, c, { r: 3 }); k.rect(x + 10 * s, y - 68 * s, 6, 68 * s, '#555'); k.rect(x + 94 * s, y - 68 * s, 6, 68 * s, '#555'); },
  curtain(k, x, y, w, h, c = '#8a3b4e') { c = k.gi(k.v(c)); for (let s = 0; s < 2; s++) { const cx = s ? x + w - w * .22 : x; k.vg(cx, y, w * .22, h, shade(c, 1.1), shade(c, .8)); for (let i = 1; i < 4; i++) k.line(cx + i * w * .055, y, cx + i * w * .055, y + h, '#000', 2, .2); } k.rect(x - 10, y - 8, w + 20, 10, k.gi('#5a4a3a')); },
  painting(k, x, y, w, h, c1 = '#9ed0e8', c2 = '#e8b04a') { k.obj(x, y, w, h, k.gi('#4a3a2a'), { r: 2 }); k.vg(x + 8, y + 8, w - 16, h - 16, k.gi(k.v(c1)), k.gi(k.v(c2))); k.poly([[x + 8, y + h - 8], [x + w * .35, y + h * .5], [x + w * .6, y + h - 8]], k.gi('#2a4a5a'), 'opacity=".7"'); },
  clock(k, x, y, r = 36) { k.circle(x, y, r, k.gi('#f4efe3'), 'stroke="#222" stroke-width="5"'); k.line(x, y, x, y - r * .6, '#222', 4); k.line(x, y, x + r * .45, y + r * .1, '#222', 4); },
  rug(k, x, y, w, c = '#8a3b4e') { c = k.gi(k.v(c)); k.add(`<ellipse cx="${x + w / 2}" cy="${y}" rx="${w / 2}" ry="${w * .09}" fill="${shade(c, .85)}" stroke="${shade(c, .6)}" stroke-width="4"/><ellipse cx="${x + w / 2}" cy="${y}" rx="${w * .36}" ry="${w * .06}" fill="none" stroke="${shade(c, 1.3)}" stroke-width="3" opacity=".7"/>`); },
  pendant(k, x, h = 220, c = '#e8c868') { k.line(x, 0, x, h, '#1a1a1a', 3); k.add(`<path d="M${x - 46},${h + 34} q46,-60 92,0 z" fill="${k.gi(c)}" stroke="#222" stroke-width="3"/>`); k.lampIn(x, h + 40, 240); k.shaft(x, h + 36, 70, 480, '#fff0c0', .12 + .14 * k.lampK, 4); },
  tubes(k, y, n = 5, x0 = 160, x1 = 1440) { for (let i = 0; i < n; i++) { const x = x0 + i * ((x1 - x0) / Math.max(1, n - 1)); k.rect(x - 70, y, 140, 12, '#f4f7ff', 'rx="5" stroke="#555" stroke-width="2"'); k.glow(x, y + 30, 210, '#eaf3ff', .26); k.shaft(x, y + 12, 130, 440, '#eaf3ff', .09, 2); } },
  stool(k, x, y, c = '#a33') { c = k.gi(c); k.shadow(x, y + 3, 28, 5, .3); k.rect(x - 4, y - 90, 8, 90, '#333'); k.add(`<ellipse cx="${x}" cy="${y - 92}" rx="30" ry="9" fill="${c}" stroke="#111" stroke-opacity=".5" stroke-width="3"/>`); },
  bench(k, x, y, w = 280, c = '#8a5a3a') { c = k.gi(c); k.shadow(x + w / 2, y + 5, w * .55, 8, .32); k.obj(x, y - 60, w, 14, c, { r: 3 }); k.obj(x, y - 120, w, 12, shade(c, .9), { r: 3 }); k.rect(x + 14, y - 46, 10, 46, shade(c, .6)); k.rect(x + w - 24, y - 46, 10, 46, shade(c, .6)); k.rect(x + 14, y - 112, 8, 52, shade(c, .6)); k.rect(x + w - 22, y - 112, 8, 52, shade(c, .6)); },
  rack(k, x, y, w = 150, h = 380, c = '#2a3040') { c = k.gi(c); k.shadow(x + w / 2, y + 5, w * .6, 8, .35); k.obj(x, y - h, w, h, c, { r: 3 }); for (let i = 0; i < Math.floor(h / 34); i++) { k.rect(x + 10, y - h + 12 + i * 34, w - 20, 22, '#0c0f16'); k.circle(x + 22, y - h + 23 + i * 34, 3.2, (i + Math.floor(x)) % 3 ? k.g('#3cff7a') : k.g('#ff6a3a')); k.circle(x + 36, y - h + 23 + i * 34, 3.2, k.g('#3aa0ff')); } },
  goods(k, x, y, w, h, rows = 4) { const c = k.gi('#9aa0a8'); k.obj(x, y - h, w, h, shade(c, .7), { r: 2 }); const P = ['#e8453a', '#f2c230', '#3aa05a', '#3a7ad8', '#e0e0e0', '#b04ad8']; for (let r = 0; r < rows; r++) { const ry = y - h + 10 + r * ((h - 20) / rows); k.rect(x + 4, ry + (h - 20) / rows - 8, w - 8, 6, c); let px = x + 10, i = 0; while (px < x + w - 24) { const pw = 16 + k.r() * 14, ph = (h - 20) / rows * (.5 + k.r() * .35); k.rect(px, ry + (h - 20) / rows - 8 - ph, pw, ph, k.gi(P[(i++ + r) % P.length]), 'stroke="#000" stroke-opacity=".25" stroke-width="1.5"'); px += pw + 3; } } },
  pew(k, x, y, w = 360, c = '#6a4a30') { c = k.gi(c); k.shadow(x + w / 2, y + 4, w * .55, 7, .3); k.obj(x, y - 52, w, 12, c, { r: 3 }); k.obj(x, y - 110, w, 52, shade(c, .85), { r: 3 }); k.rect(x + 10, y - 40, 10, 40, shade(c, .6)); k.rect(x + w - 20, y - 40, 10, 40, shade(c, .6)); },
  cot(k, x, y, w = 300, c = '#dfe6ee') { c = k.gi(c); k.shadow(x + w / 2, y + 5, w * .55, 8, .35); k.obj(x, y - 100, w, 28, c, { r: 8 }); k.obj(x, y - 130, 70, 40, shade(c, 1.05), { r: 10 }); k.rect(x + 14, y - 72, 8, 72, '#777'); k.rect(x + w - 22, y - 72, 8, 72, '#777'); },
  bars(k, x, y, w, h) { k.rect(x, y, w, h, '#000', 'opacity=".25"'); for (let i = 0; i <= w / 36; i++) k.rect(x + i * 36, y - 4, 8, h + 8, k.gi('#3a3f48')); k.rect(x - 6, y - 8, w + 12, 12, k.gi('#2a2f38')); k.rect(x - 6, y + h - 4, w + 12, 12, k.gi('#2a2f38')); },
  door2(k, x, y, w, h, c) { k.door(x, y - h, w, h, c); },
};

// ---- archetype: a room with a back wall, a floor, windows, a mid layer and props ---------------------------------
export function room(k, c) {
  k.out = false;
  const y = c.y ?? 740;
  k.layer('back wall', () => { k.wall(0, y, k.v(c.wall, c.hue ?? .35), { kind: c.wk }); if (c.wains) k.wainscot(y - c.wains, y, k.v(c.wc || c.wall, .35)); k.baseboard(y, c.base || '#e8e2d6'); if (c.ceil) { k.vg(0, 0, W, c.ceil, shade(k.gi(c.cc || '#e8e4dc'), .9), shade(k.gi(c.cc || '#e8e4dc'), 1.05)); k.rect(0, c.ceil, W, 5, '#000', 'opacity=".25"'); } });
  k.layer('windows', () => (c.wins || []).forEach((w) => k.window(w[0], w[1], w[2], w[3], { frame: c.frame, cols: w[4] || 2, rows: w[5] || 2, view: c.view })));
  k.layer('floor', () => k.floor(y, k.v(c.floor, .3), { indoor: true, kind: c.fk || 'wood', persp: c.persp !== false, sheen: .13 }));
  k.layer('mid', () => c.mid && c.mid(k, y));
  k.layer('props', () => c.props && c.props(k, y));
  k.layer('light', () => { c.light && c.light(k, y); if (c.lamps !== false && !c.light) k.lampIn(800, 120, 700, '#ffe9bd', .12 + .16 * k.lampK); });
  k.finish();
}

const P = (id, cat, aka, floor, make, extra = {}) => ({ id, cat, aka, out: false, floor, make, ...extra });

export const INDOOR = [
  // ---------------- home ----------------
  P('livingRoom', 'home', ['lounge', 'sitting room', 'family room', 'den'], 740, (k) => room(k, {
    wall: '#cdb89a', wk: 'plaster', floor: '#8a5a3a', wains: 0, wins: [[1060, 130, 340, 300]], view: 'nature',
    mid: (k, y) => { F.painting(k, 300, 180, 240, 160); F.shelf(k, 70, y, 220, 400, 4); F.clock(k, 700, 200, 34); },
    props: (k, y) => { F.rug(k, 360, y + 60, 760); F.sofa(k, 360, y - 6, 420, '#5a6a8a'); F.armchair(k, 940, y - 6, '#8a5a3a'); F.table(k, 560, y + 76, 200, '#6a4a30', 60); F.tv(k, 1200, y - 90, 220, true); F.plant(k, 1500, y, 1.2); },
    light: (k, y) => { k.lampIn(1230, 260, 420, '#fff0c8', .2); k.lampIn(260, 420, 260, '#ffd88a', .12 + .3 * k.lampK); k.shaft(1230, 130, 300, 640, '#fff4cc', .16); },
  })),
  P('bedroom', 'home', ['sleeping room', 'master bedroom'], 750, (k) => room(k, {
    wall: '#9fb0cf', wk: 'plaster', floor: '#7a5a42', wins: [[1100, 150, 300, 280, 2, 2]], view: 'nature',
    mid: (k, y) => { F.curtain(k, 1070, 130, 360, 320, '#6a4a7a'); F.painting(k, 360, 190, 220, 150, '#8ab0d8', '#d98a6a'); },
    props: (k, y) => { F.rug(k, 260, y + 70, 620, '#7a5a8a'); F.bed(k, 260, y - 8, 520, '#6a8ab8'); F.table(k, 120, y, 110, '#6a4a30', 120); F.table(k, 820, y, 110, '#6a4a30', 120); F.plant(k, 1440, y, 1.3); },
    light: (k) => { k.lampIn(170, 560, 200, '#ffd08a', .18 + .35 * k.lampK); k.lampIn(870, 560, 200, '#ffd08a', .18 + .35 * k.lampK); },
  })),
  P('kitchen', 'home', ['kitchenette'], 750, (k) => room(k, {
    wall: '#e8d9b8', wk: 'tile', wains: 0, floor: '#a89888', fk: 'tile', wins: [[1060, 150, 260, 220, 2, 2]], view: 'nature',
    mid: (k, y) => { F.counter(k, 120, y, 760, '#8a5a3a', '#cfcfd6', true); F.stove(k, 440, y, 150); },
    props: (k, y) => { F.fridge(k, 960, y, '#cfd6dd'); F.sink(k, 220, y - 144); F.table(k, 1130, y + 60, 300, '#8a6a46', 120); F.chair(k, 1090, y + 60, '#8a6a46'); F.chair(k, 1400, y + 60, '#8a6a46', true); },
    light: (k) => { F.pendant(k, 1280, 280); k.lampIn(400, 160, 520, '#fff0c8', .14 + .18 * k.lampK); },
  })),
  P('bathroom', 'home', ['restroom', 'washroom', 'toilet'], 740, (k) => room(k, {
    wall: '#bcd6dc', wk: 'tile', t: 60, floor: '#d4d8dc', fk: 'tile',
    mid: (k, y) => { k.obj(520, 170, 280, 240, k.gi('#b8c8d0'), { r: 8 }); k.vg(534, 184, 252, 212, k.gi('#d9eef8'), k.gi('#9fc2d4')); k.line(560, 380, 740, 200, '#fff', 4, .35); k.obj(460, y - 170, 400, 26, k.gi('#f2f2f4'), { r: 6 }); k.obj(560, y - 144, 200, 144, k.gi('#f2f2f4'), { r: 6 }); },
    props: (k, y) => { k.obj(1000, y - 150, 560, 160, k.gi('#f4f6f8'), { r: 40 }); k.rect(1020, y - 160, 520, 18, '#cfd8de'); k.rect(1500, y - 380, 10, 230, '#9aa4ac'); k.shadow(1280, y + 8, 340, 12, .35); k.obj(110, y - 80, 130, 80, k.gi('#f4f6f8'), { r: 24 }); k.obj(150, y - 150, 60, 80, k.gi('#e8ecf0'), { r: 8 }); },
  })),
  P('kidsRoom', 'home', ['nursery', 'childs bedroom', 'playroom'], 750, (k) => room(k, {
    wall: '#f2cfa6', wk: 'plaster', floor: '#c49a6a', wins: [[140, 150, 280, 250, 2, 2]],
    mid: (k, y) => { for (let i = 0; i < 6; i++) k.circle(560 + i * 130, 200 + (i % 2) * 60, 24, k.gi(k.v(['#e8453a', '#f2c230', '#3aa05a', '#3a7ad8', '#b04ad8'][i % 5], .3))); },
    props: (k, y) => { F.rug(k, 520, y + 80, 700, '#3a8ad8'); F.bed(k, 1060, y, 460, '#e8453a'); for (let i = 0; i < 5; i++) k.box(560 + i * 70, y + 40 + (i % 2) * 20, 52, 52, ['#e8453a', '#f2c230', '#3aa05a', '#3a7ad8', '#b04ad8'][i]); F.shelf(k, 60, y, 260, 300, 3); },
  })),
  P('attic', 'home', ['loft', 'garret'], 760, (k) => room(k, {
    wall: '#6a5238', wk: 'planks', floor: '#5a4630', wins: [[700, 190, 200, 200, 2, 2]], persp: true,
    mid: (k, y) => { k.poly([[0, 0], [W, 0], [W - 220, 150], [220, 150]], k.gi('#3a2a1c'), 'opacity=".5"'); for (let i = 0; i < 7; i++) k.rect(150 + i * 215, 0, 22, 180, k.gi('#3a2a1c')); },
    props: (k, y) => { for (let i = 0; i < 6; i++) k.box(110 + i * 90 + (i % 2) * 20, y - 70 - (i % 3) * 52, 88, 68 + (i % 3) * 20, '#a8845a'); k.add(`<rect x="1050" y="${y - 200}" width="260" height="200" fill="${k.gi('#8a3b4e')}" opacity=".9" rx="10"/>`); k.sheen(y, '#ffe9bd', .1); },
  })),
  P('basement', 'home', ['cellar', 'storage room'], 760, (k) => room(k, {
    wall: '#6a6e74', wk: 'stone', floor: '#4a4a50', fk: 'concrete', frame: '#333',
    mid: (k, y) => { k.rect(0, 120, W, 22, k.gi('#4a4a50')); for (let i = 0; i < 5; i++) k.rect(120 + i * 320, 140, 18, 40, k.gi('#4a4a50')); F.shelf(k, 120, y, 300, 360, 3); F.shelf(k, 1160, y, 300, 360, 3); },
    props: (k, y) => { for (let i = 0; i < 4; i++) k.box(620 + i * 80, y - 50 - (i % 2) * 60, 74, 74, '#a8845a'); k.rect(820, y - 220, 120, 14, '#333'); },
    light: (k) => { k.lampIn(800, 150, 600, '#ffe2a0', .2 + .2 * k.lampK); F.pendant(k, 800, 90); },
  })),
  P('hallway', 'home', ['corridor', 'entryway', 'foyer', 'entrance hall'], 750, (k) => room(k, {
    wall: '#cbbfa6', wk: 'plaster', wains: 220, wc: '#e8e2d6', floor: '#6a4a38',
    mid: (k, y) => { for (let i = 0; i < 3; i++) F.painting(k, 180 + i * 300, 170, 190, 130, ['#9ed0e8', '#e8b04a', '#8ab08a'][i], ['#e8b04a', '#d98a6a', '#4a7a9a'][i]); F.door2(k, 1100, y, 160, 360, '#6a4a30'); },
    props: (k, y) => { F.table(k, 100, y, 340, '#6a4a30', 110); F.plant(k, 180, y - 110, .7); k.rect(480, y - 6, 560, 14, '#8a3b4e', 'opacity=".7"'); F.clock(k, 1370, 220, 34); },
    light: (k) => { F.pendant(k, 600, 160); F.pendant(k, 1000, 160); },
  })),
  P('staircase', 'home', ['stairs', 'stairwell'], 760, (k) => room(k, {
    wall: '#d4c8b0', wk: 'plaster', floor: '#7a5a42',
    mid: (k, y) => { for (let i = 0; i < 9; i++) { k.obj(520 + i * 80, y - 40 - i * 52, 600 - i * 80, 52, k.gi('#8a6a4a'), { r: 2 }); } k.add(`<path d="M520,${y - 130} L1120,${y - 560}" stroke="${k.gi('#5a3b24')}" stroke-width="10"/>`); for (let i = 0; i < 9; i++) k.rect(540 + i * 66, y - 124 - i * 48, 6, 90, k.gi('#5a3b24')); },
    props: (k, y) => { F.painting(k, 160, 200, 230, 170); F.plant(k, 330, y, 1.1); },
  })),
  P('homeOffice', 'home', ['study', 'work from home', 'den office'], 750, (k) => room(k, {
    wall: '#4a5a6a', wk: 'plaster', floor: '#6a4a38', wins: [[1100, 150, 300, 260, 2, 2]],
    mid: (k, y) => { F.shelf(k, 90, y, 380, 460, 4); F.painting(k, 560, 200, 260, 170, '#8ab0d8', '#e8c868'); },
    props: (k, y) => { F.desk(k, 520, y, 520, '#6a4a30'); F.monitor(k, 640, y - 130, 170); F.monitor(k, 830, y - 130, 130, true); F.chair(k, 700, y + 30, '#222'); F.plant(k, 1460, y, 1.2); },
    light: (k) => { k.lampIn(520, 440, 220, '#ffd88a', .12 + .3 * k.lampK); },
  })),
  P('diningRoom', 'home', ['dining'], 750, (k) => room(k, {
    wall: '#8a3b4e', wk: 'plaster', wains: 240, wc: '#e8e2d6', floor: '#6a4a38', wins: [[1120, 140, 280, 280, 2, 2]],
    mid: (k, y) => { F.painting(k, 320, 160, 300, 200, '#8ab0d8', '#e8c868'); F.curtain(k, 1090, 120, 340, 340, '#c9a24a'); },
    props: (k, y) => { F.table(k, 380, y + 50, 640, '#7a5a3a', 140); for (let i = 0; i < 4; i++) F.chair(k, 420 + i * 150, y + 50, '#5a3b24', i > 1); F.shelf(k, 100, y, 200, 340, 3); },
    light: (k) => { F.pendant(k, 700, 220, '#e8c868'); },
  })),
  P('balcony', 'home', ['terrace', 'veranda'], 770, (k) => { k.out = true; k.layer('sky', () => k.sky()); k.layer('far', () => k.skyline(640, [80, 260], '#7a8aa8', { seed: 2, litChance: .3 })); k.layer('mid', () => k.skyline(700, [120, 340], '#556080', { seed: 6, minW: 110, maxW: 200 })); k.layer('floor', () => k.floor(770, '#7a6a5a', { kind: 'wood', persp: true })); k.layer('props', () => { k.rect(0, 580, W, 14, k.g('#3a3a44')); for (let i = 0; i < 40; i++) k.rect(i * 42, 594, 6, 176, k.g('#3a3a44')); F.table(k, 1000, 770, 180, '#6a5a4a', 100); F.chair(k, 960, 770, '#6a5a4a'); F.plant(k, 200, 770, 1.4); }); k.layer('light', () => { k.lamp(1090, 600, 220, '#ffd88a', .5); }); k.finish(); }),
  P('backyard', 'home', ['yard', 'garden shed'], 740, (k) => { k.out = true; k.layer('sky', () => k.sky()); k.layer('far', () => { k.hills(560, 90, '#5a8a6a'); k.trees(610, 8, 'round', '#3f8a4a', { size: .9 }); }); k.layer('fence', () => { k.rect(0, 560, W, 190, k.g('#b0804e')); k.tex('planks', 0, 560, W, 190, { c: k.g('#3a2410'), op: .45, t: 60 }); for (let i = 0; i < 34; i++) k.poly([[i * 48, 560], [i * 48 + 22, 536], [i * 48 + 46, 560]], k.g('#b0804e')); }); k.layer('floor', () => k.floor(740, '#4f9a4a', { kind: 'grass' })); k.layer('props', () => { k.obj(1160, 440, 300, 300, k.g('#c9a24a'), { r: 3 }); k.poly([[1140, 440], [1310, 340], [1480, 440]], k.g('#7a3b2e')); k.rect(1260, 590, 90, 150, k.g('#5a3b24')); k.trees(760, 1, 'round', '#3f8a4a', { size: 1.4 }); F.bench(k, 360, 770, 300); k.rect(120, 640, 8, 100, '#777'); }); k.finish(); }),
  P('porch', 'home', ['front porch', 'doorstep'], 750, (k) => { k.out = true; k.layer('sky', () => k.sky()); k.layer('far', () => k.trees(640, 9, 'round', '#3f8a4a', { size: 1 })); k.layer('house', () => { k.wall(120, 750, '#d9c9a8', { kind: 'planks', outdoor: true }); k.rect(0, 100, W, 40, k.g('#6a3b2e')); F.door2(k, 700, 750, 200, 400, '#8a3b4e'); k.window(260, 260, 220, 240, { frame: '#fff', spill: false }); k.window(1120, 260, 220, 240, { frame: '#fff', spill: false }); for (let i = 0; i < 6; i++) k.rect(80 + i * 260, 130, 26, 620, k.g('#f4efe3')); }); k.layer('floor', () => k.floor(750, '#8a6a4a', { kind: 'wood', persp: true })); k.layer('props', () => { F.plant(k, 200, 750, 1.3); F.plant(k, 1400, 750, 1.3); F.bench(k, 1000, 750, 240); k.rect(700, 760, 200, 26, k.g('#6a5a4a')); }); k.layer('light', () => { k.lamp(620, 240, 180, '#ffd88a', .6); k.lamp(980, 240, 180, '#ffd88a', .6); }); k.finish(); }),

  // ---------------- food and shops ----------------
  P('cafe', 'shop', ['coffee shop', 'coffeehouse', 'cafeteria bar'], 750, (k) => room(k, {
    wall: '#7a5a42', wk: 'brick', floor: '#4a3a30', wains: 180, wc: '#3a2a20', wins: [[110, 170, 360, 340, 3, 2]],
    mid: (k, y) => { F.board(k, 700, 150, 360, 220, '#222a30'); k.sign(1120, 150, 360, 80, 'COFFEE', '#2a1a10', '#f2c230', 44); F.counter(k, 700, y, 720, '#5a3b24', '#cfcfd6', false); k.obj(780, y - 200, 120, 56, k.gi('#bfc5cc')); k.obj(940, y - 200, 90, 56, k.gi('#bfc5cc')); },
    props: (k, y) => { for (let i = 0; i < 3; i++) F.stool(k, 760 + i * 220, y + 40, '#a33'); F.table(k, 130, y + 60, 150, '#8a5a3a', 110); F.chair(k, 90, y + 60, '#5a3b24'); F.chair(k, 290, y + 60, '#5a3b24', true); F.plant(k, 520, y, 1.1); },
    light: (k) => { F.pendant(k, 300, 240); F.pendant(k, 900, 150); F.pendant(k, 1240, 240); },
  })),
  P('diner', 'shop', ['american diner', 'burger joint', 'greasy spoon'], 750, (k) => room(k, {
    wall: '#e8d6b8', wk: 'tile', t: 48, floor: '#cfcfd6', fk: 'tile', wains: 200, wc: '#c0392b', wins: [[100, 170, 520, 280, 4, 2]],
    mid: (k, y) => { k.neon(760, 150, 520, 90, 'DINER', '#ff4a6a', 52); k.rect(700, y - 240, 800, 14, k.gi('#9aa0a8')); },
    props: (k, y) => { F.counter(k, 700, y, 820, '#c0392b', '#e8e8ee', false); for (let i = 0; i < 5; i++) F.stool(k, 760 + i * 150, y + 50, '#c0392b'); for (let i = 0; i < 2; i++) { F.table(k, 120 + i * 260, y + 40, 190, '#e8e8ee', 120); k.obj(60 + i * 260, y - 120, 40, 120, k.gi('#c0392b'), {}); } },
    light: (k) => { F.tubes(k, 30, 4, 300, 1300); },
  })),
  P('restaurant', 'shop', ['fine dining', 'bistro'], 750, (k) => room(k, {
    wall: '#5a2a30', wk: 'plaster', wains: 200, wc: '#2a1a16', floor: '#3a2a22', wins: [[1100, 150, 320, 300, 2, 2]],
    mid: (k, y) => { F.painting(k, 300, 160, 260, 180, '#c98a6a', '#4a3a2a'); F.painting(k, 640, 160, 260, 180, '#8ab0d8', '#d9a441'); },
    props: (k, y) => { for (let i = 0; i < 3; i++) { F.table(k, 120 + i * 440, y + 70, 220, '#f4efe3', 110); F.chair(k, 90 + i * 440, y + 70, '#5a2a30'); F.chair(k, 340 + i * 440, y + 70, '#5a2a30', true); k.rect(200 + i * 440, y - 56, 6, 28, '#fff'); k.lampIn(203 + i * 440, y - 62, 50, '#ffd88a', .5 * k.lampK + .1); } },
    light: (k) => { F.pendant(k, 340, 240); F.pendant(k, 780, 240); F.pendant(k, 1220, 240); },
  })),
  P('restaurantKitchen', 'shop', ['commercial kitchen', 'chef kitchen', 'kitchen restaurant'], 760, (k) => room(k, {
    wall: '#c9ced4', wk: 'tile', floor: '#8a8f96', fk: 'tile',
    mid: (k, y) => { k.rect(100, 160, 1400, 14, '#9aa0a8'); for (let i = 0; i < 8; i++) { k.line(150 + i * 170, 174, 150 + i * 170, 240, '#777', 3); k.circle(150 + i * 170, 262, 22, k.gi('#8a8f96')); } F.counter(k, 80, y, 560, '#9aa0a8', '#cfcfd6', false); F.counter(k, 960, y, 560, '#9aa0a8', '#cfcfd6', false); F.stove(k, 700, y, 200); },
    props: (k, y) => { k.obj(680, y - 360, 240, 130, k.gi('#8a8f96'), { r: 6 }); F.fridge(k, 1480, y, '#cfd6dd'); },
    light: (k) => { F.tubes(k, 30, 4, 300, 1300); },
  })),
  P('bar', 'shop', ['pub', 'tavern bar', 'lounge bar'], 750, (k) => room(k, {
    wall: '#3a2a20', wk: 'brick', floor: '#2a2018', wains: 0,
    mid: (k, y) => { k.rect(300, 200, 1000, 20, k.gi('#5a3b24')); k.rect(300, 330, 1000, 20, k.gi('#5a3b24')); const C = ['#c0392b', '#2a8a4a', '#d9a441', '#3a7ad8', '#e0e0e0', '#8a3b8a']; for (let r = 0; r < 2; r++) for (let i = 0; i < 20; i++) k.rect(320 + i * 48, 220 + r * 130 - 60 + 0, 22, 60 - (i % 3) * 8, k.gi(C[(i + r) % 6]), 'rx="4" opacity=".9"'); k.neon(120, 130, 260, 80, 'OPEN', '#3aff8a', 40); },
    props: (k, y) => { F.counter(k, 240, y, 1120, '#4a2a18', '#7a4a2a', false); for (let i = 0; i < 6; i++) F.stool(k, 320 + i * 180, y + 50, '#8a1b2e'); },
    light: (k) => { for (let i = 0; i < 4; i++) F.pendant(k, 350 + i * 300, 190, '#e8a85a'); },
  })),
  P('nightclub', 'shop', ['club', 'disco', 'dance floor'], 760, (k) => room(k, {
    wall: '#10102a', wk: 'none', floor: '#17172e', fk: 'tile', persp: true, lamps: false,
    mid: (k, y) => { k.vg(0, 0, W, y, '#150a2e', '#2a0f4a'); k.rect(520, 230, 560, 220, '#0c0c1c'); for (let i = 0; i < 8; i++) k.rect(540 + i * 68, 250, 52, 180, k.g(['#ff3d9a', '#3aa0ff', '#ffd54a', '#3aff8a'][i % 4]), 'opacity=".5"'); k.circle(800, 90, 40, '#d8d8ff'); },
    props: (k, y) => { for (let i = 0; i < 6; i++) k.shaft(250 + i * 220, 20, 40, 700, ['#ff3d9a', '#3aa0ff', '#ffd54a', '#3aff8a', '#b04ad8', '#ff6a3a'][i], .28, 3); for (let i = 0; i < 4; i++) k.neon(80 + i * 380, 120, 220, 60, '', ['#ff3d9a', '#3aa0ff', '#3aff8a', '#ffd54a'][i], 0); k.rect(0, y - 150, W, 150, '#000', 'opacity=".28"'); k.crowd(y + 50, 14, 0, W, .8, ['#2a1a4a', '#3a1a2a', '#1a2a4a']); },
    light: (k, y) => { k.glow(800, y + 40, 700, '#b04ad8', .25); },
  })),
  P('supermarket', 'shop', ['grocery store', 'market', 'store aisle'], 760, (k) => room(k, {
    wall: '#e8e4dc', wk: 'none', floor: '#c8c4bc', fk: 'tile',
    mid: (k, y) => { k.sign(500, 70, 600, 70, 'FRESH MARKET', '#2a8a4a', '#fff', 40); F.goods(k, 80, y, 380, 380, 4); F.goods(k, 1140, y, 380, 380, 4); },
    props: (k, y) => { F.goods(k, 560, y - 4, 160, 240, 3); F.goods(k, 880, y - 4, 160, 240, 3); k.obj(1120, y - 70, 70, 60, k.gi('#b8bcc4'), {}); k.line(1100, y - 120, 1200, y - 120, '#777', 4); },
    light: (k) => { F.tubes(k, 20, 5, 200, 1400); },
  })),
  P('mall', 'shop', ['shopping mall', 'shopping centre', 'arcade mall'], 770, (k) => room(k, {
    wall: '#e6e0d6', wk: 'none', floor: '#d8d0c4', fk: 'tile', persp: true, ceil: 80,
    mid: (k, y) => { for (let i = 0; i < 3; i++) { const x = 60 + i * 520; k.obj(x, 220, 440, y - 220, k.gi(['#3a7ad8', '#d9a441', '#b04a6a'][i]), { r: 2 }); k.rect(x + 20, 250, 400, 120, '#000', 'opacity=".25"'); k.sign(x + 90, 160, 260, 56, ['FASHION', 'SHOES', 'TECH'][i], '#12263f', '#fff', 30); k.rect(x + 20, y - 240, 400, 220, '#cfe6f4', 'opacity=".5"'); k.rect(x + 20, y - 240, 400, 220, '#000', 'opacity=".12"'); } },
    props: (k, y) => { k.crowd(y + 20, 8, 0, W, .9); F.plant(k, 520, y + 40, 1.2); F.bench(k, 1040, y + 50, 260); },
    light: (k) => { F.tubes(k, 90, 6, 140, 1460); },
  })),
  P('convenienceStore', 'shop', ['corner store', 'bodega', '7-eleven', 'minimart'], 760, (k) => room(k, {
    wall: '#e0dcd0', wk: 'tile', floor: '#b8b4aa', fk: 'tile',
    mid: (k, y) => { F.goods(k, 60, y, 560, 420, 5); k.rect(700, 170, 800, 12, '#9aa0a8'); k.obj(700, 190, 800, 240, k.gi('#2a3a4a'), { r: 3 }); for (let i = 0; i < 5; i++) k.rect(720 + i * 156, 210, 140, 200, '#bfe6ff', 'opacity=".3"'); },
    props: (k, y) => { F.counter(k, 1000, y + 40, 480, '#c0392b', '#e8e8ee', false); k.obj(1160, y - 200, 90, 56, k.gi('#222'), {}); F.goods(k, 700, y - 8, 200, 260, 3); },
    light: (k) => { F.tubes(k, 20, 4, 300, 1300); },
  })),
  P('bookstore', 'shop', ['book shop', 'bookshop'], 750, (k) => room(k, {
    wall: '#5a3b2e', wk: 'plaster', floor: '#4a3426', wins: [[640, 140, 300, 260, 2, 2]],
    mid: (k, y) => { F.shelf(k, 60, y, 520, 560, 5); F.shelf(k, 1020, y, 520, 560, 5); },
    props: (k, y) => { F.table(k, 640, y + 60, 320, '#6a4a30', 110); for (let i = 0; i < 6; i++) k.rect(670 + i * 44, y - 140 + (i % 2) * 4, 36, 12, k.gi(['#8a3b2e', '#2f5d7a', '#d9a441'][i % 3])); F.plant(k, 1560, y, 1); },
    light: (k) => { F.pendant(k, 780, 220); k.lampIn(300, 300, 340, '#ffd88a', .12 + .2 * k.lampK); },
  })),
  P('pharmacy', 'shop', ['drugstore', 'chemist'], 750, (k) => room(k, {
    wall: '#e8f0f0', wk: 'none', floor: '#c4ccd0', fk: 'tile',
    mid: (k, y) => { k.sign(600, 70, 400, 70, 'PHARMACY', '#1a8a5a', '#fff', 40); F.goods(k, 80, y, 460, 420, 4); F.goods(k, 1060, y, 460, 420, 4); },
    props: (k, y) => { F.counter(k, 600, y + 30, 400, '#e8e8ee', '#cfcfd6', false); },
    light: (k) => { F.tubes(k, 20, 5, 200, 1400); },
  })),
  P('barbershop', 'shop', ['hair salon', 'salon', 'barber'], 750, (k) => room(k, {
    wall: '#2a4a5a', wk: 'plaster', floor: '#d8d0c4', fk: 'tile', wains: 160, wc: '#e8e2d6',
    mid: (k, y) => { for (let i = 0; i < 3; i++) { k.obj(150 + i * 420, 200, 200, 280, k.gi('#8a6a40'), { r: 8 }); k.vg(162 + i * 420, 212, 176, 256, k.gi('#d9eef8'), k.gi('#8fb4c8')); } k.sign(580, 60, 440, 60, 'BARBER SHOP', '#8a1b2e', '#fff', 34); },
    props: (k, y) => { for (let i = 0; i < 3; i++) { k.shadow(250 + i * 420, y + 6, 70, 10, .4); k.obj(210 + i * 420, y - 80, 80, 80, k.gi('#8a1b2e'), { r: 18 }); k.rect(240 + i * 420, y - 20, 20, 20, '#777'); k.obj(190 + i * 420, y - 150, 120, 80, k.gi('#8a1b2e'), { r: 14 }); } k.rect(1480, y - 260, 40, 260, '#fff'); k.add(`<g opacity=".8">${[0, 1, 2, 3, 4].map((i) => `<polygon points="1480,${y - 260 + i * 52} 1520,${y - 260 + i * 52 - 26} 1520,${y - 260 + i * 52 + 0} 1480,${y - 260 + i * 52 + 26}" fill="${i % 2 ? '#c0392b' : '#2a62c9'}"/>`).join('')}</g>`); },
    light: (k) => { F.pendant(k, 360, 120); F.pendant(k, 780, 120); F.pendant(k, 1200, 120); },
  })),
  P('bakery', 'shop', ['pastry shop', 'patisserie'], 750, (k) => room(k, {
    wall: '#f2d9b0', wk: 'tile', floor: '#c9a47a', fk: 'tile', wains: 220, wc: '#c98a5a',
    mid: (k, y) => { k.sign(560, 70, 480, 66, 'BAKERY', '#8a3b2e', '#fff3d0', 40); F.shelf(k, 80, y, 400, 420, 4, ['#d9a441', '#c98a5a', '#e8c88a', '#a0623a']); F.shelf(k, 1120, y, 400, 420, 4, ['#d9a441', '#c98a5a', '#e8c88a', '#a0623a']); },
    props: (k, y) => { F.counter(k, 560, y + 30, 480, '#c98a5a', '#fff3d0', false); k.obj(580, y - 230, 440, 80, k.gi('#d9eef8'), { r: 6 }); for (let i = 0; i < 6; i++) k.add(`<ellipse cx="${620 + i * 70}" cy="${y - 180}" rx="26" ry="14" fill="${k.gi(['#e8b86a', '#c98a5a', '#f2d9a0'][i % 3])}"/>`); },
    light: (k) => { F.pendant(k, 400, 200, '#e8a85a'); F.pendant(k, 1200, 200, '#e8a85a'); },
  })),
  P('flowerShop', 'shop', ['florist'], 750, (k) => room(k, {
    wall: '#d4e6c8', wk: 'plaster', floor: '#b8a68a', fk: 'tile', wins: [[1000, 130, 460, 360, 3, 2]],
    mid: (k, y) => { F.shelf(k, 70, y, 420, 420, 4, ['#e84a8a', '#f2c230', '#b04ad8', '#3a9a5a']); },
    props: (k, y) => { for (let i = 0; i < 5; i++) { k.obj(560 + i * 130, y - 90, 100, 90, k.gi('#9a6a3a'), { r: 6 }); for (let j = 0; j < 6; j++) { k.circle(580 + i * 130 + j * 14, y - 130 - (j % 3) * 16, 14, k.gi(['#e84a8a', '#f2c230', '#b04ad8', '#e8453a', '#fff'][(i + j) % 5])); } } F.plant(k, 1500, y, 1.4); },
  })),
  P('laundromat', 'shop', ['laundrette', 'laundry'], 760, (k) => room(k, {
    wall: '#bcd0dc', wk: 'tile', floor: '#9aa0a8', fk: 'tile', wins: [[1160, 140, 340, 280, 2, 2]],
    mid: (k, y) => { for (let i = 0; i < 6; i++) { const x = 80 + i * 190; k.obj(x, y - 240, 170, 240, k.gi('#e8ecf0'), { r: 8 }); k.circle(x + 85, y - 120, 56, '#2a3a4a', 'stroke="#9aa0a8" stroke-width="8"'); k.circle(x + 85, y - 120, 40, k.g('#7fb8e0'), 'opacity=".6"'); k.rect(x + 20, y - 232, 130, 18, '#2a3a4a'); } },
    props: (k, y) => { F.bench(k, 1250, y + 40, 260, '#8a6a46'); k.box(1300, y - 140, 100, 70, '#e8453a'); },
    light: (k) => { F.tubes(k, 20, 4, 300, 1300); },
  })),
  P('gym', 'shop', ['fitness center', 'weight room', 'health club'], 760, (k) => room(k, {
    wall: '#2a2e38', wk: 'panel', floor: '#1c1e24', fk: 'tile', frame: '#333',
    mid: (k, y) => { k.vg(60, 150, 760, 440, k.gi('#bfd4e0'), k.gi('#8fa8b8')); k.line(60, 150, 820, 590, '#fff', 4, .2); k.sign(1000, 110, 500, 80, 'NO PAIN NO GAIN', '#c0392b', '#fff', 34); },
    props: (k, y) => { for (let i = 0; i < 3; i++) { k.obj(900 + i * 190, y - 20, 150, 16, '#222', { r: 3 }); k.rect(920 + i * 190, y - 170, 10, 150, '#444'); k.rect(1000 + i * 190, y - 170, 10, 150, '#444'); k.obj(900 + i * 190, y - 200, 150, 40, '#c0392b', {}); } for (let i = 0; i < 5; i++) { k.obj(130 + i * 100, y - 40 - (i % 2) * 6, 70 + (i % 3) * 14, 40, '#2a2a30', { r: 18 }); } k.obj(1200, y - 50, 300, 30, k.gi('#444'), { r: 3 }); },
    light: (k) => { F.tubes(k, 20, 5, 200, 1400); },
  })),
  P('hotelLobby', 'shop', ['hotel reception', 'lobby', 'reception'], 770, (k) => room(k, {
    wall: '#e8dcc4', wk: 'panel', floor: '#cfc4b0', fk: 'tile', persp: true, ceil: 70,
    mid: (k, y) => { F.painting(k, 640, 160, 320, 220, '#d9a441', '#8a3b2e'); for (let i = 0; i < 4; i++) { k.obj(80 + i * 40, 100, 18, y - 100, k.gi('#f4efe3'), {}); k.obj(1440 - i * 40, 100, 18, y - 100, k.gi('#f4efe3'), {}); } },
    props: (k, y) => { F.counter(k, 520, y + 30, 560, '#6a4a30', '#cfcfd6', false); F.sofa(k, 90, y + 20, 340, '#6a2a3a'); F.armchair(k, 1180, y + 20, '#6a2a3a'); F.plant(k, 1500, y + 20, 1.5); F.rug(k, 480, y + 100, 680, '#8a3b4e'); },
    light: (k) => { F.pendant(k, 400, 160, '#e8c868'); F.pendant(k, 800, 160, '#e8c868'); F.pendant(k, 1200, 160, '#e8c868'); },
  })),
  P('hotelRoom', 'shop', ['hotel suite', 'motel room'], 750, (k) => room(k, {
    wall: '#d4c4a8', wk: 'plaster', floor: '#6a5a4a', fk: 'wood', wins: [[1100, 150, 320, 300, 2, 2]],
    mid: (k, y) => { F.curtain(k, 1070, 120, 380, 360, '#8a3b4e'); F.painting(k, 460, 190, 340, 180, '#8ab0d8', '#d9a441'); },
    props: (k, y) => { F.bed(k, 340, y - 8, 560, '#f4f0e8'); F.table(k, 220, y, 100, '#5a3b24', 120); F.table(k, 920, y, 100, '#5a3b24', 120); F.tv(k, 1130, y - 130, 150, true); },
    light: (k) => { k.lampIn(270, 560, 180, '#ffd08a', .15 + .35 * k.lampK); k.lampIn(970, 560, 180, '#ffd08a', .15 + .35 * k.lampK); },
  })),
  P('hotelHallway', 'shop', ['hotel corridor', 'motel hallway'], 780, (k) => {
    k.out = false;
    k.layer('end wall', () => { k.wall(0, 780, '#cbb89a', { kind: 'plaster' }); k.rect(560, 190, 480, 460, k.gi('#8a2a3a')); k.door(700, 300, 200, 350, '#4a2a1a'); });
    k.layer('side walls', () => { k.poly([[0, 0], [560, 190], [560, 650], [0, 900]], k.gi('#bba888')); k.poly([[W, 0], [1040, 190], [1040, 650], [W, 900]], k.gi('#a89878')); for (let i = 0; i < 4; i++) { const t = (i + 1) / 5, x = 560 * (1 - t) + 0 * t, w0 = 90 * (1 - t) + 20; k.door(30 + i * 110, 700 - i * 40, 70 - i * 10, 330 - i * 60 + 0, '#5a3b24'); k.door(1500 - i * 110, 700 - i * 40, 70 - i * 10, 330 - i * 60, '#5a3b24'); } });
    k.layer('floor', () => { k.poly([[0, 900], [560, 650], [1040, 650], [W, 900]], k.gi('#7a2a3a')); k.poly([[0, 900], [560, 650], [1040, 650], [W, 900]], 'none', 'stroke="#d9b84a" stroke-width="6" opacity=".4"'); k.sheen(780, '#ffe9bd', .12); });
    k.layer('light', () => { for (let i = 0; i < 4; i++) k.lampIn(800, 60 + i * 120, 120 + i * 40, '#ffe2a0', .4); });
    k.finish();
  }, { floor: 780 }),

  // ---------------- work and public ----------------
  P('openOffice', 'work', ['coworking', 'open plan office', 'workspace', 'startup office'], 760, (k) => room(k, {
    wall: '#dcdfe6', wk: 'none', floor: '#8a8f9a', fk: 'tile', wins: [[80, 120, 1440, 360, 6, 2]], view: 'city', frame: '#9aa0a8',
    mid: (k, y) => { for (let i = 0; i < 3; i++) { F.desk(k, 100 + i * 500, y - 20, 380, '#e8e8ee'); F.monitor(k, 180 + i * 500, y - 150, 140); F.chair(k, 220 + i * 500, y + 10, '#2a2f3a'); } },
    props: (k, y) => { F.plant(k, 1540, y, 1.3); F.plant(k, 40, y, 1.3); },
    light: (k) => { F.tubes(k, 20, 5, 200, 1400); },
  })),
  P('cubicles', 'work', ['cubicle farm', 'call center'], 760, (k) => room(k, {
    wall: '#cfd4da', wk: 'none', floor: '#6a6e78', fk: 'tile',
    mid: (k, y) => { for (let i = 0; i < 4; i++) { const x = 60 + i * 380; k.obj(x, y - 360, 350, 360, k.gi('#8a95a8'), { r: 4 }); k.tex('stripes', x, y - 360, 350, 360, { c: '#000', op: .05, t: 18 }); F.desk(k, x + 20, y - 10, 310, '#e8e8ee'); F.monitor(k, x + 100, y - 140, 130); F.chair(k, x + 150, y + 20, '#2a2f3a'); } },
    light: (k) => { F.tubes(k, 20, 5, 200, 1400); },
  })),
  P('boardroom', 'work', ['conference room', 'meeting room'], 760, (k) => room(k, {
    wall: '#2a3a4a', wk: 'panel', floor: '#3a3a42', fk: 'tile', wins: [[1060, 110, 440, 400, 3, 2]], view: 'city',
    mid: (k, y) => { F.whiteboard(k, 140, 170, 760, 300); k.sign(520, 60, 360, 50, 'BOARDROOM', '#1a1e28', '#c9a24a', 26); },
    props: (k, y) => { k.shadow(800, y + 70, 720, 20, .4); k.obj(200, y - 20, 1200, 36, k.gi('#4a2a1a'), { r: 18 }); k.obj(520, y + 16, 40, 50, k.gi('#222'), {}); k.obj(1040, y + 16, 40, 50, k.gi('#222'), {}); for (let i = 0; i < 6; i++) F.chair(k, 260 + i * 190, y + 50, '#1a1e28', i > 2); },
    light: (k) => { for (let i = 0; i < 3; i++) k.lampIn(400 + i * 400, 80, 340, '#eaf3ff', .14 + .1 * k.lampK); },
  })),
  P('serverRoom', 'work', ['data center', 'datacenter'], 770, (k) => room(k, {
    wall: '#10141c', wk: 'metal', floor: '#1a1e28', fk: 'tile', persp: true, lamps: false,
    mid: (k, y) => { for (let i = 0; i < 10; i++) F.rack(k, 40 + i * 156, y - 20 - (i % 2) * 0, 140, 540 - (i % 2) * 40, '#222836'); },
    props: (k, y) => { k.rect(0, y - 4, W, 8, '#3aa0ff', 'opacity=".3"'); },
    light: (k, y) => { k.glow(800, 400, 800, '#3aa0ff', .12); k.glow(300, y - 200, 300, '#3cff7a', .08); },
  })),
  P('labClean', 'work', ['science lab', 'research lab', 'chemistry lab', 'laboratory'], 760, (k) => room(k, {
    wall: '#e4eaee', wk: 'tile', t: 70, floor: '#b4bcc4', fk: 'tile', wins: [[1120, 130, 380, 280, 3, 2]],
    mid: (k, y) => { F.counter(k, 60, y, 820, '#dfe6ee', '#2a3038', true); for (let i = 0; i < 6; i++) { const bx = 150 + i * 110, by = y - 144; k.path(`M${bx - 14},${by} h28 l10,-60 h-48 z`, k.g(['#7fd0ff', '#ff8aa8', '#a0ff9a', '#ffe27a'][i % 4]), 'opacity=".8" stroke="#223" stroke-width="2"'); k.rect(bx - 6, by - 82, 12, 24, 'none', 'stroke="#223" stroke-width="2"'); } },
    props: (k, y) => { F.rack(k, 960, y, 160, 360, '#cfd6dd'); k.obj(1180, y - 130, 200, 130, k.gi('#cfd6dd'), { r: 4 }); F.monitor(k, 1210, y - 130, 140); },
    light: (k) => { F.tubes(k, 20, 4, 300, 1300); },
  })),
  P('hospitalRoom', 'work', ['hospital ward', 'patient room', 'sick room'], 760, (k) => room(k, {
    wall: '#d8e6ea', wk: 'none', floor: '#c4ccd0', fk: 'tile', wains: 220, wc: '#9cc4d0', wins: [[1100, 140, 340, 280, 2, 2]],
    mid: (k, y) => { F.curtain(k, 600, 100, 380, 460, '#a0c4d4'); k.obj(100, 210, 340, 160, k.gi('#bfc8cf'), { r: 4 }); k.add(`<path d="M120,310 l50,0 l16,-40 l22,80 l20,-40 l100,0" stroke="${k.g('#3cff7a')}" stroke-width="4" fill="none"/>`); },
    props: (k, y) => { F.cot(k, 700, y + 10, 360, '#eef2f6'); F.table(k, 1100, y + 10, 160, '#cfd6dd', 110); k.obj(1000, y - 300, 10, 300, '#999', {}); k.rect(960, y - 300, 90, 8, '#999'); k.add(`<ellipse cx="1000" cy="${y - 250}" rx="26" ry="36" fill="${k.g('#c8e6ff')}" opacity=".8" stroke="#667" stroke-width="3"/>`); },
    light: (k) => { F.tubes(k, 20, 3, 400, 1200); },
  })),
  P('hospitalHall', 'work', ['hospital corridor', 'er hallway', 'emergency room'], 780, (k) => {
    k.out = false;
    k.layer('end wall', () => { k.wall(0, 780, '#d8e6ea', { kind: 'none' }); k.rect(560, 200, 480, 450, k.gi('#bcd0d8')); k.door(680, 260, 240, 390, '#a0c4d4', { glass: true }); k.sign(650, 140, 300, 44, 'EMERGENCY', '#c0392b', '#fff', 26); });
    k.layer('side walls', () => { k.poly([[0, 0], [560, 200], [560, 650], [0, 900]], k.gi('#cfdde2')); k.poly([[W, 0], [1040, 200], [1040, 650], [W, 900]], k.gi('#c0d0d6')); k.poly([[0, 560], [560, 470], [560, 520], [0, 640]], k.gi('#7fb4c8')); k.poly([[W, 560], [1040, 470], [1040, 520], [W, 640]], k.gi('#7fb4c8')); for (let i = 0; i < 3; i++) { k.door(70 + i * 140, 690 - i * 60, 90 - i * 18, 300 - i * 60, '#e8eef2'); k.door(1440 - i * 140, 690 - i * 60, 90 - i * 18, 300 - i * 60, '#e8eef2'); } });
    k.layer('floor', () => { k.poly([[0, 900], [560, 650], [1040, 650], [W, 900]], k.gi('#b4bcc4')); k.line(800, 650, 800, 900, '#7fb4c8', 6, .7); k.sheen(780, '#eaf3ff', .2); });
    k.layer('ceiling', () => { k.poly([[0, 0], [560, 200], [1040, 200], [W, 0]], k.gi('#e8eef2')); for (let i = 0; i < 4; i++) { const t = i / 4; k.lampIn(800, 30 + i * 36 + t * 40, 160 - i * 28, '#eaf3ff', .5); } });
    k.finish();
  }, { floor: 780 }),
  P('operatingRoom', 'work', ['surgery', 'surgical theatre', 'operating theatre'], 760, (k) => room(k, {
    wall: '#9cc4b8', wk: 'tile', t: 60, floor: '#aab4b8', fk: 'tile',
    mid: (k, y) => { F.rack(k, 100, y, 200, 380, '#cfd6dd'); F.rack(k, 1300, y, 200, 380, '#cfd6dd'); for (let i = 0; i < 3; i++) { k.circle(520 + i * 280, 150, 70, k.gi('#e8ecf0'), 'stroke="#667" stroke-width="4"'); } },
    props: (k, y) => { k.shadow(800, y + 40, 280, 12, .4); k.obj(560, y - 120, 480, 40, k.gi('#d8dee4'), { r: 10 }); k.rect(790, y - 80, 20, 80, '#888'); k.obj(740, y - 10, 120, 20, '#777', {}); },
    light: (k) => { for (let i = 0; i < 3; i++) k.shaft(520 + i * 280, 200, 120, 540, '#fff', .25, 1.5); F.tubes(k, 20, 3, 400, 1200); },
  })),
  P('classroom', 'work', ['school classroom', 'schoolroom'], 760, (k) => room(k, {
    wall: '#d9d2b0', wk: 'plaster', floor: '#a88a60', wains: 160, wc: '#6a8a6a', wins: [[1100, 150, 420, 300, 3, 2]],
    mid: (k, y) => { F.board(k, 200, 150, 720, 300, '#25483a'); F.clock(k, 1000, 130, 34); k.sign(560, 70, 320, 44, 'WELCOME', '#8a3b4e', '#fff', 24); },
    props: (k, y) => { for (let r = 0; r < 2; r++) for (let i = 0; i < 4; i++) F.schoolDesk(k, 150 + i * 280 + r * 30, y + 20 + r * 60, 1 + r * .2); F.table(k, 1280, y, 240, '#8a5a3a', 130); },
    light: (k) => { F.tubes(k, 20, 4, 300, 1300); },
  })),
  P('lectureHall', 'work', ['auditorium', 'lecture theatre', 'university lecture'], 770, (k) => room(k, {
    wall: '#3a3f4a', wk: 'panel', floor: '#5a4a3a', fk: 'wood', persp: true,
    mid: (k, y) => { F.board(k, 300, 130, 1000, 360, '#1f3a2e'); for (let i = 0; i < 5; i++) { k.obj(60, y - 80 - i * 36, 1480, 22, k.gi('#6a4a30'), { r: 2 }); } },
    props: (k, y) => { k.obj(540, y - 150, 520, 40, k.gi('#7a5a3a'), { r: 3 }); k.rect(560, y - 110, 18, 110, '#5a3b24'); k.rect(1020, y - 110, 18, 110, '#5a3b24'); },
    light: (k) => { F.tubes(k, 20, 4, 300, 1300); },
  })),
  P('schoolHallway', 'work', ['school corridor', 'school hall'], 780, (k) => {
    k.out = false;
    k.layer('end wall', () => { k.wall(0, 780, '#cbb98a', { kind: 'none' }); k.door(690, 280, 220, 370, '#3f6a8a', { glass: true }); });
    k.layer('lockers L', () => { for (let i = 0; i < 5; i++) { const t = i / 5, x = 40 + i * 100 * (1 - t * .5), h = 420 - i * 58; k.obj(x, 700 - i * 10 - h + 70, 92 - i * 14, h - 70 + 0, k.gi(k.v('#3f6a8a', .3)), { r: 2 }); } });
    k.layer('lockers R', () => { for (let i = 0; i < 5; i++) { const x = 1470 - i * 100 * (1 - i / 10), h = 420 - i * 58; k.obj(x - 70 + i * 14, 700 - i * 10 - h + 70, 92 - i * 14, h - 70, k.gi(k.v('#3f6a8a', .3)), { r: 2 }); } });
    k.layer('floor', () => { k.poly([[0, 900], [560, 650], [1040, 650], [W, 900]], k.gi('#b8a888')); k.tex('tile', 0, 650, W, 250, { c: '#000', op: .12, t: 80 }); k.sheen(780, '#fff3d0', .2); });
    k.layer('light', () => F.tubes(k, 40, 4, 500, 1100)); k.finish();
  }, { floor: 780 }),
  P('library', 'work', ['reading room', 'public library', 'study hall'], 760, (k) => room(k, {
    wall: '#6a4a38', wk: 'plaster', floor: '#5a4030', wins: [[640, 130, 320, 380, 2, 3]],
    mid: (k, y) => { F.shelf(k, 40, y, 540, 600, 5); F.shelf(k, 1020, y, 540, 600, 5); },
    props: (k, y) => { F.table(k, 560, y + 60, 480, '#8a5a3a', 120); for (let i = 0; i < 4; i++) k.obj(600 + i * 100, y - 130, 70, 8, k.gi(['#c0392b', '#2a62c9', '#2a8a4a', '#d9a441'][i]), {}); F.chair(k, 560, y + 60, '#5a3b24'); F.chair(k, 960, y + 60, '#5a3b24', true); k.lampIn(800, y - 150, 200, '#ffd88a', .15 + .3 * k.lampK); },
    light: (k) => { F.pendant(k, 800, 200, '#2a6a3a'); },
  })),
  P('cafeteria', 'work', ['canteen', 'lunch room', 'dining hall', 'school cafeteria'], 760, (k) => room(k, {
    wall: '#e0d8b8', wk: 'none', floor: '#a8a090', fk: 'tile', wins: [[80, 130, 700, 300, 5, 2]],
    mid: (k, y) => { k.sign(900, 90, 500, 70, 'LUNCH', '#8a3b2e', '#fff', 44); F.counter(k, 900, y, 640, '#9aa0a8', '#cfcfd6', false); },
    props: (k, y) => { for (let i = 0; i < 3; i++) { F.table(k, 120 + i * 270, y + 70, 240, '#c9b48a', 100); F.bench(k, 120 + i * 270, y + 110, 240, '#c9b48a'); } },
    light: (k) => { F.tubes(k, 20, 4, 300, 1300); },
  })),
  P('courtroom', 'work', ['court', 'courthouse', 'trial room', 'judge room'], 770, (k) => room(k, {
    wall: '#6a4a30', wk: 'panel', floor: '#4a3220', fk: 'wood', wains: 0,
    mid: (k, y) => { k.obj(540, y - 320, 520, 320, k.gi('#4a2a18'), { r: 4 }); k.obj(500, y - 360, 600, 50, k.gi('#5a3420'), { r: 4 }); k.add(`<path d="M780,${y - 440} h40 v34 h-40 z" fill="${k.g('#c9a24a')}"/>`); k.circle(800, y - 560, 80, k.gi('#c9a24a'), 'stroke="#5a4a1a" stroke-width="6"'); k.sign(700, y - 600, 200, 40, 'JUSTICE', '#2a1a10', '#c9a24a', 24); k.rect(100, 80, 24, y - 80, k.gi('#f4efe3')); k.rect(1476, 80, 24, y - 80, k.gi('#f4efe3')); },
    props: (k, y) => { k.obj(140, y - 100, 300, 100, k.gi('#5a3420'), { r: 3 }); k.obj(1160, y - 100, 300, 100, k.gi('#5a3420'), { r: 3 }); for (let i = 0; i < 2; i++) { k.obj(260 + i * 520, y + 30, 360, 20, k.gi('#4a2a18'), {}); } k.obj(680, y - 120, 240, 120, k.gi('#4a2a18'), { r: 3 }); },
    light: (k) => { F.pendant(k, 400, 160); F.pendant(k, 1200, 160); },
  })),
  P('policeStation', 'work', ['police office', 'precinct', 'interrogation room'], 760, (k) => room(k, {
    wall: '#4a5a6a', wk: 'plaster', floor: '#6a6a70', fk: 'tile', wains: 180, wc: '#2a3a4a',
    mid: (k, y) => { F.board(k, 180, 170, 460, 240, '#3a2a1a', false); for (let i = 0; i < 6; i++) k.rect(210 + (i % 3) * 140, 190 + Math.floor(i / 3) * 100, 110, 80, k.gi('#f4efe3'), 'transform="rotate(' + (i * 3 - 6) + ' 300 300)"'); k.add(`<path d="M260,250 L420,330 L540,230" stroke="#c0392b" stroke-width="3" fill="none"/>`); k.sign(700, 120, 400, 60, 'POLICE', '#12263f', '#fff', 40); },
    props: (k, y) => { F.desk(k, 780, y, 460, '#6a6a70'); F.monitor(k, 880, y - 130, 150); F.chair(k, 960, y + 30, '#222'); F.rack(k, 1340, y, 200, 360, '#5a6068'); },
    light: (k) => { F.tubes(k, 20, 4, 300, 1300); },
  })),
  P('jailCell', 'work', ['prison cell', 'jail', 'prison'], 770, (k) => room(k, {
    wall: '#5a5e66', wk: 'stone', floor: '#3a3a40', fk: 'concrete', frame: '#222',
    mid: (k, y) => { k.rect(560, 130, 180, 110, '#0a0c12'); for (let i = 0; i < 4; i++) k.rect(580 + i * 40, 130, 8, 110, k.gi('#444')); k.shaft(650, 240, 160, 520, '#cfe0ff', .2, 2.4); F.cot(k, 120, y, 380, '#8a8f98'); },
    props: (k, y) => { F.bars(k, 0, 0, W, 770); k.obj(1180, y - 90, 140, 90, k.gi('#9aa0a8'), { r: 4 }); },
    light: (k) => { k.lampIn(800, 60, 500, '#e8f0ff', .14); },
  })),
  P('vault', 'work', ['bank vault', 'safe room'], 770, (k) => room(k, {
    wall: '#6a7078', wk: 'metal', floor: '#2a2e36', fk: 'tile', frame: '#222',
    mid: (k, y) => { k.circle(800, 440, 280, k.gi('#8a909a'), 'stroke="#222" stroke-width="10"'); k.circle(800, 440, 220, k.gi('#6a707a'), 'stroke="#222" stroke-width="8"'); for (let i = 0; i < 8; i++) { const a = i * Math.PI / 4; k.line(800 + Math.cos(a) * 60, 440 + Math.sin(a) * 60, 800 + Math.cos(a) * 180, 440 + Math.sin(a) * 180, '#222', 10); } k.circle(800, 440, 40, k.gi('#c9a24a'), 'stroke="#222" stroke-width="6"'); },
    props: (k, y) => { for (let i = 0; i < 6; i++) { k.obj(60 + i * 70, y - 80, 60, 80, k.gi('#c9a24a'), {}); k.obj(1130 + i * 70, y - 80, 60, 80, k.gi('#3a8a4a'), {}); } },
    light: (k) => { k.lampIn(800, 60, 600, '#ffe9bd', .16); },
  })),
  P('bankLobby', 'work', ['bank branch', 'bank counter'], 760, (k) => room(k, {
    wall: '#e4e0d0', wk: 'panel', floor: '#a89878', fk: 'tile', ceil: 60,
    mid: (k, y) => { for (let i = 0; i < 4; i++) { k.obj(120 + i * 380, y - 220, 300, 220, k.gi('#8a6a40'), { r: 3 }); k.rect(140 + i * 380, y - 220, 260, 110, '#bfe6ff', 'opacity=".35" stroke="#222" stroke-width="3"'); } k.sign(560, 70, 480, 60, 'FIRST NATIONAL BANK', '#1a3a2a', '#d9c48a', 28); },
    props: (k, y) => { k.rect(300, y + 30, 1000, 10, '#8a2a3a', 'opacity=".5"'); F.plant(k, 40, y + 30, 1.3); F.plant(k, 1540, y + 30, 1.3); },
    light: (k) => { F.pendant(k, 400, 200, '#c9a24a'); F.pendant(k, 1200, 200, '#c9a24a'); },
  })),
  P('church', 'work', ['chapel', 'cathedral interior', 'place of worship'], 770, (k) => room(k, {
    wall: '#cbbfa6', wk: 'stone', floor: '#8a7a68', fk: 'tile', persp: true, frame: '#6a4a30',
    mid: (k, y) => { k.add(`<path d="M560,${y} V320 Q800,40 1040,320 V${y} Z" fill="${k.gi('#e8dcc4')}" stroke="#222" stroke-opacity=".4" stroke-width="4"/>`); k.circle(800, 220, 66, k.g('#e8453a'), 'stroke="#222" stroke-width="6"'); k.circle(800, 220, 34, k.g('#f2c230')); k.rect(780, 360, 40, 200, k.gi('#8a6a40')); k.rect(740, 410, 120, 36, k.gi('#8a6a40')); for (const s of [-1, 1]) { k.rect(300 + (s > 0 ? 840 : 0), 120, 100, 460, k.g(['#3a7ad8', '#b04ad8'][s > 0 ? 1 : 0]), 'opacity=".75" stroke="#222" stroke-width="5"'); k.shaft(350 + (s > 0 ? 840 : 0), 560, 100, 220, '#bcd0ff', .2, 3); } },
    props: (k, y) => { for (let i = 0; i < 3; i++) { F.pew(k, 60 + (i % 2) * 40, y + 40 + i * 28, 480 - i * 20); F.pew(k, 1060 - (i % 2) * 40, y + 40 + i * 28, 480 - i * 20); } k.obj(700, y - 90, 200, 90, k.gi('#8a6a40'), {}); },
    light: (k) => { k.lampIn(800, 220, 500, '#ffe0a0', .12 + .15 * k.lampK); },
  })),
  P('museum', 'work', ['exhibition hall', 'history museum'], 770, (k) => room(k, {
    wall: '#e4dcc8', wk: 'plaster', floor: '#b8a888', fk: 'tile', persp: true, ceil: 50,
    mid: (k, y) => { for (let i = 0; i < 3; i++) { F.painting(k, 100 + i * 500, 150, 360, 250, ['#8ab0d8', '#d98a6a', '#8ab08a'][i], ['#d9a441', '#4a3a2a', '#e8c868'][i]); k.lampIn(280 + i * 500, 130, 220, '#ffe9bd', .18); } },
    props: (k, y) => { for (let i = 0; i < 3; i++) { k.obj(220 + i * 480, y - 90, 140, 90, k.gi('#f4efe3'), { r: 3 }); k.obj(240 + i * 480, y - 200, 100, 120, k.g('#bfe6ff'), { r: 3 }); k.circle(290 + i * 480, y - 150, 26, k.gi('#c9a24a')); } F.bench(k, 1300, y + 20, 200, '#6a4a30'); },
    light: (k) => { F.tubes(k, 20, 3, 400, 1200); },
  })),
  P('gallery', 'work', ['art gallery', 'art studio gallery'], 760, (k) => room(k, {
    wall: '#f0ece4', wk: 'none', floor: '#c4b8a4', fk: 'wood', wains: 0,
    mid: (k, y) => { const C = [['#e8453a', '#f2c230'], ['#3a7ad8', '#b04ad8'], ['#3a9a5a', '#e8c868'], ['#d98a6a', '#2a4a7a']]; for (let i = 0; i < 4; i++) { F.painting(k, 90 + i * 380, 190 + (i % 2) * 40, 280, 220 - (i % 2) * 30, C[i][0], C[i][1]); k.shaft(230 + i * 380, 20, 60, 600, '#fff3d0', .14, 3); } },
    props: (k, y) => { F.bench(k, 640, y + 40, 320, '#2a2a30'); k.obj(1400, y - 160, 90, 160, k.gi('#f4efe3'), {}); k.circle(1445, y - 200, 40, k.gi('#d9a441')); },
  })),
  P('theater', 'work', ['theatre', 'playhouse', 'stage curtain'], 780, (k) => room(k, {
    wall: '#2a0f1a', wk: 'none', floor: '#4a2a1a', fk: 'wood', y: 780, lamps: false,
    mid: (k, y) => { k.vg(0, 0, W, y, '#2a0f1a', '#4a1a2a'); k.vg(260, 60, 1080, y - 60, '#e8c868', '#6a4a30', 'opacity=".25"'); F.curtain(k, 120, 0, 1360, y - 40, '#9a1b3a'); k.rect(100, 0, 1400, 70, k.gi('#7a1230')); for (let i = 0; i < 14; i++) k.add(`<circle cx="${130 + i * 100}" cy="76" r="9" fill="${k.g('#ffd76b')}"/>`); },
    props: (k, y) => { k.shaft(500, 60, 120, 760, '#fff1c0', .3, 2.6); k.shaft(1100, 60, 120, 760, '#fff1c0', .3, 2.6); k.obj(0, y, W, 120, k.gi('#3a1a10'), { r: 0 }); for (let i = 0; i < 12; i++) k.add(`<ellipse cx="${100 + i * 130}" cy="${y + 140}" rx="64" ry="48" fill="#000" opacity=".7"/>`); },
    light: (k, y) => { k.glow(800, y - 120, 640, '#ffe0a0', .25); },
  })),
  P('cinema', 'work', ['movie theatre', 'movie theater', 'screening room'], 780, (k) => room(k, {
    wall: '#1a1018', wk: 'none', floor: '#2a1a1a', fk: 'tile', y: 780, lamps: false, persp: true,
    mid: (k, y) => { k.vg(0, 0, W, y, '#150c14', '#2a1420'); k.obj(300, 90, 1000, 460, '#e8ecf4', { r: 2 }); k.vg(312, 102, 976, 436, k.g('#4aa0e8'), k.g('#b0e0ff')); k.glow(800, 330, 900, '#8ac8ff', .3); },
    props: (k, y) => { for (let r = 0; r < 3; r++) for (let i = 0; i < 7; i++) { const x = 120 + i * 210 + (r % 2) * 40, yy = y - 40 + r * 40; k.obj(x, yy - 80 + r * 4, 110, 90, k.gi('#8a1b2e'), { r: 10 }); } k.crowd(y + 60, 4, 200, 1300, .8, ['#2a1a2a', '#1a1a2a']); },
    light: (k, y) => { k.shaft(800, 780, 60, 780, '#cfe6ff', .1, 8); },
  })),
  P('tvStudio', 'work', ['television studio', 'news desk', 'talk show set', 'newsroom studio'], 770, (k) => room(k, {
    wall: '#12203a', wk: 'none', floor: '#1a1e28', fk: 'tile', frame: '#333', lamps: false,
    mid: (k, y) => { k.vg(0, 0, W, y, '#0c1630', '#1c3260'); for (let i = 0; i < 6; i++) k.rect(160 + i * 230, 100, 160, 400, k.g('#3a7ad8'), 'opacity=".25"'); k.neon(560, 130, 480, 90, 'NEWS', '#ff3a4a', 60); k.obj(1100, 150, 360, 220, '#0a0c12', { r: 4 }); k.vg(1110, 160, 340, 200, k.g('#3a8ad8'), k.g('#0a2a5a')); },
    props: (k, y) => { k.shadow(640, y + 10, 420, 14, .4); k.obj(300, y - 130, 680, 130, k.gi('#1a2a4a'), { r: 8 }); k.rect(320, y - 134, 640, 8, '#3aa0ff'); for (let i = 0; i < 3; i++) { k.add(`<g><rect x="${60 + i * 60}" y="${y - 200 + i * 10}" width="30" height="200" fill="#222"/></g>`); k.shaft(220 + i * 520, 10, 60, 740, '#eaf3ff', .2, 3); } },
    light: (k, y) => { k.glow(640, y - 200, 620, '#7fb8ff', .18); },
  })),
  P('podcastStudio', 'work', ['recording studio', 'radio studio', 'broadcast booth'], 750, (k) => room(k, {
    wall: '#2a2230', wk: 'panel', floor: '#1c1a22', fk: 'tile', t: 60,
    mid: (k, y) => { for (let i = 0; i < 12; i++) k.rect(100 + i * 112, 160, 96, 300, k.gi('#3a2a46'), 'rx="4" opacity=".9"'); k.neon(620, 90, 360, 56, 'ON AIR', '#ff3a4a', 34); },
    props: (k, y) => { F.table(k, 420, y + 30, 760, '#3a2a20', 120); for (let i = 0; i < 3; i++) { k.rect(560 + i * 210, y - 330, 8, 200, '#222'); k.circle(564 + i * 210, y - 330, 26, '#111', 'stroke="#555" stroke-width="3"'); } F.chair(k, 520, y + 40, '#222'); F.chair(k, 900, y + 40, '#222', true); },
    light: (k) => { k.lampIn(800, 120, 560, '#ff9a6a', .14 + .1 * k.lampK); },
  })),
  P('concertHall', 'work', ['concert venue', 'opera house'], 780, (k) => room(k, {
    wall: '#3a1a2a', wk: 'none', floor: '#2a1a14', fk: 'wood', y: 780, lamps: false, persp: true,
    mid: (k, y) => { k.vg(0, 0, W, y, '#2a0f1a', '#5a2a30'); for (let i = 0; i < 7; i++) k.add(`<path d="M${100 + i * 200},0 q100,300 0,${y - 100}" stroke="${k.g('#c9a24a')}" stroke-width="10" fill="none" opacity=".7"/>`); k.obj(300, y - 220, 1000, 220, k.gi('#4a2a1a'), { r: 4 }); },
    props: (k, y) => { for (let i = 0; i < 4; i++) k.obj(400 + i * 200, y - 120, 100, 100, '#1a1a20', { r: 3 }); k.shaft(500, 0, 160, 760, '#ffe9b0', .25, 2.4); k.shaft(1100, 0, 160, 760, '#ffe9b0', .25, 2.4); },
    light: (k, y) => { k.glow(800, y - 160, 700, '#ffd88a', .22); },
  })),
  P('warehouse', 'work', ['storage warehouse', 'depot', 'distribution center', 'logistics'], 780, (k) => room(k, {
    wall: '#8a8f98', wk: 'metal', floor: '#6a6a70', fk: 'concrete', y: 780, persp: true,
    mid: (k, y) => { for (let i = 0; i < 4; i++) { const x = 90 + i * 380; k.rect(x, 160, 12, y - 160, k.gi('#c0752a')); k.rect(x + 300, 160, 12, y - 160, k.gi('#c0752a')); for (let j = 0; j < 4; j++) { k.rect(x, 200 + j * 150, 312, 12, k.gi('#d97a2a')); if (j < 3) k.box(x + 20, 200 + j * 150 - 80 + 12, 130, 80, '#a8845a'); if (j < 3) k.box(x + 160, 200 + j * 150 - 70 + 12, 130, 70, '#b8946a'); } } },
    props: (k, y) => { k.obj(1000, y - 130, 200, 18, k.gi('#d9a441'), {}); k.obj(1010, y - 220, 90, 90, k.gi('#a8845a'), {}); k.circle(1030, y + 8, 14, '#222'); k.circle(1170, y + 8, 14, '#222'); },
    light: (k) => { for (let i = 0; i < 4; i++) { k.lampIn(260 + i * 360, 40, 280, '#fff3d0', .18 + .1 * k.lampK); k.shaft(260 + i * 360, 40, 70, 600, '#fff3d0', .1, 3); } },
  })),
  P('factory', 'work', ['factory floor', 'assembly line', 'manufacturing plant', 'plant'], 780, (k) => room(k, {
    wall: '#5a6068', wk: 'metal', floor: '#3a3e44', fk: 'concrete', y: 780, wins: [[100, 90, 1400, 120, 8, 1]], frame: '#2a2e34',
    mid: (k, y) => { k.rect(0, 280, W, 22, k.gi('#d9a441')); for (let i = 0; i < 6; i++) { k.line(150 + i * 260, 302, 150 + i * 260, 420, '#222', 6); k.obj(100 + i * 260, 420, 100, 60, k.gi('#c0392b'), { r: 6 }); } },
    props: (k, y) => { k.obj(80, y - 110, 1440, 30, k.gi('#4a4e56'), { r: 4 }); for (let i = 0; i < 9; i++) { k.circle(120 + i * 170, y - 70, 14, '#222'); k.box(100 + i * 170, y - 170, 70, 60, '#a8845a'); } k.obj(1200, y - 380, 120, 270, k.gi('#d9a441'), { r: 8 }); },
    light: (k, y) => { for (let i = 0; i < 4; i++) k.lampIn(240 + i * 380, 60, 300, '#fff0c0', .2); k.glow(1260, y - 130, 200, '#ff8a3a', .25); },
  })),
  P('workshop', 'work', ['garage workshop', 'carpenter shop', 'mechanic shop', 'repair shop'], 760, (k) => room(k, {
    wall: '#8a7a64', wk: 'planks', floor: '#4a4036', fk: 'concrete',
    mid: (k, y) => { k.rect(100, 190, 900, 14, '#5a4630'); for (let i = 0; i < 12; i++) { const x = 130 + i * 70; k.line(x, 210, x, 300 + (i % 3) * 30, '#999', 5); k.rect(x - 8, 300 + (i % 3) * 30, 16, 22, k.gi(['#c0392b', '#2a62c9', '#d9a441'][i % 3])); } F.board(k, 1100, 150, 420, 260, '#5a4630', false); },
    props: (k, y) => { F.table(k, 120, y, 760, '#6a4a30', 150); k.obj(900, y - 120, 200, 120, k.gi('#c0392b'), { r: 3 }); for (let i = 0; i < 3; i++) k.rect(920, y - 110 + i * 34, 160, 6, '#000', 'opacity=".3"'); k.obj(1200, y - 260, 280, 260, k.gi('#3a3e48'), { r: 3 }); },
    light: (k) => { F.pendant(k, 500, 190, '#d9d29a'); F.pendant(k, 1100, 190, '#d9d29a'); },
  })),
  P('tradingFloor', 'work', ['stock exchange', 'trading floor', 'wall street office'], 770, (k) => room(k, {
    wall: '#10182a', wk: 'none', floor: '#1c2230', fk: 'tile', lamps: false,
    mid: (k, y) => { k.obj(120, 60, 1360, 300, '#07090f', { r: 4 }); for (let i = 0; i < 16; i++) { const up = i % 3 !== 0; k.add(`<path d="M${160 + i * 80},${280 - (i * 7 % 40)} l20,${up ? -50 : 30} l20,${up ? -30 : 40}" stroke="${k.g(up ? '#3cff7a' : '#ff4a4a')}" stroke-width="4" fill="none"/>`); } },
    props: (k, y) => { for (let r = 0; r < 2; r++) for (let i = 0; i < 4; i++) { F.desk(k, 80 + i * 380, y + r * 40, 330, '#2a3040'); F.monitor(k, 150 + i * 380, y - 130 + r * 40, 100); F.monitor(k, 260 + i * 380, y - 130 + r * 40, 100); } },
    light: (k) => { k.glow(800, 200, 800, '#3aa0ff', .12); },
  })),
  P('newsroom', 'work', ['press room', 'editorial office'], 760, (k) => room(k, {
    wall: '#cfd4da', wk: 'none', floor: '#5a5e68', fk: 'tile',
    mid: (k, y) => { for (let i = 0; i < 4; i++) { k.obj(110 + i * 220, 120, 180, 120, '#0a0c12', { r: 3 }); k.rect(120 + i * 220, 130, 160, 100, k.g(['#3a7ad8', '#c0392b', '#2a8a4a', '#d9a441'][i]), 'opacity=".6"'); } k.sign(1040, 120, 440, 90, 'BREAKING', '#c0392b', '#fff', 50); },
    props: (k, y) => { for (let i = 0; i < 3; i++) { F.desk(k, 120 + i * 500, y, 400, '#e8e8ee'); F.monitor(k, 200 + i * 500, y - 130, 130); F.chair(k, 250 + i * 500, y + 30, '#222'); } },
    light: (k) => { F.tubes(k, 20, 5, 200, 1400); },
  })),
  P('elevator', 'work', ['lift', 'elevator interior'], 780, (k) => room(k, {
    wall: '#9aa0a8', wk: 'metal', t: 80, floor: '#555a62', fk: 'tile', y: 780,
    mid: (k, y) => { k.obj(560, 100, 480, y - 100, k.gi('#8a909a'), { r: 2 }); k.line(800, 100, 800, y, '#222', 6); k.obj(1060, 240, 70, 250, k.gi('#2a2e36'), { r: 6 }); for (let i = 0; i < 6; i++) k.circle(1095, 270 + i * 38, 11, i === 2 ? k.g('#ffd54a') : '#888'); k.rect(660, 40, 280, 40, '#0a0c12'); k.add(`<text x="800" y="72" text-anchor="middle" font-family="monospace" font-size="30" fill="${k.g('#ff6a3a')}">12</text>`); },
    props: (k, y) => { k.rect(100, 540, W - 200, 12, k.gi('#c0c4cc')); },
    light: (k) => { k.lampIn(800, 30, 700, '#fff3d0', .22); },
  })),
  P('startupLoft', 'work', ['startup', 'tech office', 'garage startup', 'hackerspace'], 760, (k) => room(k, {
    wall: '#5a3b2e', wk: 'brick', floor: '#6a6a70', fk: 'concrete', wins: [[80, 130, 640, 380, 4, 2]], view: 'city', frame: '#222',
    mid: (k, y) => { F.whiteboard(k, 820, 150, 460, 260); k.neon(1320, 150, 220, 60, 'BUILD', '#3aff8a', 34); },
    props: (k, y) => { F.desk(k, 120, y, 460, '#c9b48a'); F.monitor(k, 200, y - 130, 140); F.monitor(k, 360, y - 130, 140); F.chair(k, 300, y + 30, '#c0392b'); F.sofa(k, 940, y + 10, 340, '#3a7ad8'); F.table(k, 1380, y + 20, 150, '#c9b48a', 80); k.box(1400, y - 120, 70, 50, '#e8453a'); },
    light: (k) => { F.pendant(k, 300, 220); F.pendant(k, 1100, 220); },
  })),
  P('whiteVoid', 'studio', ['white studio', 'blank studio', 'infinity cove', 'product studio'], 760, (k) => { k.out = false; k.layer('backdrop', () => { k.vg(0, 0, W, 900, k.gi('#f4f5f8'), k.gi('#dcdfe6')); }); k.layer('floor', () => { k.vg(0, 760, W, 140, k.gi('#e6e8ee'), k.gi('#c8ccd6')); k.sheen(760, '#fff', .3); }); k.layer('light', () => { k.glow(800, 380, 900, '#fff', .35); k.shadow(800, 790, 600, 40, .18); }); k.finish(); }),
  P('darkStudio', 'studio', ['black studio', 'spotlight stage', 'dark void', 'interview set'], 760, (k) => { k.out = false; k.layer('backdrop', () => { k.vg(0, 0, W, 900, k.gi('#1a1e2c'), k.gi('#0a0c14')); }); k.layer('floor', () => { k.vg(0, 760, W, 140, k.gi('#1c202c'), k.gi('#0c0e16')); k.sheen(760, '#aac0ff', .12); }); k.layer('light', () => { k.shaft(800, 0, 160, 780, '#cfe0ff', .3, 3); k.glow(800, 770, 520, '#cfe0ff', .22); }); k.finish(); }),
  P('colorStudio', 'studio', ['colour backdrop', 'color backdrop', 'gradient studio'], 760, (k) => { k.out = false; const a = k.v('#3a5ad8', 1), b = k.v('#b04ad8', 1); k.layer('backdrop', () => { k.vg(0, 0, W, 900, k.gi(a), k.gi(b)); for (let i = 0; i < 6; i++) k.circle(200 + i * 260, 200 + (i % 3) * 140, 90 + (i % 2) * 40, '#fff', 'opacity=".05"'); }); k.layer('floor', () => { k.vg(0, 760, W, 140, k.gi(shade(a, .8)), k.gi(shade(b, .5))); k.sheen(760, '#fff', .18); }); k.layer('light', () => { k.glow(800, 400, 800, '#fff', .2); }); k.finish(); }),
  P('chalkboard', 'studio', ['blackboard', 'classroom board', 'teaching wall'], 760, (k) => room(k, { wall: '#25483a', wk: 'none', floor: '#6a4a32', fk: 'wood', wains: 0, mid: (k, y) => { k.vg(80, 60, 1440, 640, k.gi('#27503f'), k.gi('#1d3b30')); let q = ''; for (let i = 0; i < 9; i++) q += `<path d="M160,${150 + i * 60} q${200},${-20 + (i % 3) * 14} ${300 + (i % 4) * 160},0" stroke="#fff" stroke-width="4" fill="none" opacity=".35" stroke-linecap="round"/>`; k.add(q); k.rect(80, 700, 1440, 14, k.gi('#8a6a40')); } })),
  P('blueprint', 'studio', ['technical grid', 'engineering grid', 'schematic'], 760, (k) => { k.out = false; k.layer('backdrop', () => { k.vg(0, 0, W, 900, k.gi('#0f3a7a'), k.gi('#0a2a5a')); k.tex('grid', 0, 0, W, 900, { c: '#9fd0ff', op: .22, t: 50 }); k.tex('grid', 0, 0, W, 900, { c: '#9fd0ff', op: .12, t: 10 }); k.add(`<g stroke="#bfe0ff" stroke-width="3" fill="none" opacity=".4"><circle cx="520" cy="360" r="140"/><circle cx="520" cy="360" r="70"/><rect x="800" y="220" width="420" height="280"/><path d="M800,360 h420 M1010,220 v280"/></g>`); }); k.layer('floor', () => { k.vg(0, 760, W, 140, '#0a2a5a', '#051a3a', 'opacity=".6"'); k.rect(0, 758, W, 3, '#9fd0ff', 'opacity=".5"'); }); k.finish(); }),
  P('gridVoid', 'studio', ['digital grid', 'tron grid', 'virtual space', 'cyber grid'], 760, (k) => { k.out = false; k.layer('backdrop', () => { k.vg(0, 0, W, 760, '#05061a', '#1a0a3a'); k.glow(800, 740, 900, '#b04ad8', .4); for (let i = 0; i < 80; i++) k.circle(k.rd(0, W), k.rd(0, 700), k.rd(.8, 2.2), '#aab', 'opacity=".4"'); }); k.layer('floor', () => { k.vg(0, 760, W, 140, '#120a2a', '#05061a'); let q = ''; for (let j = -16; j <= 16; j++) q += `<line x1="${800 + j * 28}" y1="760" x2="${800 + j * 300}" y2="900" stroke="#ff3d9a" stroke-width="2" opacity=".6"/>`; let yy = 760, st = 5; while (yy < 900) { q += `<line x1="0" y1="${yy}" x2="${W}" y2="${yy}" stroke="#3aa0ff" stroke-width="2" opacity=".55"/>`; yy += st; st *= 1.35; } k.add(q); }); k.finish(); }),
  P('apartmentNight', 'home', ['city apartment', 'studio apartment', 'flat'], 750, (k) => room(k, {
    wall: '#33323a', wk: 'plaster', floor: '#3a2a22', wins: [[1060, 120, 420, 340, 2, 2]], view: 'city',
    mid: (k, y) => { F.shelf(k, 80, y, 260, 380, 4); F.painting(k, 420, 180, 240, 150, '#8ab0d8', '#d98a6a'); },
    props: (k, y) => { F.rug(k, 360, y + 70, 700, '#5a3b5a'); F.sofa(k, 400, y - 6, 440, '#5a4a6a'); F.table(k, 560, y + 84, 200, '#6a4a30', 60); F.plant(k, 1000, y, 1.3); },
    light: (k) => { k.lampIn(330, 450, 240, '#ffd08a', .14 + .35 * k.lampK); },
  })),
];
